package com.asset.dailyapplookupservice;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class LookupServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
