package com.asset.dailyapplookupservice.database.dao.imp;

import com.asset.dailyapplookupservice.constants.Queries;
import com.asset.dailyapplookupservice.database.dao.preparedStatements.RatePlanGroupKeyPreparedStatement;
import com.asset.dailyapplookupservice.database.dao.preparedStatements.RatePlansBatchPreparedStatement;
import com.asset.dailyapplookupservice.database.extractors.RatePlanByIDExtractor;
import com.asset.dailyapplookupservice.database.extractors.RatePlanGroupsExtractor;
import com.asset.dailyapplookupservice.database.extractors.RatePlansExtractor;
import com.asset.dailyapplookupservice.defines.DatabaseStructs;
import com.asset.dailyapplookupservice.defines.Defines;
import com.asset.dailyapplookupservice.defines.ErrorCodes;
import com.asset.dailyapplookupservice.exception.LookupException;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.manager.QueriesCache;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanGroupModel;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanModel;
import com.asset.dailyapplookupservice.model.response.rateplan.RatePlanResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.sql.PreparedStatement;
import java.util.List;

@Component
public class RatePlanDao
{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private RatePlanByIDExtractor ratePlanByIDExtractor;

    private String sqlQuery;

    public List<RatePlanResponse> getAllRatePlans()
    {
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Retrieving The Rate Plans from db");
            sqlQuery = QueriesCache.allQueries.get(Queries.GET_ALL_RATE_PLANS.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            return jdbcTemplate.query(sqlQuery,  new RatePlansExtractor());
        }catch (EmptyResultDataAccessException e) {
            return null;
        }catch (Exception ex){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            ex.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public RatePlanModel getRatePlanByCode(String rpCode) {
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Retrieving The Rate Plan of code = {} from db", rpCode);
            sqlQuery = QueriesCache.allQueries.get(Queries.GET_RATE_PLAN_BY_CODE.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            return jdbcTemplate.queryForObject(sqlQuery, new BeanPropertyRowMapper<>(RatePlanModel.class), rpCode);
        }catch (EmptyResultDataAccessException e) {
            return null;
        }catch (Exception e) {
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void updateRatePlan(RatePlanModel ratePlan)
    {
        DailyAppLogger.DEBUG_LOGGER.debug("Start Updating The Rate Plan in the db");
        try{
            sqlQuery = QueriesCache.allQueries.get(Queries.UPDATE_RATE_PLAN.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.update(sqlQuery, ratePlan.getRatePlanGroupKey(), ratePlan.getShowFlag(), ratePlan.getRatePlanCode());
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void ratePlansBatchUpdate(List<RatePlanModel> ratePlanModelList) {
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Updating The Rate Plans in the db");

            sqlQuery = QueriesCache.allQueries.get(Queries.UPDATE_RATE_PLAN.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.batchUpdate(sqlQuery, new RatePlansBatchPreparedStatement(ratePlanModelList));
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void ratePlansGroupKeysBatchUpdate(List<RatePlanModel> ratePlanModelList) {
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Updating The Rate Plans in the db");

            sqlQuery = QueriesCache.allQueries.get(Queries.UPDATE_RP_GROUP_KEY_IN_RATE_PLANE.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.batchUpdate(sqlQuery, new RatePlanGroupKeyPreparedStatement(ratePlanModelList));
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void setRatePlanGroupKeyInRatePlanByNull(Integer groupKey){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Updating The Rate Plans in the db");

            sqlQuery = QueriesCache.allQueries.get(Queries.REMOVE_RATE_PLAN_GROUP_KEY_FROM_RATE_PLAN.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.update(sqlQuery, groupKey);
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    /*-----------Rate Plan Groups--------------*/
    public List<RatePlanGroupModel> getAllRatePlanGroups(){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Retrieving The Rate Plan Groups from db");
            sqlQuery = QueriesCache.allQueries.get(Queries.GET_ALL_RATE_PLAN_GROUPS.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            return jdbcTemplate.query(sqlQuery, new RatePlanGroupsExtractor());
        }catch (EmptyResultDataAccessException e) {
            return null;
        }
        catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception: {}", e.getMessage());
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception: {}", e.getMessage());
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public List<RatePlanGroupModel> getAllRatePlanGroupsWithRatePlans(){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Retrieving The Rate Plan Groups from db");
            sqlQuery = QueriesCache.allQueries.get(Queries.GET_RATE_PLAN_GROUPS_WITH_RP.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            return jdbcTemplate.query(sqlQuery, new RatePlanGroupsExtractor());
        }catch (EmptyResultDataAccessException e) {
            return null;
        }
        catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception: {}", e.getMessage());
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception: {}", e.getMessage());
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public RatePlanGroupModel getRatePlanGroupByKey(Integer key){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Retrieving The Rate Plan Group from db");
            sqlQuery = QueriesCache.allQueries.get(Queries.GET_RATE_PLAN_GROUP_BY_ID_WITH_RATE_PLANS.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            return jdbcTemplate.query(sqlQuery, ratePlanByIDExtractor, key);
        }catch (EmptyResultDataAccessException e) {
            return null;
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public Integer addRatePlanGroup(RatePlanGroupModel groupModel){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Adding Rate Plan Group to db...");
            sqlQuery = QueriesCache.allQueries.get(Queries.ADD_RATE_PLAN_GROUP.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);

            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(sqlQuery, new String[]
                        {DatabaseStructs.RATE_PLAN_GROUP.RATE_PLAN_GROUP_KEY});
                ps.setString(1, groupModel.getRatePlanGroup());
                ps.setInt(2, groupModel.getShowFlag());
                ps.setString(3, groupModel.getDescription());

                return ps;
            }, keyHolder);
            DailyAppLogger.DEBUG_LOGGER.debug("Inserted with generated key: {}", keyHolder.getKey().intValue());
            return keyHolder.getKey().intValue();
        }catch (Exception ex){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            ex.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void updateRatePlanGroup(RatePlanGroupModel groupModel){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Updating Rate Plan Group...");
            sqlQuery = QueriesCache.allQueries.get(Queries.UPDATE_RATE_PLAN_GROUP.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.update(sqlQuery, groupModel.getRatePlanGroup(), groupModel.getShowFlag(),
                    groupModel.getDescription(), groupModel.getRatePlanGroupKey());
        }catch (Exception ex){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            ex.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void deleteRatePlanGroup(Integer ratePlanGroupKey){
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Updating The Rate Plans in the db");

            sqlQuery = QueriesCache.allQueries.get(Queries.DELETE_RATE_PLAN_GROUP.id);
            DailyAppLogger.DEBUG_LOGGER.debug("SQL Query: {}", sqlQuery);
            jdbcTemplate.update(sqlQuery, ratePlanGroupKey);
        }catch (Exception e){
            DailyAppLogger.DEBUG_LOGGER.error("SQL Data Access Exception");
            DailyAppLogger.ERROR_LOGGER.error("SQL Data Access Exception");
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }
}
