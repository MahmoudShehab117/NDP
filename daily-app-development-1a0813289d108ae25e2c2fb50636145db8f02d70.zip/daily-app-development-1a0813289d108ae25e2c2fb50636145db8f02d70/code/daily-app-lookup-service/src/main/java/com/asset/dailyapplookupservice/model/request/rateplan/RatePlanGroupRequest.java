package com.asset.dailyapplookupservice.model.request.rateplan;

import lombok.Data;

@Data
public class RatePlanGroupRequest {
    Integer ratePlanGroupKey;
}
