package com.asset.dailyapplookupservice.database.extractors;

import com.asset.dailyapplookupservice.defines.DatabaseStructs;
import com.asset.dailyapplookupservice.defines.Defines;
import com.asset.dailyapplookupservice.defines.ErrorCodes;
import com.asset.dailyapplookupservice.exception.LookupException;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanGroupModel;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanModel;
import com.asset.dailyapplookupservice.model.response.rateplan.RatePlanResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RatePlansExtractor implements ResultSetExtractor<List<RatePlanResponse>>
{

    @Override
    public List<RatePlanResponse> extractData(ResultSet rs) throws SQLException, DataAccessException
    {
        try
        {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Data Extraction");
            List<RatePlanResponse> ratePlans = new ArrayList<>();
            while(rs.next())
            {
                RatePlanResponse ratePlanResponse = new RatePlanResponse();

                ratePlanResponse.setRatePlanCode(rs.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN_CODE));
                ratePlanResponse.setRatePlan(rs.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN));
                ratePlanResponse.setRatePlanKey(rs.getInt(DatabaseStructs.RATE_PLAN.RATE_PLAN_KEY));
                ratePlanResponse.setRatePlanGroupKey(rs.getInt(DatabaseStructs.RATE_PLAN.RATE_PLAN_GROUP_KEY));

                String contractType = rs.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN_TYPE);
                int contractTypeInt = "Consumer".equals(contractType) ? 1 : "Enterprise".equals(contractType) ? 2 : 3;
                ratePlanResponse.setContractType(contractTypeInt);

                String type = rs.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN_TYPE);
                int typeInt = "Prepaid".equals(type) ? 1 : "Postpaid".equals(type) ? 2 : 0;
                ratePlanResponse.setRatePlanType(typeInt);

                ratePlanResponse.setShowFlag(rs.getInt(DatabaseStructs.RATE_PLAN.SHOW_FLAG));
                ratePlanResponse.setActivationSourceFlag(rs.getInt(DatabaseStructs.RATE_PLAN.ACTIVATION_SOURCE_FLAG));

                ratePlanResponse.setForIvrCost(rs.getString(DatabaseStructs.RATE_PLAN.FOR_IVR_COST));
                ratePlanResponse.setForIvrRev(rs.getString(DatabaseStructs.RATE_PLAN.FOR_IVR_REV));
                ratePlanResponse.setCombined(rs.getString(DatabaseStructs.RATE_PLAN.COMBINED));
                ratePlanResponse.setPostPreFlag(rs.getInt(DatabaseStructs.RATE_PLAN.POST_PRE_FLAG));

                ratePlans.add(ratePlanResponse);
            }
            return ratePlans;
        } catch (SQLException e) {
            DailyAppLogger.ERROR_LOGGER.error("SQL-Data Extraction Exception ==> {}", e.getMessage());
            DailyAppLogger.DEBUG_LOGGER.error("SQL-Data Extraction Exception ==> {}", e.getMessage());
            e.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_MAPPING_ERROR, Defines.SEVERITY.FATAL);
        }
    }
}
