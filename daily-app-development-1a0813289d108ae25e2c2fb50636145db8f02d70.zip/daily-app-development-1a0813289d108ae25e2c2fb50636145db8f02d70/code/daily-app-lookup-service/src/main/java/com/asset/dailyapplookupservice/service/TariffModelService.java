package com.asset.dailyapplookupservice.service;

import com.asset.dailyapplookupservice.database.dao.imp.TariffModelDAOImp;
import com.asset.dailyapplookupservice.defines.Defines;
import com.asset.dailyapplookupservice.defines.ErrorCodes;
import com.asset.dailyapplookupservice.exception.LookupException;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.model.response.tariff.TariffModelsResponse;
import com.asset.dailyapplookupservice.model.response.tariff.TariffModelResponse;
import com.asset.dailyapplookupservice.model.shared.TariffModel;
import com.asset.dailyapplookupservice.utils.TariffModelUtil;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TariffModelService {

    @Autowired
    TariffModelDAOImp tariffModelDAOImp;

    public TariffModelsResponse getAllTariffModels() throws LookupException {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all tariff list");
        List<TariffModel> tariffModels = tariffModelDAOImp.getAllTariffModel();
        if (tariffModels == null || tariffModels.isEmpty()) {
            DailyAppLogger.DEBUG_LOGGER.error("No tariff were found");
            throw new LookupException(ErrorCodes.ERROR.NO_TARIFF_MODELS_FOUND, Defines.SEVERITY.ERROR,"tariffModel");
        }
        List<TariffModelResponse> tariffModelResponses = TariffModelUtil.mapTariffModelsResponse(tariffModels);
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving all tariff list");
        return new TariffModelsResponse(tariffModelResponses);
    }


    public Integer updateTariffModel(TariffModelResponse tariffModelResponse) throws LookupException {
         TariffModel tariffModel = TariffModelUtil.mapTariffModel(tariffModelResponse);
        DailyAppLogger.DEBUG_LOGGER.debug("Start updating tariff model [" + tariffModel + "]");
        Integer rowsAffected = tariffModelDAOImp.updateTariffModel(tariffModel);
        if (rowsAffected == 0 || rowsAffected == null) {
            DailyAppLogger.DEBUG_LOGGER.error("Tariff code not updated");
            throw new LookupException(ErrorCodes.ERROR.UPDATE_FAILED, Defines.SEVERITY.ERROR,"tariffModel");
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Updated tariff model successfully with row affected ["+rowsAffected+"}");
        return rowsAffected;
    }
    
    public void updateTariffModelBatch(List<TariffModelResponse> tariffModelResponses) throws LookupException {
         List<TariffModel> tariffModels = TariffModelUtil.mapTariffModelList(tariffModelResponses);
        DailyAppLogger.DEBUG_LOGGER.debug("Start updating tariff model batch [" + tariffModels + "]");
        int[] rowsAffected = tariffModelDAOImp.UpdateTariffModelBatch(tariffModels);
        DailyAppLogger.DEBUG_LOGGER.debug("Updated tariff model batch successfully with row affected ["+Arrays.asList(rowsAffected)+"}");
    }

}
