package com.asset.dailyapplookupservice.database.extractors;

import com.asset.dailyapplookupservice.defines.DatabaseStructs;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanGroupModel;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanModel;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class RatePlanGroupsExtractor implements ResultSetExtractor<List<RatePlanGroupModel>> {
    @Override
    public List<RatePlanGroupModel> extractData(ResultSet rs) throws SQLException, DataAccessException {
        try
        {
            DailyAppLogger.DEBUG_LOGGER.debug("Start Data Extraction");
            List<RatePlanGroupModel> groups = new ArrayList<>();
            HashMap<Integer, RatePlanModel> ratePlanGroupMap = new HashMap<>();
            while(rs.next())
            {
                RatePlanGroupModel ratePlanGroupModel = new RatePlanGroupModel();
                RatePlanModel ratePlan = new RatePlanModel();

                ratePlanGroupModel.setRatePlanGroupKey(rs.getInt(DatabaseStructs.RATE_PLAN_GROUP.RATE_PLAN_GROUP_KEY));
                ratePlanGroupModel.setRatePlanGroup(rs.getString(DatabaseStructs.RATE_PLAN_GROUP.RATE_PLAN_GROUP));
                ratePlanGroupModel.setShowFlag(rs.getInt(DatabaseStructs.RATE_PLAN_GROUP.SHOW_FLAG));
                ratePlanGroupModel.setDescription(rs.getString(DatabaseStructs.RATE_PLAN_GROUP.DESCRIPTION));

                groups.add(ratePlanGroupModel);
            }
            return groups;
        } catch (SQLException e) {
            DailyAppLogger.ERROR_LOGGER.error("SQL Exception ==> {}", e.getMessage());
            DailyAppLogger.DEBUG_LOGGER.error("SQL Exception ==> {}", e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
