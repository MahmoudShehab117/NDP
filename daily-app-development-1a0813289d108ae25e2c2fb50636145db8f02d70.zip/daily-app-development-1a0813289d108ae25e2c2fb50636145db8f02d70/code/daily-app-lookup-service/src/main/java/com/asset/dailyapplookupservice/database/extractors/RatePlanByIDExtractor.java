package com.asset.dailyapplookupservice.database.extractors;

import com.asset.dailyapplookupservice.defines.DatabaseStructs;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanGroupModel;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanModel;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
@Component
public class RatePlanByIDExtractor implements ResultSetExtractor<RatePlanGroupModel> {
    @Override
    public RatePlanGroupModel extractData(ResultSet resultSet) throws SQLException, DataAccessException {
        RatePlanGroupModel ratePlanGroupModel = null;
        RatePlanModel ratePlanModel;
        ArrayList<RatePlanModel> priceGroupModels  = new ArrayList<>();

        while (resultSet.next()) {
            ratePlanGroupModel = new RatePlanGroupModel();
            ratePlanGroupModel.setRatePlanGroupKey(resultSet.getInt(DatabaseStructs.RATE_PLAN_GROUP.RATE_PLAN_GROUP_KEY));
            ratePlanGroupModel.setRatePlanGroup(resultSet.getString(DatabaseStructs.RATE_PLAN_GROUP.RATE_PLAN_GROUP));
            ratePlanGroupModel.setShowFlag(resultSet.getInt(DatabaseStructs.RATE_PLAN.SHOW_FLAG));
            ratePlanGroupModel.setDescription(resultSet.getString(DatabaseStructs.RATE_PLAN_GROUP.DESCRIPTION));

            ratePlanGroupModel.setRatePlans(priceGroupModels);


            Integer RatePlanId = resultSet.getInt(DatabaseStructs.RATE_PLAN.RATE_PLAN_KEY);

            if (!RatePlanId.equals(0)) {
                ratePlanModel = new RatePlanModel();
                ratePlanModel.setRatePlanKey(RatePlanId);
                ratePlanModel.setRatePlan(resultSet.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN));

                ratePlanModel.setRatePlanCode(resultSet.getString(DatabaseStructs.RATE_PLAN.RATE_PLAN_CODE));
                ratePlanModel.setRatePlanType(resultSet.getInt(DatabaseStructs.RATE_PLAN.RATE_PLAN_TYPE));
                ratePlanModel.setContractType(resultSet.getInt(DatabaseStructs.RATE_PLAN.CONTRACT_TYPE));
                ratePlanModel.setActivationSourceFlag(resultSet.getInt(DatabaseStructs.RATE_PLAN.ACTIVATION_SOURCE_FLAG));
                ratePlanModel.setShowFlag(resultSet.getInt("SHOW_FLAG_RATE_PLAN_GROUP") );
                ratePlanModel.setCombined(resultSet.getString(DatabaseStructs.RATE_PLAN.COMBINED));
                ratePlanModel.setPostPreFlag(resultSet.getString(DatabaseStructs.RATE_PLAN.POST_PRE_FLAG));
                ratePlanModel.setForIvrRev(resultSet.getString(DatabaseStructs.RATE_PLAN.FOR_IVR_REV));
                ratePlanModel.setForIvrCost(resultSet.getString(DatabaseStructs.RATE_PLAN.FOR_IVR_COST));
                priceGroupModels.add(ratePlanModel);

            }
        }
        return ratePlanGroupModel;
    }
}
