package com.asset.dailyapplookupservice.model.request.priceGroup;

public class GetPgGroupRequestModel {


   private  String PgGroupId;

    public String getPgGroupId() {
        return PgGroupId;
    }

    public void setPgGroupId(String pgGroupId) {
        PgGroupId = pgGroupId;
    }
}
