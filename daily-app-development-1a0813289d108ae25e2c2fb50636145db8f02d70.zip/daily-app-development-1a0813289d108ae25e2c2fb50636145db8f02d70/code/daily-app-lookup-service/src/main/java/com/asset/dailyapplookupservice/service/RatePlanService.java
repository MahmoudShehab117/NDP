package com.asset.dailyapplookupservice.service;

import com.asset.dailyapplookupservice.database.dao.imp.RatePlanDao;
import com.asset.dailyapplookupservice.defines.Defines;
import com.asset.dailyapplookupservice.defines.ErrorCodes;
import com.asset.dailyapplookupservice.exception.LookupException;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanGroupModel;
import com.asset.dailyapplookupservice.model.rateplan.RatePlanModel;
import com.asset.dailyapplookupservice.model.response.rateplan.RatePlanResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.stream.IntStream;

@Component
public class RatePlanService {
    @Autowired
    RatePlanDao ratePlanDao;

    public List<RatePlanResponse> getAllRatePlans(){
        List<RatePlanResponse> ratePlans = ratePlanDao.getAllRatePlans();

        DailyAppLogger.DEBUG_LOGGER.debug("Check rate plans existence");
        if(ratePlans == null || ratePlans.isEmpty()) {
            DailyAppLogger.DEBUG_LOGGER.error("No Rate Plans Found in db");
            DailyAppLogger.ERROR_LOGGER.error("No Rate Plans Found in db");
            throw new LookupException(ErrorCodes.ERROR.NO_RATE_PLANS_FOUND, Defines.SEVERITY.ERROR);
        }
        return ratePlans;
    }

    public void updateRatePlan(RatePlanModel ratePlanModel){
        DailyAppLogger.DEBUG_LOGGER.debug("Check Rate Plan Code Existence........");
        if (getRatePlanByCode(ratePlanModel.getRatePlanCode()) == null) {
            DailyAppLogger.DEBUG_LOGGER.error("Rate Plan Code Does NOT Exist");
            DailyAppLogger.ERROR_LOGGER.error("Rate Plan Code Does NOT Exist");
            throw new LookupException(ErrorCodes.ERROR.RATE_PLAN_DOES_NOT_EXIST, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Code Exists ==> Update Rate Plan......");
        ratePlanDao.updateRatePlan(ratePlanModel);
        DailyAppLogger.DEBUG_LOGGER.debug("Updated Successfully");
    }

    public void ratePlansBatchUpdate(List<RatePlanModel> ratePlanModelList){
        DailyAppLogger.DEBUG_LOGGER.debug("Update List of Rate Plans......");
        ratePlanDao.ratePlansBatchUpdate(ratePlanModelList);
        DailyAppLogger.DEBUG_LOGGER.debug("Updated Successfully");
    }

    private RatePlanModel getRatePlanByCode(String ratePlanCode){
        RatePlanModel ratePlanModel = ratePlanDao.getRatePlanByCode(ratePlanCode);
        DailyAppLogger.DEBUG_LOGGER.debug("Check rate plan existence");
        if (ratePlanModel != null)
            return ratePlanModel;
        DailyAppLogger.DEBUG_LOGGER.error("Rate Plan Code Does NOT Exist");
        DailyAppLogger.ERROR_LOGGER.error("Rate Plan Code Does NOT Exist");
        throw new LookupException(ErrorCodes.ERROR.RATE_PLAN_DOES_NOT_EXIST, Defines.SEVERITY.ERROR);
    }

        /*-----------Rate Plan Groups--------------*/
    public List<RatePlanGroupModel> getAllRatePlanGroups(){
        List<RatePlanGroupModel> groups = ratePlanDao.getAllRatePlanGroups();
        if(groups == null)
        {
            DailyAppLogger.DEBUG_LOGGER.error("Rate Plan GROUP Does NOT Exist");
            DailyAppLogger.ERROR_LOGGER.error("Rate Plan GROUP Does NOT Exist");
            throw new LookupException(ErrorCodes.ERROR.GROUPS_NOT_FOUND, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Retrieved Successfully");
        return groups;
    }

    public RatePlanGroupModel getRatePlanGroupByKey(Integer key){
        RatePlanGroupModel group = ratePlanDao.getRatePlanGroupByKey(key);
        if (group != null)
            return group;
        DailyAppLogger.DEBUG_LOGGER.error("GROUP KEY DOES NOT EXIST");
        DailyAppLogger.ERROR_LOGGER.error("GROUP KEY DOES NOT EXIST");
        throw new LookupException(ErrorCodes.ERROR.GROUPS_NOT_FOUND, Defines.SEVERITY.ERROR);
    }

    public Integer addRatePlanGroup(RatePlanGroupModel groupModel){
        Integer key = ratePlanDao.addRatePlanGroup(groupModel);
        if(key == null) {
            DailyAppLogger.DEBUG_LOGGER.error("Rate Plan Group Cannot Be Added");
            DailyAppLogger.ERROR_LOGGER.error("Rate Plan Group Cannot Be Added");
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR);
        }
        groupModel.setRatePlanGroupKey(key);
        DailyAppLogger.DEBUG_LOGGER.debug("<<<<GroupMode.getGroupKey>>>> = {}", groupModel.getRatePlanGroupKey());

        DailyAppLogger.DEBUG_LOGGER.debug("Start Assigning RPG Key for each RP...");
        IntStream.range(0, groupModel.getRatePlans().size()).forEach(i -> groupModel.getRatePlans().get(i).setRatePlanGroupKey(key));

        DailyAppLogger.DEBUG_LOGGER.debug("Start Updating Rate Plans...");
        ratePlanDao.ratePlansGroupKeysBatchUpdate(groupModel.getRatePlans());

        DailyAppLogger.DEBUG_LOGGER.debug("Added Successfully, new key = {}", key.toString());
        return key;
    }

    public void updateRatePlanGroupAndRatePlans(RatePlanGroupModel groupModel){
        DailyAppLogger.DEBUG_LOGGER.debug("checking Rate Plan Group Existence with key = {}", groupModel.getRatePlanGroupKey());
        getRatePlanGroupByKey(groupModel.getRatePlanGroupKey());

        DailyAppLogger.DEBUG_LOGGER.debug("Start Removing Rate Plan Group Key from Rate Plans Of group key = {}...", groupModel.getRatePlanGroupKey());
        ratePlanDao.setRatePlanGroupKeyInRatePlanByNull(groupModel.getRatePlanGroupKey());

        DailyAppLogger.DEBUG_LOGGER.debug("Start Updating Rate Plan Group...");
        ratePlanDao.updateRatePlanGroup(groupModel);

        DailyAppLogger.DEBUG_LOGGER.debug("Start Updating Rate Plans if Exists...");
        ratePlanDao.ratePlansGroupKeysBatchUpdate(groupModel.getRatePlans());

        DailyAppLogger.DEBUG_LOGGER.debug("Updated Successfully");
    }

    public void deleteRatePlanGroup(Integer ratePlanGroupKey){
        DailyAppLogger.DEBUG_LOGGER.debug("Checking Rate Plan Group Existence with key = {}", ratePlanGroupKey);
        getRatePlanGroupByKey(ratePlanGroupKey);

        DailyAppLogger.DEBUG_LOGGER.debug("Start Removing Rate Plan Group Key from Rate Plans Of group key = {}...", ratePlanGroupKey);
        ratePlanDao.setRatePlanGroupKeyInRatePlanByNull(ratePlanGroupKey);

        DailyAppLogger.DEBUG_LOGGER.debug("Start Deleting Rate Plan Group...");
        ratePlanDao.deleteRatePlanGroup(ratePlanGroupKey);
    }
}
