package com.asset.dailyapplookupservice.database.dao.imp;

import com.asset.dailyapplookupservice.configuration.Properties;
import com.asset.dailyapplookupservice.constants.Queries;
import com.asset.dailyapplookupservice.database.extractors.PriceGroupExtractor;
import com.asset.dailyapplookupservice.database.extractors.PriceGroupGroupBYIdExtractor;
import com.asset.dailyapplookupservice.defines.DatabaseStructs;
import com.asset.dailyapplookupservice.defines.Defines;
import com.asset.dailyapplookupservice.defines.ErrorCodes;
import com.asset.dailyapplookupservice.exception.LookupException;
import com.asset.dailyapplookupservice.logger.DailyAppLogger;
import com.asset.dailyapplookupservice.manager.QueriesCache;
import com.asset.dailyapplookupservice.model.request.priceGroup.AddPriceGroupGroupRequest;
import com.asset.dailyapplookupservice.model.request.priceGroup.GetPgGroupRequestModel;
import com.asset.dailyapplookupservice.model.request.priceGroup.UpdatePriceGroupResponse;
import com.asset.dailyapplookupservice.model.response.pricegroup.GetPgGroupModel;
import com.asset.dailyapplookupservice.model.shared.PgGroupModel;
import com.asset.dailyapplookupservice.model.shared.PriceGroupModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@Component
public class PriceGroupDAOImp {
    private final BeanPropertyRowMapper<PgGroupModel> getAllPriceGroupGroups = new BeanPropertyRowMapper<>(PgGroupModel.class);
    @Autowired
    Properties properties;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private PriceGroupExtractor priceGroupExtractor;
    @Autowired
    private PriceGroupGroupBYIdExtractor priceGroupGroupBYIdExtractor;

    public int UpdatePriceGroup(PriceGroupModel groupModel) throws LookupException {
        String updatePriceGroup = QueriesCache.allQueries.get(Queries.UPDATE_PRICE_GROUP.id);
        try {
            return jdbcTemplate.update(updatePriceGroup, groupModel.getPgGroupKey().getPgGroupKey(), LocalDate.now(), groupModel.getPriceGroupCode());
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + updatePriceGroup);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + updatePriceGroup, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public int updatePgGroup(PgGroupModel pgGroupModel) throws LookupException {
        String updatePgGroup = QueriesCache.allQueries.get(Queries.UPDATE_PG_GROUP.id);
        try {
            return jdbcTemplate.update(updatePgGroup, pgGroupModel.getPgGroup(), pgGroupModel.getShowFlag(), pgGroupModel.getDescription(), pgGroupModel.getPgGroupKey());
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + updatePgGroup);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + updatePgGroup, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public List<PriceGroupModel> getAll() throws LookupException {
        String getAllPriceGroupQuery = QueriesCache.allQueries.get(Queries.GET_ALL_GROUP.id);
        try {
            return jdbcTemplate.query(getAllPriceGroupQuery, priceGroupExtractor);
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + getAllPriceGroupQuery);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + getAllPriceGroupQuery, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public List<PgGroupModel> getAllPriceGroupGroups() {
        String getAllPriceGroupGroupsQuery = QueriesCache.allQueries.get(Queries.GET_PRICE_GROUP_GROUPS.id);
        try {
            return jdbcTemplate.query(getAllPriceGroupGroupsQuery, getAllPriceGroupGroups);
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + getAllPriceGroupGroupsQuery);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + getAllPriceGroupGroupsQuery, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public GetPgGroupModel getPriceGroupGroupById(GetPgGroupRequestModel pgGroup) {
        String getPriceGroupGroupByIdQuery = QueriesCache.allQueries.get(Queries.GET_PRICE_GROUP_GROUPS_ById.id);
        try {
            GetPgGroupModel getPgGroupModel = jdbcTemplate.query(getPriceGroupGroupByIdQuery, priceGroupGroupBYIdExtractor, pgGroup.getPgGroupId());
            if (getPgGroupModel.getPgGroupModel() != null) {
                getPgGroupModel.getPgGroupModel().setPgGroupKey(pgGroup.getPgGroupId());
                return getPgGroupModel;
            }
            return null;
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + getPriceGroupGroupByIdQuery);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + getPriceGroupGroupByIdQuery, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }


    public int getPgGroup(String pgGroupKey) throws LookupException {
        String getPgGroup = QueriesCache.allQueries.get(Queries.GET_PG_GROUP.id);
        try {
            return jdbcTemplate.queryForObject(getPgGroup, Integer.class, pgGroupKey);
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + getPgGroup);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + getPgGroup, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public Integer addPGGroups(AddPriceGroupGroupRequest addPriceGroupGroupRequest) {
        String addPgGroup = QueriesCache.allQueries.get(Queries.INSERT_PG_GROUP.id);
        try {
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update((Connection connection) -> {
                PreparedStatement ps = connection.prepareStatement(addPgGroup, new String[]{DatabaseStructs.PG_GROUP.PG_GROUP_KEY});
                ps.setString(1, addPriceGroupGroupRequest.getPgGroupModel().getPgGroup());
                ps.setInt(2, addPriceGroupGroupRequest.getPgGroupModel().getShowFlag());
                ps.setString(3, addPriceGroupGroupRequest.getPgGroupModel().getDescription());

                return ps;
            }, keyHolder);
            int pgGroupId = keyHolder.getKey() == null ? null : keyHolder.getKey().intValue();
            addPriceGroupGroupRequest.getPgGroupModel().setPgGroupKey(String.valueOf(pgGroupId));
            return pgGroupId;
        } catch (Exception ex) {
            DailyAppLogger.DEBUG_LOGGER.error("error while execute " + addPgGroup);
            DailyAppLogger.ERROR_LOGGER.error("error while execute " + addPgGroup, ex);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
        }
    }

    public void UpdatePriceGroupBatch(List<UpdatePriceGroupResponse> priceGroupList) {
        String updatePriceGroup = QueriesCache.allQueries.get(Queries.UPDATE_PRICE_GROUP.id);
        jdbcTemplate.batchUpdate(updatePriceGroup, new BatchPreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps, int i) {
                try {
                    UpdatePriceGroupResponse data = priceGroupList.get(i);


                    ps.setString(1, data.getPgGroupKey());
                    ps.setDate(2, Date.valueOf(LocalDate.now()));
                    ps.setString(3, data.getPriceGroupCode());


                } catch (SQLException ex) {
                    DailyAppLogger.DEBUG_LOGGER.error("error while execute " + updatePriceGroup);
                    DailyAppLogger.ERROR_LOGGER.error("error while execute " + updatePriceGroup, ex);
                    throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.ERROR, ex.getMessage());
                }
            }

            @Override
            public int getBatchSize() {
                return priceGroupList.size();
            }
        });

    }

    public void pgGroupExistInPriceGroup(String pgGroupId)  {
        String getPgGroupUsingPriceGroupID = QueriesCache.allQueries.get(Queries.GET_PG_GROUP_USING_PRICE_GROUP_ID.id);
        try {
            DailyAppLogger.DEBUG_LOGGER.debug("getPgGroupUsingPriceGroupID sql:  "+ getPgGroupUsingPriceGroupID );

            DailyAppLogger.DEBUG_LOGGER.debug("getPriceGroupKeyForGroupSelectionForPostPaid  "+ properties.getPriceGroupKeyForGroupSelectionForPostPaid() );
            DailyAppLogger.DEBUG_LOGGER.debug("getPriceGroupKeyForGroupSelectionForPrePaid  "+ properties.getPriceGroupKeyForGroupSelectionForPrePaid() );
            String postPaidPgGroupId = jdbcTemplate.queryForObject(getPgGroupUsingPriceGroupID,String.class, properties.getPriceGroupKeyForGroupSelectionForPostPaid());
            DailyAppLogger.DEBUG_LOGGER.debug("postPaidPgGroupId  "+ postPaidPgGroupId );

            String prePaidPgGroupId =  jdbcTemplate.queryForObject(getPgGroupUsingPriceGroupID,String.class, properties.getPriceGroupKeyForGroupSelectionForPrePaid());
            DailyAppLogger.DEBUG_LOGGER.debug("prePaidPgGroupId  "+ prePaidPgGroupId );

            DailyAppLogger.DEBUG_LOGGER.debug("if pg group used in configuration system we can not delete it ");
            if (postPaidPgGroupId ==null || prePaidPgGroupId ==null ||
                    postPaidPgGroupId.equals(pgGroupId) || prePaidPgGroupId.equals(pgGroupId)) {
                throw new LookupException(ErrorCodes.ERROR.CANNOT_DELETE_PG_GROUP_USED_IN_CONFIGURATION_SYSTEM, Defines.SEVERITY.ERROR);

            }
        } catch (LookupException exception){
            DailyAppLogger.DEBUG_LOGGER.debug("error while execute deletePgGroup", getPgGroupUsingPriceGroupID + " error ", exception);
            DailyAppLogger.ERROR_LOGGER.error("error while execute deletePgGroup  " + exception.getMessage());
            throw new LookupException(ErrorCodes.ERROR.CANNOT_DELETE_PG_GROUP_USED_IN_CONFIGURATION_SYSTEM, Defines.SEVERITY.FATAL);
        }
        catch (Exception exception) {
            DailyAppLogger.DEBUG_LOGGER.debug("error while execute deletePgGroup", getPgGroupUsingPriceGroupID + " error ", exception);
            DailyAppLogger.ERROR_LOGGER.error("error while execute deletePgGroup  " + exception.getMessage());
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void setPgGroupKeyNullInPriceGroup(String pgGroupId) {
        String setPgGroupKeyNullInPriceGroup = QueriesCache.allQueries.get(Queries.SET_PG_GROUP_KEY_NULL_IN_PRICE_GROUP.id);
        try {
            DailyAppLogger.DEBUG_LOGGER.info("Start Set pgGroupKey null in priceGroup");
            DailyAppLogger.DEBUG_LOGGER.info("SQL Query = " + setPgGroupKeyNullInPriceGroup);
            jdbcTemplate.update(setPgGroupKeyNullInPriceGroup, pgGroupId);
        } catch (Exception exception) {
            DailyAppLogger.DEBUG_LOGGER.debug("error while execute deletePgGroup", setPgGroupKeyNullInPriceGroup + " error ", exception);
            DailyAppLogger.ERROR_LOGGER.error("error while execute deletePgGroup  " + exception.getMessage());
            exception.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }

    public void deletePgGroup(String pgGroupId) {
        String deletePgGroup = QueriesCache.allQueries.get(Queries.DELETE_PG_GROUP.id);

        try {
            DailyAppLogger.DEBUG_LOGGER.info("Start deleting pgGroup");

            DailyAppLogger.DEBUG_LOGGER.info("SQL Query = " + deletePgGroup);
            jdbcTemplate.update(deletePgGroup, pgGroupId);
        } catch (Exception exception) {
            DailyAppLogger.DEBUG_LOGGER.debug("error while execute deletePgGroup", deletePgGroup + " error ", exception);
            DailyAppLogger.ERROR_LOGGER.error("error while execute deletePgGroup  " + exception.getMessage());
            exception.printStackTrace();
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }

    }

    public void assertPgGroupKeyExistenceForPriceGroup(String pgGroupKey) {
        String getPgGroupUsingPriceGroupID = QueriesCache.allQueries.get(Queries.GET_PG_GROUP_USING_PRICE_GROUP_ID.id);
        String updatePgGroupUsingPriceGroup = QueriesCache.allQueries.get(Queries.UPDATE_PG_GROUP_USING_PRICE_GROUP_KEY.id);

        try {


            String postPaidPgGroupId = jdbcTemplate.queryForObject(getPgGroupUsingPriceGroupID,String.class, properties.getPriceGroupKeyForGroupSelectionForPostPaid());
            String prePaidPgGroupId =  jdbcTemplate.queryForObject(getPgGroupUsingPriceGroupID,String.class, properties.getPriceGroupKeyForGroupSelectionForPrePaid());
            DailyAppLogger.DEBUG_LOGGER.debug("check getPgGroup for post paid "+ getPgGroupUsingPriceGroupID + "price group id "+  properties.getPriceGroupKeyForGroupSelectionForPostPaid());
            DailyAppLogger.DEBUG_LOGGER.debug("check getPgGroup for pre paid "+ getPgGroupUsingPriceGroupID + "price group id "+  properties.getPriceGroupKeyForGroupSelectionForPrePaid());
            if (postPaidPgGroupId ==null) {
                DailyAppLogger.DEBUG_LOGGER.debug(" post paid for price group can not be null , set pg group for postpaid using pg group id  ");
                jdbcTemplate.update(updatePgGroupUsingPriceGroup,pgGroupKey, properties.getPriceGroupKeyForGroupSelectionForPostPaid() );
                throw new LookupException(ErrorCodes.WARRNING.PG_GROUP_CAN_NOT_BE_NULL_IN_POST_PAID, Defines.SEVERITY.WARNING);

            }
            if(prePaidPgGroupId ==null ){
                DailyAppLogger.DEBUG_LOGGER.debug(" pre paid for price group can not be null , set pg group for pre paid  using pg group id  ");
                jdbcTemplate.update(updatePgGroupUsingPriceGroup,pgGroupKey, properties.getPriceGroupKeyForGroupSelectionForPrePaid());
                throw new LookupException(ErrorCodes.WARRNING.PG_GROUP_CAN_NOT_BE_NULL_IN_PRE_PAID, Defines.SEVERITY.WARNING);
            }
        }
        catch (LookupException e){
            DailyAppLogger.DEBUG_LOGGER.debug(" pre paid for price group can not be null , set pg group for pre paid  using pg group id  ");
            throw new LookupException(ErrorCodes.WARRNING.PG_GROUP_CAN_NOT_BE_NULL_IN_POST_PAID_OR_PRE_PAID, Defines.SEVERITY.WARNING);
        }
        catch (Exception exception) {
            DailyAppLogger.DEBUG_LOGGER.debug("error while execute deletePgGroup" , exception);
            DailyAppLogger.ERROR_LOGGER.error("error while execute deletePgGroup  " + exception);
            throw new LookupException(ErrorCodes.ERROR.DATABASE_ERROR, Defines.SEVERITY.FATAL);
        }
    }
}
