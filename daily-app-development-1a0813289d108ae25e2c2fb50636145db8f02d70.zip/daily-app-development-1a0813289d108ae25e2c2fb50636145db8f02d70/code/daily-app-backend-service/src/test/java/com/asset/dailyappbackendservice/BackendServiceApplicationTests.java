package com.asset.dailyappbackendservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
