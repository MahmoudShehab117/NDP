package com.asset.dailyappbackendservice.defines;

public class ErrorCodes {
    public static class SUCCESS {
        public final static int SUCCESS = 0;
    }

    public static class ERROR {
        public final static int USER_NOT_AUTHORIZED = -402;



    }

}
