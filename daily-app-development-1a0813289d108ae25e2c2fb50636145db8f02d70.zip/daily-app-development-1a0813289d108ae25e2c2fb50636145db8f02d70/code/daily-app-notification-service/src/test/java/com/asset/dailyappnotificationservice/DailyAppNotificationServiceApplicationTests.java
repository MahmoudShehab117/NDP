package com.asset.dailyappnotificationservice;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class DailyAppNotificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
