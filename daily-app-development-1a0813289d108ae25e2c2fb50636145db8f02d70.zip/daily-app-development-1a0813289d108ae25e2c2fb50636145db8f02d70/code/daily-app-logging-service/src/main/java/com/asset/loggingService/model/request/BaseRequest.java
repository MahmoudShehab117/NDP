package com.asset.loggingService.model.request;

public class BaseRequest {
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    private String token;


}
