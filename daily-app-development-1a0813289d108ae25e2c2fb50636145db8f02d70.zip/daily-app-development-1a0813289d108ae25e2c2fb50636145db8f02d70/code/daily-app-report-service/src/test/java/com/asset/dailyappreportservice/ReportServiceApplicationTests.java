package com.asset.dailyappreportservice;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class ReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
