package com.asset.dailyappreportservice.service;

import com.asset.dailyappreportservice.configuration.Properties;
import com.asset.dailyappreportservice.database.dao.imp.ValidationEngineDAOImp;
import com.asset.dailyappreportservice.defines.Defines;
import com.asset.dailyappreportservice.defines.ErrorCodes;
import com.asset.dailyappreportservice.excel.ExcelHelper;
import com.asset.dailyappreportservice.exception.ReportsException;
import com.asset.dailyappreportservice.logger.DailyAppLogger;
import com.asset.dailyappreportservice.model.request.AggregationListRequest;
import com.asset.dailyappreportservice.model.request.EpochDateRequest;
import com.asset.dailyappreportservice.model.response.RetrieveAggregationDataResponse;
import com.asset.dailyappreportservice.model.validationEngine.GetAllAggregationData;
import com.asset.dailyappreportservice.model.validationEngine.GetAllBalances;
import com.asset.dailyappreportservice.model.validationEngine.GetAllTransactionResponse;
import com.asset.dailyappreportservice.model.validationEngine.TransactionModel;
import com.asset.dailyappreportservice.security.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.util.List;

@Component
public class ValidationEngineService {

    @Autowired
    Properties properties;
    @Autowired
    ValidationEngineDAOImp validationEngineDAOImp;

    @Autowired
    JwtTokenUtil jwtTokenUtil;

    public GetAllBalances RetrieveBalances(EpochDateRequest validationEngineRequest) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all BALANCE ");
        GetAllBalances getAllBalances = validationEngineDAOImp.RetrieveBalances(validationEngineRequest);
        if (getAllBalances.getClosing() != null && getAllBalances.getOpening() != null) {
            getAllBalances.setVariance(Double.parseDouble(getAllBalances.getClosing()) - Double.parseDouble(getAllBalances.getOpening())); //TODO UNCOMMENT VARIANCE
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving all BALANCE");
        return getAllBalances;
    }

    public GetAllAggregationData RetrieveAggregationData(EpochDateRequest validationEngineRequest) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all AggregationData ");
        List<RetrieveAggregationDataResponse> aggregationDataResponses = validationEngineDAOImp.RetrieveAggregationData(validationEngineRequest);
        if (aggregationDataResponses == null || aggregationDataResponses.isEmpty())
        {
            DailyAppLogger.DEBUG_LOGGER.debug("The Entered Date Has No Aggregated Data");
            DailyAppLogger.ERROR_LOGGER.error("The Entered Date Has No Aggregated Data");
            throw new ReportsException(ErrorCodes.ERROR.DATE_HAS_NO_DATA, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving AggregationData");
        return new GetAllAggregationData(aggregationDataResponses);
    }

    public GetAllTransactionResponse GetTransactionType() {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all TransactionType ");
        List<TransactionModel> transactionModelList = validationEngineDAOImp.GetTransactionType();
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving TransactionType");
        return new GetAllTransactionResponse(transactionModelList);
    }

    @Transactional(rollbackFor = ReportsException.class)// todo rollback
    public void update(AggregationListRequest aggregationListRequest) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start update Update in VALID_ENGINE_AGGREGATION");
        int userId = jwtTokenUtil.parseJwt(aggregationListRequest.getToken()).getUserId();
        for (int i = 0; i < aggregationListRequest.getAggregationLists().size(); i++) {
            DailyAppLogger.DEBUG_LOGGER.debug("Insert token ");
            aggregationListRequest.getAggregationLists().get(i).setUserId(userId);
            validationEngineDAOImp.updateValidEngineAggregation(aggregationListRequest.getAggregationLists().get(i));
            DailyAppLogger.DEBUG_LOGGER.debug(" Update in VALID_ENGINE_AGGREGATION Done");
            DailyAppLogger.DEBUG_LOGGER.debug("Start Update in VALIDATION_ENGINE ");
            validationEngineDAOImp.updateValidationEngine(aggregationListRequest.getAggregationLists().get(i)); //todo no table yet
            DailyAppLogger.DEBUG_LOGGER.debug(" Update in VALIDATION_ENGINE Done");
            DailyAppLogger.DEBUG_LOGGER.debug("Start Insert daily record in DAILY_DATA_AGGREGATION");
            int insertDailyDataAggregation = validationEngineDAOImp.insertDailyDataAggregation(aggregationListRequest.getAggregationLists().get(i));
            DailyAppLogger.DEBUG_LOGGER.debug("Insert daily record in DAILY_DATA_AGGREGATION done");
            DailyAppLogger.DEBUG_LOGGER.debug("Start Insert closing record in DAILY_DATA_AGGREGATION ");
            int insertClosingDailyDataAggregation = validationEngineDAOImp.insertClosingDailyDataAggregation(aggregationListRequest.getAggregationLists().get(i));
            DailyAppLogger.DEBUG_LOGGER.debug("Insert closing record in DAILY_DATA_AGGREGATION done");
            DailyAppLogger.DEBUG_LOGGER.debug("Start Insert net adds record in DAILY_DATA_AGGREGATION");
            int insertNetAddsDailyDataAggregation = validationEngineDAOImp.insertNetAddsDailyDataAggregation(aggregationListRequest.getAggregationLists().get(i));
            DailyAppLogger.DEBUG_LOGGER.debug(" Insert net adds record in DAILY_DATA_AGGREGATION done");
            DailyAppLogger.DEBUG_LOGGER.debug("Start Update in VALID_ENGINE_AGGREGATION  ");
            validationEngineDAOImp.updateAdjustFlagInValidEngineAggregation(aggregationListRequest.getAggregationLists().get(i));
            DailyAppLogger.DEBUG_LOGGER.debug(" Update in VALIDATION_ENGINE Done");
            DailyAppLogger.DEBUG_LOGGER.debug("update done ");
        }
    }


    public ByteArrayInputStream loadExcel() {
        List<TransactionModel> transactionModelList = validationEngineDAOImp.GetTransactionType();
        ByteArrayInputStream in = ExcelHelper.buildExcel(transactionModelList);
        return in;
    }

}
