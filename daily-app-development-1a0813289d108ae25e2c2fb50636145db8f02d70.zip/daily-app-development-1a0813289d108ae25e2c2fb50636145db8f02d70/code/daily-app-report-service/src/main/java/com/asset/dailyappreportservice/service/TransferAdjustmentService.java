package com.asset.dailyappreportservice.service;

import com.asset.dailyappreportservice.configuration.Properties;
import com.asset.dailyappreportservice.constants.RatePlanType;
import com.asset.dailyappreportservice.database.dao.imp.ManualAdjustmentDao;
import com.asset.dailyappreportservice.database.dao.imp.TransferAdjustmentDAOImp;
import com.asset.dailyappreportservice.defines.Defines;
import com.asset.dailyappreportservice.defines.ErrorCodes;
import com.asset.dailyappreportservice.exception.ReportsException;
import com.asset.dailyappreportservice.logger.DailyAppLogger;
import com.asset.dailyappreportservice.model.request.AddBatchTransferAdjustmentRequest;
import com.asset.dailyappreportservice.model.request.AddTransferAdjustmentRequest;
import com.asset.dailyappreportservice.model.request.TransferAdjustmentRequest;
import com.asset.dailyappreportservice.model.response.GetAllTransferAdjustment;
import com.asset.dailyappreportservice.model.response.GetTransferAdjustment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TransferAdjustmentService {
    @Autowired
    TransferAdjustmentDAOImp transferAdjustmentDAOImp;
    @Autowired
    private ManualAdjustmentDao dataAggregationDao;
    @Autowired
    private Properties properties;

    public GetAllTransferAdjustment RetrieveAllTransferAdjustment(TransferAdjustmentRequest transferAdjustmentRequeset) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all AllTransferAdjustment ");
        List<GetTransferAdjustment> allTransferAdjustment = transferAdjustmentDAOImp.RetrieveAllTransferAdjustment(transferAdjustmentRequeset);
        if (allTransferAdjustment == null || allTransferAdjustment.isEmpty())
        {
            DailyAppLogger.DEBUG_LOGGER.debug("The Entered Date Has No Aggregated Data");
            DailyAppLogger.ERROR_LOGGER.error("The Entered Date Has No Aggregated Data");
            throw new ReportsException(ErrorCodes.ERROR.DATE_HAS_NO_DATA, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving all AllTransferAdjustment ");

        return new GetAllTransferAdjustment(allTransferAdjustment);


    }

    public void addTransferAdjustment(AddBatchTransferAdjustmentRequest transferAdjustmentRequest) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start adding  batch TransferAdjustment ");


        Integer pgGroupKeyForPostPaid = dataAggregationDao.getPgGroupKeyByPgKey(properties.getPriceGroupKeyForGroupSelectionForPostPaid());
        Integer pgGroupKeyForPrePaid = dataAggregationDao.getPgGroupKeyByPgKey(properties.getPriceGroupKeyForGroupSelectionForPrePaid());

        for (int i = 0; i < transferAdjustmentRequest.getAddTransferAdjustmentRequests().size(); i++) {
            DailyAppLogger.DEBUG_LOGGER.debug("check if rate plan equal null or not  ");
            checkIfRatePlanKeyNull(transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i), i);


            DailyAppLogger.DEBUG_LOGGER.debug("Row number: {}", i);
            DailyAppLogger.DEBUG_LOGGER.debug("getNumberOfSubs: {}", transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i).getNumberOfSubs());
            DailyAppLogger.DEBUG_LOGGER.debug("getMaximumNumberOfSubscriptions: {}", properties.getMaximumNumberOfSubscriptions());
            if (transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i).getNumberOfSubs() > properties.getMaximumNumberOfSubscriptions()) {
                DailyAppLogger.DEBUG_LOGGER.error("Number of Subs Exceeds 3000 in Row Number = {}", i + 1);
                DailyAppLogger.ERROR_LOGGER.error("Number of Subs Exceeds 3000 in Row Number = {}", i + 1);
                throw new ReportsException(ErrorCodes.ERROR.SUBSCRIPTIONS_EXCEEDS_3000, Defines.SEVERITY.ERROR, String.valueOf(i + 1));
            }
            if (transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i).getRatePlanType() == 2) {
                if (pgGroupKeyForPostPaid == null || pgGroupKeyForPostPaid.equals(null)) {
                    DailyAppLogger.DEBUG_LOGGER.debug("check if pgGroupKeyForPostPaid not null");
                    DailyAppLogger.DEBUG_LOGGER.error("pgGroupKeyForPrePaid  null");
                    throw new ReportsException(ErrorCodes.ERROR.PG_GROUP_FOR_PRICE_GROUP_NULL, Defines.SEVERITY.ERROR, "pg group null");
                }
                DailyAppLogger.DEBUG_LOGGER.debug("rate plan type post paid= {}", RatePlanType.POST.getValue());
                transferAdjustmentRequest.getAddTransferAdjustmentRequests().set(i, buildTransferAdjustment(transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i), properties.getPgKeyForPostPaid(), properties.getDwhStatusKeyForPostPaid(), pgGroupKeyForPostPaid, properties.getUserIdForClosing()));
            } else if (transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i).getRatePlanType() == 1) {
                if (pgGroupKeyForPrePaid == null || pgGroupKeyForPrePaid.equals(null)) {
                    DailyAppLogger.DEBUG_LOGGER.debug("check if pgGroupKeyForPrePaid not null");
                    DailyAppLogger.DEBUG_LOGGER.error("pgGroupKeyForPrePaid  null");
                    throw new ReportsException(ErrorCodes.ERROR.PG_GROUP_FOR_PRICE_GROUP_NULL, Defines.SEVERITY.ERROR, "pg group null");
                }
                DailyAppLogger.DEBUG_LOGGER.debug("rate plan type pre paid = {}", RatePlanType.PRE.getValue());
                transferAdjustmentRequest.getAddTransferAdjustmentRequests().set(i, buildTransferAdjustment(transferAdjustmentRequest.getAddTransferAdjustmentRequests().get(i), properties.getPgKeyForPrePaid(), properties.getDwhStatusKeyForPrePaid(), pgGroupKeyForPrePaid, properties.getUserIdForClosing()));

            } else{
                DailyAppLogger.DEBUG_LOGGER.error("Invalid rate plan type");
                DailyAppLogger.ERROR_LOGGER.error("Invalid rate plan type");
                throw new ReportsException(ErrorCodes.ERROR.INVALID_RATE_PLAN_TYPE, Defines.SEVERITY.FATAL, String.valueOf(i+1));
            }
        }

        transferAdjustmentDAOImp.addTransferAdjustment(transferAdjustmentRequest.getAddTransferAdjustmentRequests());
        DailyAppLogger.DEBUG_LOGGER.debug("done adding   batch TransferAdjustment ");
    }

    private void checkIfRatePlanKeyNull(AddTransferAdjustmentRequest transferAdjustmentRequest, int transferAdjustmentRequestIndex) {
        if (transferAdjustmentRequest.getRatePlanKey() == 0) {
            DailyAppLogger.DEBUG_LOGGER.debug("rate plan shouldn't be null  ", transferAdjustmentRequest);
            DailyAppLogger.DEBUG_LOGGER.debug("rate plan shouldn't be null in index  ", transferAdjustmentRequestIndex);
            DailyAppLogger.DEBUG_LOGGER.error("rate plan shouldn't be null  ", transferAdjustmentRequest);
            DailyAppLogger.DEBUG_LOGGER.error("rate plan shouldn't be null in index  ", transferAdjustmentRequestIndex);
            throw new ReportsException(ErrorCodes.ERROR.RATE_PLAN_KEY_NULL, Defines.SEVERITY.ERROR, String.valueOf(transferAdjustmentRequestIndex + 1));
        }
    }

    private AddTransferAdjustmentRequest buildTransferAdjustment(AddTransferAdjustmentRequest transferAdjustmentRequest, Integer pgKey, Integer dwhStatusKey, Integer pgGroupKey, Integer userId) {
        {
            transferAdjustmentRequest.setPgGroupKey(pgGroupKey);
            transferAdjustmentRequest.setPriceGroupKey(pgKey);
            transferAdjustmentRequest.setDwhStatusKey(dwhStatusKey);
            transferAdjustmentRequest.setUserId(userId);
            return transferAdjustmentRequest;
        }
    }
}
