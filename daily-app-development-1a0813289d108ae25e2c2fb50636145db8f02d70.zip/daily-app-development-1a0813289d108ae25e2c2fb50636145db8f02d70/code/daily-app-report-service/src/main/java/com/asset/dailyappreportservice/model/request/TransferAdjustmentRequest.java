package com.asset.dailyappreportservice.model.request;

public class TransferAdjustmentRequest {

    private long date;

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

}
