package com.asset.dailyappusermanagementservice.models.request.user;

import com.asset.dailyappusermanagementservice.models.request.BaseRequest;

import java.io.Serializable;

public class GetAllUsersRequest extends BaseRequest implements Serializable {


}
