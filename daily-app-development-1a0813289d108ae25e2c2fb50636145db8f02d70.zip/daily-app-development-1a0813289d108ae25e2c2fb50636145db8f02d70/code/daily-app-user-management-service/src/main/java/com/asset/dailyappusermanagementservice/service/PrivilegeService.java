package com.asset.dailyappusermanagementservice.service;

import com.asset.dailyappusermanagementservice.database.dao.imp.PrivilegeDAOImp;
import com.asset.dailyappusermanagementservice.defines.Defines;
import com.asset.dailyappusermanagementservice.defines.ErrorCodes;
import com.asset.dailyappusermanagementservice.exception.UserManagementException;
import com.asset.dailyappusermanagementservice.logger.DailyAppLogger;
import com.asset.dailyappusermanagementservice.models.responses.privilege.GetAllPrivilegeResponse;
import com.asset.dailyappusermanagementservice.models.responses.privilege.GetPrivilegeResponse;
import com.asset.dailyappusermanagementservice.models.shared.LkPrivilegeModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PrivilegeService {
    @Autowired
    PrivilegeDAOImp privilegeDAOImp;


    public void addPrivilege(LkPrivilegeModel privilege)throws UserManagementException  {
        DailyAppLogger.DEBUG_LOGGER.debug("Start adding privilege [" + privilege.getName() + "]");
        Integer privilegeId = privilegeDAOImp.add(privilege);
        if (privilegeId == null) {
            DailyAppLogger.DEBUG_LOGGER.error("Failed to add privilege");
            throw new UserManagementException(ErrorCodes.ERROR.UNKNOWN_ERROR, Defines.SEVERITY.ERROR, "privilege");
        }

    }


    public GetPrivilegeResponse retrievePrivilege(Integer privilegeId) throws UserManagementException {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving privilege with id [" + privilegeId + "]");
        LkPrivilegeModel privilegeModel = privilegeDAOImp.get(privilegeId);

        if (privilegeModel == null) {
            DailyAppLogger.DEBUG_LOGGER.debug("privilege with id [" + privilegeId + "] was not found");
            throw new UserManagementException(ErrorCodes.ERROR.PRIVILEGE_NOT_FOUND, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving privilege with id [" + privilegeId + "]");
        return new GetPrivilegeResponse(privilegeModel);
    }
    public GetAllPrivilegeResponse retrieveAllPrivilege()throws UserManagementException  {
        DailyAppLogger.DEBUG_LOGGER.debug("Start retrieving all privileges");
        List<LkPrivilegeModel> privileges = privilegeDAOImp.getAll();
        if (privileges == null || privileges.isEmpty()) {
            DailyAppLogger.DEBUG_LOGGER.error("No privileges found");
            throw new UserManagementException(ErrorCodes.ERROR.PRIVILEGE_NOT_FOUND, Defines.SEVERITY.ERROR);
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Done retrieving all privileges");
        return new GetAllPrivilegeResponse(privileges);
    }


    public void deletePrivilege(Integer privilegeId)throws UserManagementException  {
        DailyAppLogger.DEBUG_LOGGER.debug("Start deleting privilege with ID [" + privilegeId + "]");


         int deleted=  privilegeDAOImp.delete(privilegeId);
        if (deleted <= 0) {
            DailyAppLogger.DEBUG_LOGGER.error("Failed to delete privilege");
            throw new UserManagementException(ErrorCodes.ERROR.DELETE_FAILED, Defines.SEVERITY.ERROR, "privilege");
        }
        DailyAppLogger.DEBUG_LOGGER.debug("deleted privilege successfully");

    }

    public void updatePrivilege(LkPrivilegeModel privilege) {
        DailyAppLogger.DEBUG_LOGGER.debug("Start updating privilege [" + privilege.getName() + "]");
        int updated = privilegeDAOImp.update(privilege);
        if (updated <= 0) {
            DailyAppLogger.DEBUG_LOGGER.error("Failed to update privilege");
            throw new UserManagementException(ErrorCodes.ERROR.UPDATE_FAILED, Defines.SEVERITY.ERROR, "privilege");
        }
        DailyAppLogger.DEBUG_LOGGER.debug("Updated privilege successfully");
    }

    public Integer retrieveProfileByPrivilegeId(Integer privilegeId) {
        DailyAppLogger.DEBUG_LOGGER.debug("Retrieving users with profile ID [" + privilegeId + "]");
        return privilegeDAOImp.retrieveProfileByPrivilegeId(privilegeId);
    }
}
