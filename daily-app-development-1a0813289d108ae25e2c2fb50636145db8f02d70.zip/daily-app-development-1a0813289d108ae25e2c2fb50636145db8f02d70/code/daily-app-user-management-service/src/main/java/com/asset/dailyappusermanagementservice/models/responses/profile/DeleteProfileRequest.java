package com.asset.dailyappusermanagementservice.models.responses.profile;

public class DeleteProfileRequest {
    private Integer profileId;

    public Integer getProfileId() {
        return profileId;
    }

    public void setProfileId(Integer profileId) {
        this.profileId = profileId;
    }
}
