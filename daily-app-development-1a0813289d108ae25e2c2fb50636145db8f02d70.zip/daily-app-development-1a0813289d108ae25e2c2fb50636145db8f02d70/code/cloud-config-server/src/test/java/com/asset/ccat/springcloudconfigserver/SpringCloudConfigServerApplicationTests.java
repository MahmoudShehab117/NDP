package com.asset.ccat.springcloudconfigserver;
class SpringCloudConfigServerApplicationTests {

//	@Test
	void contextLoads() {
	}

}
