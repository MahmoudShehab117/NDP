package com.asset.dailapp.springcloudconfigserver.model.request;

public class UpdateSystemSettingModelRequest {

    private String code;
    private String value;
    private String applicationName;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }
}
