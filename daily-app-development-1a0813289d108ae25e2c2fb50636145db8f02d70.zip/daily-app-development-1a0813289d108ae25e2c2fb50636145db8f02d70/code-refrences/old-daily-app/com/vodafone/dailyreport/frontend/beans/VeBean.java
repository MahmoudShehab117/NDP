package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.dao.VeDao;
import com.vodafone.dailyreport.backend.model.AppUser;
import com.vodafone.dailyreport.backend.model.TotalModel;
import com.vodafone.dailyreport.backend.model.TrxModel;
import com.vodafone.dailyreport.backend.model.VeAggModel;
import com.vodafone.dailyreport.backend.model.VeSearchModel;
import com.vodafone.dailyreport.backend.service.VeService;
import com.vodafone.dailyreport.frontend.util.SessionHelper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import javax.faces.component.UISelectOne;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import org.richfaces.component.UIDatascroller;

public class VeBean
{
/*  26 */   ArrayList veAgg = new ArrayList();
/*  27 */   ArrayList veDe = new ArrayList();
/*  28 */   VeSearchModel searchModel = new VeSearchModel();
/*  29 */   HashMap map = new HashMap();
/*  30 */   HashMap trxMap = new HashMap();
/*  31 */   String msgStr = "";
  private UIDatascroller datascroller2;
/*  33 */   private VeAggModel modelForUpdate = new VeAggModel();
  public String day;
/*  35 */   ArrayList trx = new ArrayList();
  private UISelectOne oneMenuTagSorting;
  private UISelectOne oneMenuTagSorting2;
  long closingAll;
  long openingAll;
  long totalClosing;
  long totalopen;

  private void init()
  {
/*  46 */     this.veAgg = new ArrayList();
/*  47 */     this.veDe = new ArrayList();
/*  48 */     this.searchModel = new VeSearchModel();
/*  49 */     this.map = new HashMap();
/*  50 */     this.trxMap = new HashMap();
/*  51 */     this.msgStr = "";

/*  53 */     this.modelForUpdate = new VeAggModel();
/*  54 */     this.day = "";
/*  55 */     ArrayList trx = new ArrayList();

/*  57 */     this.closingAll = 0L;
/*  58 */     this.openingAll = 0L;
/*  59 */     this.totalClosing = 0L;
/*  60 */     this.totalopen = 0L;
  }

  public long getClosingAll()
  {
/*  67 */     if (this.totalClosing == 0L) {
/*  68 */       this.totalClosing = VeService.getDao().getTotalTrx(this.day).getClosing();
              }
/*  70 */     this.closingAll = this.totalClosing;
/*  71 */     Iterator it = this.veAgg.iterator();
/*  72 */     while (it.hasNext()) {
/*  73 */       VeAggModel aggModel = (VeAggModel)it.next();
/*  74 */       if (aggModel.isInApply()) {
/*  75 */         this.closingAll += Math.abs(aggModel.getInSubs()) * aggModel.getInTrxModel().getValue();
                }
/*  77 */       if (aggModel.isOutApply()) {
/*  78 */         this.closingAll += Math.abs(aggModel.getOutSubs()) * aggModel.getOutTrxModel().getValue();
                }
              }

/*  82 */     return this.closingAll;
  }

  public void setClosingAll(long closingAll)
  {
/*  90 */     this.closingAll = closingAll;
  }

  public long getOpeningAll()
  {
/*  97 */     if (this.totalopen == 0L) {
/*  98 */       this.totalopen = VeService.getDao().getTotalTrx(this.day).getOpening();
              }
/* 100 */     this.openingAll = this.totalopen;
/* 101 */     return this.openingAll;
  }

  public void setOpeningAll(long openingAll)
  {
/* 108 */     this.openingAll = openingAll;
  }

  public ArrayList getTrx()
  {
/* 118 */     return this.trx;
  }

  public void setTrx(ArrayList trx)
  {
/* 125 */     this.trx = trx;
  }

  public String getDay()
  {
/* 132 */     return this.day;
  }

  public void setDay(String day)
  {
/* 139 */     this.day = day;
  }

  public UIDatascroller getDatascroller2() {
/* 143 */     return this.datascroller2;
  }

  public void setDatascroller2(UIDatascroller datascroller2) {
/* 147 */     this.datascroller2 = datascroller2;
  }

  public HashMap getMap() {
/* 151 */     return this.map;
  }

  public void setMap(HashMap map) {
/* 155 */     this.map = map;
  }

  public String getMsgStr() {
/* 159 */     return this.msgStr;
  }

  public void setMsgStr(String msgStr) {
/* 163 */     this.msgStr = msgStr;
  }

  public VeSearchModel getSearchModel() {
/* 167 */     return this.searchModel;
  }

  public void setSearchModel(VeSearchModel searchModel) {
/* 171 */     this.searchModel = searchModel;
  }

  public ArrayList getVeDe() {
/* 175 */     return this.veDe;
  }

  public void setVeDe(ArrayList veDe) {
/* 179 */     this.veDe = veDe;
  }

  public void setVeAgg(ArrayList veAgg) {
/* 183 */     this.veAgg = veAgg;
  }

  public String getVeAggregation()
  {
/* 188 */     ArrayList temp = new ArrayList();
/* 189 */     this.veAgg = new ArrayList();
/* 190 */     this.totalopen = 0L;
/* 191 */     this.totalClosing = 0L;
/* 192 */     temp = VeService.getDao().getOriginalVeData(this.day);
/* 193 */     Iterator it = temp.iterator();
/* 194 */     int counter = 0;
/* 195 */     while (it.hasNext()) {
/* 196 */       VeAggModel aggModel = (VeAggModel)it.next();
/* 197 */       counter++;
                aggModel.setSeq(String.valueOf(counter));
/* 198 */       this.veAgg.add(aggModel);
/* 199 */       this.map.put(new Integer(aggModel.getRatePlanKey()), aggModel);
                }

/* 202 */     if (this.trx.size() == 0) {
/* 203 */       HashMap map = new HashMap();
/* 204 */       this.trx = new ArrayList();
/* 205 */       ArrayList list = VeService.getDao().getTrx();
/* 206 */       Iterator it2 = list.iterator();
/* 207 */       while (it2.hasNext()) {
/* 208 */         TrxModel trxModel = (TrxModel)it2.next();
/* 209 */         this.trxMap.put(String.valueOf(trxModel.getKey()), trxModel);
/* 210 */         SelectItem selectItem = new SelectItem();
/* 211 */         selectItem.setLabel(trxModel.getName());
/* 212 */         selectItem.setValue(new Integer(trxModel.getKey()));
/* 213 */         this.trx.add(selectItem);
      }
    }
/* 216 */     return "vfagg";
  }

  public void adjust(ActionEvent ae)
  {
/* 223 */     Iterator it = this.veAgg.iterator();
/* 224 */     VeAggModel temp = null;

/* 226 */     Collection list = this.map.values();
/* 227 */     Iterator tt = list.iterator();
/* 228 */     while (tt.hasNext()) {
/* 229 */       VeAggModel aggModel = (VeAggModel)tt.next();
/* 230 */       aggModel.setCloseFinal(0L);
              }
/* 232 */     while (it.hasNext()) {
/* 233 */       VeAggModel model = (VeAggModel)it.next();
/* 234 */       if (model.isInApply()) {
/* 235 */         TrxModel model2 = (TrxModel)this.trxMap.get(model.getInAdjustType());

/* 238 */         model.setInTrxModel(model2);
                } else {
/* 240 */         model.setInTrxModel(null);
                }
/* 242 */       if (model.isOutApply()) {
/* 243 */         TrxModel model2 = (TrxModel)this.trxMap.get(model.getOutAdjustType());
/* 244 */         model.setOutTrxModel(model2);
                }
                else {
/* 247 */         model.setOutTrxModel(null);
                }

/* 251 */       temp = (VeAggModel)this.map.get(new Integer(model.getRatePlanKey()));
/* 252 */       if (model.getOutTrxModel() != null) {
                  int t = temp.getClose() +  model.getOutTrxModel().getValue() * Math.abs(model.getOutSubs());
/* 253 */         temp.setCloseFinal(t);
                }

/* 258 */       if (model.getInTrxModel() != null) {
                 int t = temp.getClose() + model.getInTrxModel().getValue() * Math.abs(model.getInSubs());
/* 259 */         temp.setCloseFinal(t);
                }

    }

/* 272 */     Iterator it2 = this.veAgg.iterator();
/* 273 */     VeAggModel temp1 = null;
/* 274 */     while (it2.hasNext()) {
/* 275 */       VeAggModel model = (VeAggModel)it2.next();

/* 277 */       temp1 = (VeAggModel)this.map.get(new Integer(model.getRatePlanKey()));
/* 278 */       model.setCloseFinal(temp1.getCloseFinal());
    }
  }

  public String submit()
  {
/* 292 */     Iterator it = this.veAgg.iterator();

/* 294 */     while (it.hasNext()) {
/* 295 */       VeAggModel model = (VeAggModel)it.next();
/* 296 */       if (model.isInApply()) {
/* 297 */         TrxModel model2 = (TrxModel)this.trxMap.get(model.getInAdjustType());
/* 298 */         model.setInTrxModel(model2);
      } else {
/* 300 */         model.setInTrxModel(null);
      }
/* 302 */       if (model.isOutApply()) {
/* 303 */         TrxModel model2 = (TrxModel)this.trxMap.get(model.getOutAdjustType());
/* 304 */         model.setOutTrxModel(model2);
      }
      else {
/* 307 */         model.setOutTrxModel(null);
      }

    }

/* 316 */     VeService.getDao().insertDeVeData(this.veAgg);
/* 317 */     VeService.getDao().insertPerContracData(this.veAgg);
/* 318 */     VeService.getDao().insertDaily(SessionHelper.getLoginBean().getUserModel().getUserKey(), ((VeAggModel)this.veAgg.get(0)).getDateKey());
/* 319 */     VeService.getDao().insertClosing(SessionHelper.getLoginBean().getUserModel().getUserKey(), ((VeAggModel)this.veAgg.get(0)).getDateKey());
/* 320 */     VeService.getDao().insertNetAdds(SessionHelper.getLoginBean().getUserModel().getUserKey(), ((VeAggModel)this.veAgg.get(0)).getDateKey());

/* 322 */     VeService.getDao().commitAdjustment(this.veAgg);

/* 325 */     ArrayList temp = new ArrayList();
/* 326 */     this.veAgg = new ArrayList();
/* 327 */     this.totalopen = 0L;
/* 328 */     this.totalClosing = 0L;
/* 329 */     this.veAgg = new ArrayList();
/* 330 */     this.map = new HashMap();
/* 331 */     temp = VeService.getDao().getOriginalVeData(this.day);
/* 332 */     Iterator it2 = temp.iterator();
/* 333 */     int counter = 0;
/* 334 */     while (it2.hasNext()) {
/* 335 */       VeAggModel aggModel = (VeAggModel)it2.next();
/* 336 */       counter++; aggModel.setSeq(String.valueOf(counter));
/* 337 */       this.veAgg.add(aggModel);
/* 338 */       this.map.put(new Integer(aggModel.getRatePlanKey()), aggModel);
    }

/* 341 */     if (this.trx.size() == 0) {
/* 342 */       HashMap map = new HashMap();
/* 343 */       this.trx = new ArrayList();
/* 344 */       ArrayList list = VeService.getDao().getTrx();
/* 345 */       Iterator it3 = list.iterator();
/* 346 */       while (it3.hasNext()) {
/* 347 */         TrxModel trxModel = (TrxModel)it3.next();
/* 348 */         this.trxMap.put(String.valueOf(trxModel.getKey()), trxModel);
/* 349 */         SelectItem selectItem = new SelectItem();
/* 350 */         selectItem.setLabel(trxModel.getName());
/* 351 */         selectItem.setValue(new Integer(trxModel.getKey()));
/* 352 */         this.trx.add(selectItem);
      }
    }

/* 356 */     return "vfagg";
  }

  public String returns()
  {
/* 362 */     return "resturn";
  }

  public ArrayList getVeAgg()
  {
/* 367 */     return this.veAgg;
  }

  public VeAggModel getModelForUpdate() {
/* 371 */     return this.modelForUpdate;
  }

  public void setModelForUpdate(VeAggModel modelForUpdate) {
/* 375 */     this.modelForUpdate = modelForUpdate;
  }

  public UISelectOne getOneMenuTagSorting()
  {
/* 383 */     return this.oneMenuTagSorting;
  }

  public void setOneMenuTagSorting(UISelectOne oneMenuTagSorting)
  {
/* 390 */     this.oneMenuTagSorting = oneMenuTagSorting;
  }

  public UISelectOne getOneMenuTagSorting2()
  {
/* 397 */     return this.oneMenuTagSorting2;
  }

  public void setOneMenuTagSorting2(UISelectOne oneMenuTagSorting2)
  {
/* 404 */     this.oneMenuTagSorting2 = oneMenuTagSorting2;
  }

  public HashMap getTrxMap()
  {
/* 411 */     return this.trxMap;
  }

  public void setTrxMap(HashMap trxMap)
  {
/* 418 */     this.trxMap = trxMap;
  }
}