/*    */ package com.vodafone.dailyreport.frontend.beans;
/*    */ 
/*    */ public class GroupSearchBean
/*    */ {
/*    */   private String name;
/*    */   private boolean show;
/*    */ 
/*    */   public String getName()
/*    */   {
/*  8 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 12 */     this.name = name;
/*    */   }
/*    */   public boolean isShow() {
/* 15 */     return this.show;
/*    */   }
/*    */   public void setShow(boolean show) {
/* 18 */     this.show = show;
/*    */   }
/*    */ }