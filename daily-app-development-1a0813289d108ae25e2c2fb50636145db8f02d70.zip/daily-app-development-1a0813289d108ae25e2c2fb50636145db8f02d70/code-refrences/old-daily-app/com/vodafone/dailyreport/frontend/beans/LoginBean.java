/*    */ package com.vodafone.dailyreport.frontend.beans;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.UserManagmentDao;
/*    */ import com.vodafone.dailyreport.backend.model.AppUser;
/*    */ import com.vodafone.dailyreport.backend.service.UserManagmentService;
/*    */ import java.io.PrintStream;
/*    */ import javax.faces.application.FacesMessage;
/*    */ import javax.faces.context.ExternalContext;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LoginBean
/*    */ {
/* 18 */   public static Logger logger = Logger.getLogger(LoginBean.class.getName());
/*    */   private String username;
/*    */   private String password;
/*    */   private AppUser userModel;
/*    */ 
/*    */   public String getPassword()
/*    */   {
/* 27 */     return this.password;
/*    */   }
/*    */ 
/*    */   public void setPassword(String password)
/*    */   {
/* 33 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public AppUser getUserModel()
/*    */   {
/* 40 */     return this.userModel;
/*    */   }
/*    */ 
/*    */   public void setUserModel(AppUser userModel)
/*    */   {
/* 46 */     this.userModel = userModel;
/*    */   }
/*    */ 
/*    */   public String getUsername()
/*    */   {
/* 52 */     return this.username;
/*    */   }
/*    */ 
/*    */   public void setUsername(String username)
/*    */   {
/* 58 */     this.username = username;
/*    */   }
/*    */ 
/*    */   public String login()
/*    */   {
/* 65 */     this.userModel = UserManagmentService.getDao().checkUser(this.username);
/* 66 */     if (this.userModel == null) {
/* 67 */       FacesContext.getCurrentInstance().addMessage("deviceForm:propertyTag", new FacesMessage(FacesMessage.SEVERITY_WARN, "Username or password is wrong ..", ""));
/* 68 */       return null;
/* 69 */     }if (!this.password.equals(this.userModel.getPassword())) {
/* 70 */       FacesContext.getCurrentInstance().addMessage("deviceForm:propertyTag", new FacesMessage(FacesMessage.SEVERITY_WARN, "Username or password is wrong ..", ""));
/* 71 */       return null;
/*    */     }
/*    */ 
/* 74 */     HttpServletRequest httpRequest = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
/* 75 */     String userIpAddress = httpRequest.getHeader("X-Forwarded-For");
/* 76 */     String remoteIpAddress = httpRequest.getRemoteAddr();
/* 77 */     System.out.println("login -INFO- X-Forwarded-For IP:" + userIpAddress);
/* 78 */     System.out.println("login -INFO- Remote Adress IP:" + remoteIpAddress);
/* 79 */     logger.info("login -INFO- Currently logged in user:" + this.userModel.getName());
/* 80 */     logger.info("login -INFO- X-Forwarded-For IP:" + userIpAddress);
/* 81 */     logger.info("login -INFO- Remote Adress IP:" + remoteIpAddress);
/*    */ 
/* 88 */     return "client";
/*    */   }
/*    */ }