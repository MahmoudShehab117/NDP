/*    */ package com.vodafone.dailyreport.frontend.util;
/*    */ 
/*    */ import com.vodafone.dailyreport.frontend.beans.LoginBean;
/*    */ import com.vodafone.dailyreport.frontend.beans.VeBean;
/*    */ import javax.faces.context.ExternalContext;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class SessionHelper
/*    */ {
/*    */   public static HttpSession getSession()
/*    */   {
/* 23 */     FacesContext ctx = FacesContext.getCurrentInstance();
/* 24 */     ExternalContext app = ctx.getExternalContext();
/* 25 */     HttpSession session = (HttpSession)app.getSession(false);
/* 26 */     return session;
/*    */   }
/*    */ 
/*    */   public static LoginBean getLoginBean()
/*    */   {
/* 33 */     FacesContext ctx = FacesContext.getCurrentInstance();
/* 34 */     ExternalContext app = ctx.getExternalContext();
/* 35 */     HttpSession session = (HttpSession)app.getSession(false);
/*    */ 
/* 37 */     LoginBean loginbean = (LoginBean)session.getAttribute("loginbean");
/* 38 */     if (loginbean == null) {
/* 39 */       loginbean = new LoginBean();
/* 40 */       session.setAttribute("loginbean", loginbean);
/*    */     }
/* 42 */     return loginbean;
/*    */   }
/*    */ 
/*    */   public static VeBean getVeBean()
/*    */   {
/* 47 */     FacesContext ctx = FacesContext.getCurrentInstance();
/* 48 */     ExternalContext app = ctx.getExternalContext();
/* 49 */     HttpSession session = (HttpSession)app.getSession(false);
/*    */ 
/* 51 */     VeBean veBean = (VeBean)session.getAttribute("vebean");
/* 52 */     if (veBean == null) {
/* 53 */       veBean = new VeBean();
/* 54 */       session.setAttribute("vebean", veBean);
/*    */     }
/* 56 */     return veBean;
/*    */   }
/*    */ 
/*    */   public static HttpServletRequest getRequest()
/*    */   {
/* 63 */     FacesContext ctx = FacesContext.getCurrentInstance();
/* 64 */     ExternalContext app = ctx.getExternalContext();
/* 65 */     HttpServletRequest request = (HttpServletRequest)app.getRequest();
/* 66 */     return request;
/*    */   }
/*    */ 
/*    */   public static HttpServletResponse getResponce()
/*    */   {
/* 73 */     FacesContext ctx = FacesContext.getCurrentInstance();
/* 74 */     ExternalContext app = ctx.getExternalContext();
/* 75 */     HttpServletResponse responce = (HttpServletResponse)app.getResponse();
/* 76 */     return responce;
/*    */   }
/*    */ }