package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.dao.RatePlanDao;
import com.vodafone.dailyreport.backend.model.SearchModel;
import com.vodafone.dailyreport.backend.model.ServiceClass;
import com.vodafone.dailyreport.backend.model.TariffModel;
import com.vodafone.dailyreport.backend.service.RatePlanService;
import com.vodafone.dailyreport.backend.util.SendMail;
import java.util.ArrayList;
import java.util.Iterator;
import javax.faces.event.ActionEvent;
import org.apache.log4j.Logger;
import org.richfaces.component.UIDatascroller;

public class MainBean
{
/*  25 */   private ArrayList serviceClasses = new ArrayList();
/*  26 */   private ArrayList tariffs = new ArrayList();
/*  27 */   private ArrayList bundleTypes = new ArrayList();
/*  28 */   private String msgStr = "";
/*  29 */   private SearchBean searchBean = new SearchBean();
  private UIDatascroller datascroller2;
  private UIDatascroller datascroller3;
/*  33 */   private ArrayList oldServiceClasses = null;
/*  34 */   private ArrayList oldTariffs = null;

/*  37 */   Logger logger = Logger.getLogger(MainBean.class);

  public UIDatascroller getDatascroller2()
  {
/*  41 */     return this.datascroller2;
  }

  public void initalizeScroll() {
/*  45 */     this.datascroller2.setPage("1");
/*  46 */     this.datascroller3.setPage("1");
  }

  public String search()
  {
/*  51 */     initalizeScroll();
/*  52 */     String activation = this.searchBean.getActivationSource();
/*  53 */     String ctype = this.searchBean.getCType();

/*  55 */     if (ctype == null) {
/*  56 */       ctype = "0";
    }

/*  59 */     String name = this.searchBean.getName();
/*  60 */     String bundleType = this.searchBean.getBundleType();
/*  61 */     this.logger.debug("Search name : " + name + "  , Bundle Type : " + bundleType);
/*  62 */     String type = this.searchBean.getType();

/*  64 */     if (type == null)
/*  65 */       type = "0";
/*  66 */     if (activation == null)
/*  67 */       activation = "0";
/*  68 */     if (bundleType == null) {
/*  69 */       bundleType = "";
    }
/*  71 */     ArrayList searchesSC = new ArrayList();
/*  72 */     ArrayList searchesTM = new ArrayList();
/*  73 */     if ((name == null) || (name.equals("")))
    {
/*  76 */       name = "All";
    }
/*  78 */     if (ctype.equals("1")) {
/*  79 */       SearchModel model = new SearchModel();
/*  80 */       model.setAtt(BackEndConstants.CONSUMER);
/*  81 */       model.setValue(true);
/*  82 */       searchesSC.add(model);
/*  83 */     } else if (ctype.equals("2")) {
/*  84 */       SearchModel model = new SearchModel();
/*  85 */       model.setAtt(BackEndConstants.ENT);
/*  86 */       model.setValue(true);
/*  87 */       searchesSC.add(model);
    }
/*  89 */     else if (ctype.equals("3")) {
/*  90 */       SearchModel model = new SearchModel();
/*  91 */       model.setAtt(BackEndConstants.ENT);
/*  92 */       model.setEmpty(true);
/*  93 */       searchesSC.add(model);
/*  94 */       SearchModel model2 = new SearchModel();
/*  95 */       model2.setAtt(BackEndConstants.CONSUMER);
/*  96 */       model2.setEmpty(true);
/*  97 */       searchesSC.add(model2);
    }

/* 100 */     if (type.equals("1")) {
/* 101 */       SearchModel model = new SearchModel();
/* 102 */       model.setAtt(BackEndConstants.PRE);
/* 103 */       model.setValue(true);
/* 104 */       searchesSC.add(model);
/* 105 */     } else if (type.equals("2")) {
/* 106 */       SearchModel model = new SearchModel();
/* 107 */       model.setAtt(BackEndConstants.POST);
/* 108 */       model.setValue(true);
/* 109 */       searchesSC.add(model);
/* 110 */     } else if (type.equals("3")) {
/* 111 */       SearchModel model = new SearchModel();
/* 112 */       model.setAtt(BackEndConstants.PRE);
/* 113 */       model.setEmpty(true);
/* 114 */       searchesSC.add(model);
/* 115 */       SearchModel model2 = new SearchModel();
/* 116 */       model2.setAtt(BackEndConstants.POST);
/* 117 */       model2.setEmpty(true);
/* 118 */       searchesSC.add(model2);
/* 119 */     } else if (type.equals("4")) {
/* 120 */       SearchModel model = new SearchModel();
/* 121 */       model.setAtt(BackEndConstants.HYBIRD);
/* 122 */       model.setValue(true);
/* 123 */       searchesSC.add(model);
    }

/* 126 */     if (type.equals("1")) {
/* 127 */       SearchModel model = new SearchModel();
/* 128 */       model.setAtt(BackEndConstants.PRE);
/* 129 */       model.setValue(true);
/* 130 */       searchesTM.add(model);
/* 131 */     } else if (type.equals("2")) {
/* 132 */       SearchModel model = new SearchModel();
/* 133 */       model.setAtt(BackEndConstants.POST);
/* 134 */       model.setValue(true);
/* 135 */       searchesTM.add(model);
    }
/* 137 */     else if (type.equals("3")) {
/* 138 */       SearchModel model = new SearchModel();
/* 139 */       model.setAtt(BackEndConstants.PRE);
/* 140 */       model.setEmpty(true);
/* 141 */       searchesTM.add(model);
/* 142 */       SearchModel model2 = new SearchModel();
/* 143 */       model2.setAtt(BackEndConstants.POST);
/* 144 */       model2.setEmpty(true);
/* 145 */       searchesTM.add(model2);
/* 146 */     } else if (type.equals("4")) {
/* 147 */       SearchModel model = new SearchModel();
/* 148 */       model.setAtt(BackEndConstants.HYBIRD);
/* 149 */       model.setValue(true);
/* 150 */       searchesTM.add(model);
    }

/* 154 */     if (ctype.equals("1")) {
/* 155 */       SearchModel model2 = new SearchModel();
/* 156 */       model2.setAtt(BackEndConstants.CONSUMER);
/* 157 */       model2.setValue(true);
/* 158 */       searchesTM.add(model2);
/* 159 */     } else if (ctype.equals("2")) {
/* 160 */       SearchModel model2 = new SearchModel();
/* 161 */       model2.setAtt(BackEndConstants.ENT);
/* 162 */       model2.setValue(true);
/* 163 */       searchesTM.add(model2);
    }
/* 165 */     else if (ctype.equals("3")) {
/* 166 */       SearchModel model = new SearchModel();
/* 167 */       model.setAtt(BackEndConstants.CONSUMER);
/* 168 */       model.setEmpty(true);
/* 169 */       searchesTM.add(model);
/* 170 */       SearchModel model2 = new SearchModel();
/* 171 */       model2.setAtt(BackEndConstants.ENT);
/* 172 */       model2.setEmpty(true);
/* 173 */       searchesTM.add(model2);
    }

/* 176 */     if (activation.equals("1")) {
/* 177 */       SearchModel model2 = new SearchModel();
/* 178 */       model2.setAtt(BackEndConstants.SOURCE);
/* 179 */       model2.setValue(true);
/* 180 */       searchesTM.add(model2);
/* 181 */       searchesSC.add(model2);
/* 182 */     } else if (activation.equals("2")) {
/* 183 */       SearchModel model2 = new SearchModel();
/* 184 */       model2.setAtt(BackEndConstants.SOURCE);
/* 185 */       model2.setValue(false);
/* 186 */       searchesTM.add(model2);
/* 187 */       searchesSC.add(model2);
    }

/* 190 */     this.serviceClasses = RatePlanService.getDao().getServiceClassByFlag(name, bundleType, searchesSC);
/* 191 */     this.tariffs = RatePlanService.getDao().getTariffModelbyFlag(name, bundleType, searchesTM);

/* 193 */     this.msgStr = "";
/* 194 */     return "cleint";
  }

  public String clear()
  {
/* 202 */     this.searchBean = new SearchBean();
/* 203 */     return "cleint";
  }

  public String apply()
  {
/* 208 */     getOldData();

/* 210 */     String serviceClass = "";
/* 211 */     String tarrifs = "";

/* 213 */     RatePlanService.getDao().updateServicClass(this.serviceClasses);
/* 214 */     RatePlanService.getDao().updateTariffs(this.tariffs);

/* 218 */     Iterator iter1 = this.oldServiceClasses.iterator();
/* 219 */     Iterator iter2 = this.serviceClasses.iterator();
/* 220 */     int i = 1;
/* 221 */     label315: while (iter1.hasNext())
    {
/* 223 */       ServiceClass oldServiceClass = (ServiceClass)iter1.next();
/* 224 */       ServiceClass newServiceClass = (ServiceClass)iter2.next();

/* 226 */       if (!oldServiceClass.getScName().equals(newServiceClass.getScName()))
        continue;
/* 228 */       if ((!oldServiceClass.isScPre()) != newServiceClass.isScPre())
/* 229 */         if ((!oldServiceClass.isScPost()) != newServiceClass.isScPost())
/* 230 */           if ((!oldServiceClass.isScHybird()) != newServiceClass.isScHybird())
/* 231 */             if ((!oldServiceClass.isScConsumer()) != newServiceClass.isScConsumer())
/* 232 */               if ((!oldServiceClass.isScEnt()) != newServiceClass.isScEnt())
/* 233 */                 if ((!oldServiceClass.isActivationSource()) != newServiceClass.isActivationSource())
/* 234 */                   if (((!oldServiceClass.isDeacSource()) != newServiceClass.isDeacSource()) && 
/* 235 */                     (oldServiceClass.getBundleType().equals(newServiceClass.getBundleType()))) break label315;
/* 237 */       if (i == 1)
/* 238 */         serviceClass = serviceClass + oldServiceClass.getScName();
      else {
/* 240 */         serviceClass = serviceClass + " , " + oldServiceClass.getScName();
      }

/* 243 */       i++;
    }

/* 249 */     Iterator iter3 = this.oldTariffs.iterator();
/* 250 */     Iterator iter4 = this.tariffs.iterator();
/* 251 */     int j = 1;
/* 252 */     label614: while (iter3.hasNext())
    {
/* 254 */       TariffModel oldTariff = (TariffModel)iter3.next();
/* 255 */       TariffModel newTariff = (TariffModel)iter4.next();

/* 257 */       if (!oldTariff.getTmName().equals(newTariff.getTmName()))
        continue;
/* 259 */       if ((!oldTariff.isTmPre()) != newTariff.isTmPre())
/* 260 */         if ((!oldTariff.isTmPost()) != newTariff.isTmPost())
/* 261 */           if ((!oldTariff.isTmHybird()) != newTariff.isTmHybird())
/* 262 */             if ((!oldTariff.isTmConsumer()) != newTariff.isTmConsumer())
/* 263 */               if ((!oldTariff.isTmEnt()) != newTariff.isTmEnt())
/* 264 */                 if ((!oldTariff.isActivationSource()) != newTariff.isActivationSource())
/* 265 */                   if (((!oldTariff.isDeacSource()) != newTariff.isDeacSource()) && 
/* 266 */                     (oldTariff.getBundleType().equals(newTariff.getBundleType())))
                    break label614;
/* 269 */       if (j == 1)
/* 270 */         tarrifs = tarrifs + oldTariff.getTmName();
      else {
/* 272 */         tarrifs = tarrifs + " , " + oldTariff.getTmName();
      }

/* 275 */       j++;
    }

    try
    {
/* 283 */       String subject = "";
/* 284 */       if ((!tarrifs.equals("")) && (!serviceClass.equals("")))
/* 285 */         subject = "Dear Team,\n\n \t Kindly check declarations of new RatePlans: " + serviceClass + " ** and Tarrifs: " + tarrifs + ".\n\nBr,\nDWH Team";
/* 286 */       else if ((tarrifs.equals("")) && (!serviceClass.equals("")))
/* 287 */         subject = "Dear Team,\n\n \t Kindly check declarations of new RatePlans: " + serviceClass + ".\n\nBr,\nDWH Team";
/* 288 */       else if ((!tarrifs.equals("")) && (serviceClass.equals(""))) {
/* 289 */         subject = "Dear Team,\n\n \t Kindly check declarations of new Tarrifs: " + tarrifs + ".\n\nBr,\nDWH Team";
      }

/* 292 */       SendMail.sendMail(null, "Daily Report Updates", subject);
    }
    catch (Exception e)
    {
/* 296 */       e.printStackTrace();
    }
/* 298 */     this.msgStr = "All Record Successfully Updates";
/* 299 */     this.logger.debug("All Record Successfully Updates");
/* 300 */     return "cleint";
  }

  public void getOldData()
  {
/* 307 */     String activation = this.searchBean.getActivationSource();
/* 308 */     String ctype = this.searchBean.getCType();

/* 310 */     if (ctype == null) {
/* 311 */       ctype = "0";
    }

/* 314 */     String name = this.searchBean.getName();
/* 315 */     String bundleType = this.searchBean.getBundleType();
/* 316 */     this.logger.debug("Search name : " + name + "  , Bundle Type : " + bundleType);
/* 317 */     String type = this.searchBean.getType();

/* 319 */     if (type == null)
/* 320 */       type = "0";
/* 321 */     if (activation == null)
/* 322 */       activation = "0";
/* 323 */     if (bundleType == null) {
/* 324 */       bundleType = "";
    }
/* 326 */     ArrayList searchesSC = new ArrayList();
/* 327 */     ArrayList searchesTM = new ArrayList();
/* 328 */     if ((name == null) || (name.equals("")))
    {
/* 331 */       name = "All";
    }
/* 333 */     if (ctype.equals("1")) {
/* 334 */       SearchModel model = new SearchModel();
/* 335 */       model.setAtt(BackEndConstants.CONSUMER);
/* 336 */       model.setValue(true);
/* 337 */       searchesSC.add(model);
/* 338 */     } else if (ctype.equals("2")) {
/* 339 */       SearchModel model = new SearchModel();
/* 340 */       model.setAtt(BackEndConstants.ENT);
/* 341 */       model.setValue(true);
/* 342 */       searchesSC.add(model);
    }
/* 344 */     else if (ctype.equals("3")) {
/* 345 */       SearchModel model = new SearchModel();
/* 346 */       model.setAtt(BackEndConstants.ENT);
/* 347 */       model.setEmpty(true);
/* 348 */       searchesSC.add(model);
/* 349 */       SearchModel model2 = new SearchModel();
/* 350 */       model2.setAtt(BackEndConstants.CONSUMER);
/* 351 */       model2.setEmpty(true);
/* 352 */       searchesSC.add(model2);
    }

/* 355 */     if (type.equals("1")) {
/* 356 */       SearchModel model = new SearchModel();
/* 357 */       model.setAtt(BackEndConstants.PRE);
/* 358 */       model.setValue(true);
/* 359 */       searchesSC.add(model);
/* 360 */     } else if (type.equals("2")) {
/* 361 */       SearchModel model = new SearchModel();
/* 362 */       model.setAtt(BackEndConstants.POST);
/* 363 */       model.setValue(true);
/* 364 */       searchesSC.add(model);
/* 365 */     } else if (type.equals("3")) {
/* 366 */       SearchModel model = new SearchModel();
/* 367 */       model.setAtt(BackEndConstants.PRE);
/* 368 */       model.setEmpty(true);
/* 369 */       searchesSC.add(model);
/* 370 */       SearchModel model2 = new SearchModel();
/* 371 */       model2.setAtt(BackEndConstants.POST);
/* 372 */       model2.setEmpty(true);
/* 373 */       searchesSC.add(model2);
/* 374 */     } else if (type.equals("4")) {
/* 375 */       SearchModel model = new SearchModel();
/* 376 */       model.setAtt(BackEndConstants.HYBIRD);
/* 377 */       model.setValue(true);
/* 378 */       searchesSC.add(model);
    }

/* 381 */     if (type.equals("1")) {
/* 382 */       SearchModel model = new SearchModel();
/* 383 */       model.setAtt(BackEndConstants.PRE);
/* 384 */       model.setValue(true);
/* 385 */       searchesTM.add(model);
/* 386 */     } else if (type.equals("2")) {
/* 387 */       SearchModel model = new SearchModel();
/* 388 */       model.setAtt(BackEndConstants.POST);
/* 389 */       model.setValue(true);
/* 390 */       searchesTM.add(model);
    }
/* 392 */     else if (type.equals("3")) {
/* 393 */       SearchModel model = new SearchModel();
/* 394 */       model.setAtt(BackEndConstants.PRE);
/* 395 */       model.setEmpty(true);
/* 396 */       searchesTM.add(model);
/* 397 */       SearchModel model2 = new SearchModel();
/* 398 */       model2.setAtt(BackEndConstants.POST);
/* 399 */       model2.setEmpty(true);
/* 400 */       searchesTM.add(model2);
/* 401 */     } else if (type.equals("4")) {
/* 402 */       SearchModel model = new SearchModel();
/* 403 */       model.setAtt(BackEndConstants.HYBIRD);
/* 404 */       model.setValue(true);
/* 405 */       searchesTM.add(model);
    }

/* 409 */     if (ctype.equals("1")) {
/* 410 */       SearchModel model2 = new SearchModel();
/* 411 */       model2.setAtt(BackEndConstants.CONSUMER);
/* 412 */       model2.setValue(true);
/* 413 */       searchesTM.add(model2);
/* 414 */     } else if (ctype.equals("2")) {
/* 415 */       SearchModel model2 = new SearchModel();
/* 416 */       model2.setAtt(BackEndConstants.ENT);
/* 417 */       model2.setValue(true);
/* 418 */       searchesTM.add(model2);
    }
/* 420 */     else if (ctype.equals("3")) {
/* 421 */       SearchModel model = new SearchModel();
/* 422 */       model.setAtt(BackEndConstants.CONSUMER);
/* 423 */       model.setEmpty(true);
/* 424 */       searchesTM.add(model);
/* 425 */       SearchModel model2 = new SearchModel();
/* 426 */       model2.setAtt(BackEndConstants.ENT);
/* 427 */       model2.setEmpty(true);
/* 428 */       searchesTM.add(model2);
    }

/* 431 */     if (activation.equals("1")) {
/* 432 */       SearchModel model2 = new SearchModel();
/* 433 */       model2.setAtt(BackEndConstants.SOURCE);
/* 434 */       model2.setValue(true);
/* 435 */       searchesTM.add(model2);
/* 436 */       searchesSC.add(model2);
/* 437 */     } else if (activation.equals("2")) {
/* 438 */       SearchModel model2 = new SearchModel();
/* 439 */       model2.setAtt(BackEndConstants.SOURCE);
/* 440 */       model2.setValue(false);
/* 441 */       searchesTM.add(model2);
/* 442 */       searchesSC.add(model2);
    }

/* 446 */     this.oldServiceClasses = RatePlanService.getDao().getServiceClassByFlag(name, bundleType, searchesSC);
/* 447 */     this.oldTariffs = RatePlanService.getDao().getTariffModelbyFlag(name, bundleType, searchesTM);
  }

  public SearchBean getSearchBean() {
/* 451 */     return this.searchBean;
  }

  public void setSearchBean(SearchBean searchBean) {
/* 455 */     this.searchBean = searchBean;
  }

  public void setDatascroller2(UIDatascroller datascroller2) {
/* 459 */     this.datascroller2 = datascroller2;
  }

  public UIDatascroller getDatascroller3()
  {
/* 466 */     return this.datascroller3;
  }

  public void setDatascroller3(UIDatascroller datascroller3)
  {
/* 473 */     this.datascroller3 = datascroller3;
  }

  public ArrayList getTariffs()
  {
/* 481 */     return this.tariffs;
  }

  public void setTariffs(ArrayList tariffs)
  {
/* 489 */     this.tariffs = tariffs;
  }

  public ArrayList getServiceClasses()
  {
/* 497 */     return this.serviceClasses;
  }

  public void setServiceClasses(ArrayList serviceClasses)
  {
/* 504 */     this.serviceClasses = serviceClasses;
  }

  public void search(ActionEvent ae)
  {
  }

  public void export(ActionEvent ae)
  {
  }

  public String getMsgStr() {
/* 516 */     return this.msgStr;
  }

  public void setMsgStr(String msgStr)
  {
/* 523 */     this.msgStr = msgStr;
  }

  public void setBundleTypes(ArrayList bundleTypes) {
/* 527 */     this.bundleTypes = bundleTypes;
  }

  public ArrayList getBundleTypes() {
/* 531 */     return this.bundleTypes;
  }
}