package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.dao.ManualAdjDao;
import com.vodafone.dailyreport.backend.model.AdjManualModel;
import com.vodafone.dailyreport.backend.model.AppUser;
import com.vodafone.dailyreport.backend.model.RATEPLANALL;
import com.vodafone.dailyreport.backend.service.ManualAdjService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.faces.component.UISelectOne;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.richfaces.component.UIDatascroller;

public class AdjBean
{
/*  27 */   ArrayList adjs = new ArrayList();
  private UIDatascroller datascroller2;
  private String msgStr;
  private String day;
/*  31 */   private ArrayList allRatePlan = new ArrayList();
/*  32 */   private ArrayList allRatePlanSelect = new ArrayList();
  HashMap ratePlan;
  private UISelectOne oneMenuTag;
/*  35 */   private String errorMsg = "";

  public UISelectOne getOneMenuTag()
  {
/*  42 */     return this.oneMenuTag;
  }

  public void setOneMenuTag(UISelectOne oneMenuTag)
  {
/*  49 */     this.oneMenuTag = oneMenuTag;
  }

  public HashMap getRatePlan()
  {
/*  56 */     return this.ratePlan;
  }

  public void setRatePlan(HashMap ratePlan)
  {
/*  63 */     this.ratePlan = ratePlan;
  }

  public ArrayList getAllRatePlan()
  {
/*  71 */     return this.allRatePlan;
  }

  public void setAllRatePlan(ArrayList allRatePlan)
  {
/*  78 */     this.allRatePlan = allRatePlan;
  }

  public String getMsgStr()
  {
/*  86 */     return this.msgStr;
  }

  public void setMsgStr(String msgStr)
  {
/*  93 */     this.msgStr = msgStr;
  }

  public String getAdjData()
  {
/*  98 */     this.adjs = ManualAdjService.getDao().TransferAdj(this.day);
/*  99 */     if ((this.allRatePlan == null) || (this.allRatePlan.size() == 0)) {
/* 100 */       this.ratePlan = new HashMap();
/* 101 */       this.allRatePlan = ManualAdjService.getDao().getAllRatePlan();
/* 102 */       Iterator iterator = this.allRatePlan.iterator();
/* 103 */       while (iterator.hasNext()) {
/* 104 */         RATEPLANALL rateplanall = (RATEPLANALL)iterator.next();
/* 105 */         SelectItem selectItem = new SelectItem();
/* 106 */         selectItem.setLabel(rateplanall.getRatePlanName());
/* 107 */         selectItem.setValue(rateplanall.getRatePlanName());
/* 108 */         this.allRatePlanSelect.add(selectItem);

/* 110 */         this.ratePlan.put(rateplanall.getRatePlanName(), rateplanall);
      }
    }
/* 113 */     return "adj";
  }

  public String submitTransfer()
  {
/* 121 */     int i = 0;
/* 122 */     String invalidRows = "";
/* 123 */     String isAdmin = "";
/* 124 */     this.errorMsg = "";

/* 126 */     HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
/* 127 */     HttpSession session = request.getSession();
/* 128 */     if (((LoginBean)session.getAttribute("loginbean") != null) && (((LoginBean)session.getAttribute("loginbean")).getUserModel() != null)) {
/* 129 */       isAdmin = ((LoginBean)session.getAttribute("loginbean")).getUserModel().getAdmin();
    }

/* 132 */     Iterator it = this.adjs.iterator();
/* 133 */     while (it.hasNext()) {
/* 134 */       i++;

/* 136 */       AdjManualModel model = (AdjManualModel)it.next();
/* 137 */       RATEPLANALL ratetemp = (RATEPLANALL)this.ratePlan.get(model.getRatePlanStr());
/* 138 */       model.setRateplanall((RATEPLANALL)this.ratePlan.get(model.getRatePlanStr()));

/* 140 */       if (model.getAdjust() > 3000L) {
/* 141 */         invalidRows = invalidRows + i + ",";
/* 142 */         this.errorMsg = ("Error : row " + invalidRows + " has adjust values greater than 3000");
      }
    }

/* 146 */     if (("".equals(this.errorMsg)) || ((!"".equals(this.errorMsg)) && ("Y".equals(isAdmin)))) {
/* 147 */       ManualAdjService.getDao().insertTransferData(this.adjs);
/* 148 */       this.adjs = ManualAdjService.getDao().TransferAdj(this.day);
/* 149 */       this.errorMsg = "";
    }

/* 154 */     return "adj";
  }

  public ArrayList getAdjs()
  {
/* 162 */     return this.adjs;
  }

  public void setAdjs(ArrayList adjs)
  {
/* 170 */     this.adjs = adjs;
  }

  public UIDatascroller getDatascroller2()
  {
/* 178 */     return this.datascroller2;
  }

  public void setDatascroller2(UIDatascroller datascroller2)
  {
/* 186 */     this.datascroller2 = datascroller2;
  }

  public String getDay()
  {
/* 193 */     return this.day;
  }

  public void setDay(String day)
  {
/* 200 */     this.day = day;
  }

  public ArrayList getAllRatePlanSelect()
  {
/* 207 */     return this.allRatePlanSelect;
  }

  public void setAllRatePlanSelect(ArrayList allRatePlanSelect)
  {
/* 214 */     this.allRatePlanSelect = allRatePlanSelect;
  }

  public String getErrorMsg() {
/* 218 */     return this.errorMsg;
  }

  public void setErrorMsg(String errorMsg) {
/* 222 */     this.errorMsg = errorMsg;
  }
}