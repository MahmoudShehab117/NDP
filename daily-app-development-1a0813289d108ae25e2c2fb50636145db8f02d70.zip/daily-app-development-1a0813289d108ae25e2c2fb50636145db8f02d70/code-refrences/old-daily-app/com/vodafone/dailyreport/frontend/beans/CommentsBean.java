package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.dao.CommentsDao;
import com.vodafone.dailyreport.backend.model.Comment;
import com.vodafone.dailyreport.backend.service.CommentsService;
import java.io.PrintStream;
import java.util.ArrayList;
import org.richfaces.component.UIDatascroller;

public class CommentsBean
{
/*  11 */   ArrayList comments = new ArrayList();
  private UIDatascroller datascroller2;
/*  13 */   String day = "";
/*  14 */   String comment = "";
/*  15 */   String cat = "";

  public void intialte() {
/*  18 */     this.day = "";
/*  19 */     this.comment = "";
/*  20 */     this.cat = "";
  }

  public String addComment()
  {
/*  26 */     Comment com = new Comment(this.day, this.comment, this.cat);
/*  27 */     CommentsService.getDao().addComments(com);
/*  28 */     intialte();
/*  29 */     return "init";
  }

  public String getCommentDetails() {
/*  33 */     System.out.println(this.day);
/*  34 */     this.comments = CommentsService.getDao().getComments(this.day);
/*  35 */     System.out.println(this.comments.size());

/*  37 */     return "view";
  }

  public String getCat()
  {
/*  44 */     return this.cat;
  }

  public void setCat(String cat)
  {
/*  50 */     this.cat = cat;
  }

  public String getComment()
  {
/*  56 */     return this.comment;
  }

  public void setComment(String comment)
  {
/*  62 */     this.comment = comment;
  }

  public ArrayList getComments()
  {
/*  68 */     return this.comments;
  }

  public void setComments(ArrayList comments)
  {
/*  74 */     this.comments = comments;
  }

  public String getDay()
  {
/*  80 */     return this.day;
  }

  public void setDay(String day)
  {
/*  86 */     this.day = day;
  }

  public UIDatascroller getDatascroller2()
  {
/*  93 */     return this.datascroller2;
  }

  public void setDatascroller2(UIDatascroller datascroller2)
  {
/* 100 */     this.datascroller2 = datascroller2;
  }
}