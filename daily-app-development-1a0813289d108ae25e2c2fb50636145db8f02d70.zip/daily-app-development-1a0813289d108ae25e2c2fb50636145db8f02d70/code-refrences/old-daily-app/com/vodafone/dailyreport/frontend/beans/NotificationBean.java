package com.vodafone.dailyreport.frontend.beans;

public class NotificationBean
{
}