/*    */ package com.vodafone.dailyreport.frontend.util;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.constant.BackEndConstants;
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.PropertyConfigurator;
/*    */ 
/*    */ public final class ResponceFilter
/*    */   implements Filter
/*    */ {
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig arg0)
/*    */     throws ServletException
/*    */   {
/*    */     try
/*    */     {
/* 36 */       Properties log4jPropertiesFile = new Properties();
/* 37 */       ResourceBundle log4jRB = ResourceBundle.getBundle("com.vodafone.dailyreport.log4j");
/* 38 */       Enumeration rbKeys = log4jRB.getKeys();
/* 39 */       while (rbKeys.hasMoreElements()) {
/* 40 */         String pKey = (String)rbKeys.nextElement();
/* 41 */         log4jPropertiesFile.setProperty(pKey, log4jRB.getString(pKey));
/*    */       }
/* 43 */       PropertyConfigurator.configure(log4jPropertiesFile);
/*    */ 
/* 45 */       BackEndConstants.ERROR_LOGGER = Logger.getLogger(ResponceFilter.class);
/* 46 */       BackEndConstants.DEBUG_LOGGER = Logger.getLogger(ResponceFilter.class);
/* 47 */       BackEndConstants.DEBUG_LOGGER.debug("Initialize ");
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/*    */     }
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 87 */     chain.doFilter(request, response);
/*    */   }
/*    */ }