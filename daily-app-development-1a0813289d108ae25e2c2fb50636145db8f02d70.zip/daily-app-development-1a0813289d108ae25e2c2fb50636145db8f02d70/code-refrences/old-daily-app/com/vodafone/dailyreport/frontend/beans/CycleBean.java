/*    */ package com.vodafone.dailyreport.frontend.beans;
/*    */ 
/*    */ import com.vodafone.dailyreport.frontend.util.SessionHelper;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class CycleBean
/*    */ {
/*    */   public void cleanUp()
/*    */   {
/*  9 */     MainBean mainBean = new MainBean();
/*    */ 
/* 11 */     SessionHelper.getSession().setAttribute("mainbean", mainBean);
/* 12 */     SessionHelper.getSession()
/* 13 */       .setAttribute("grouprate", new GroupingBean());
/* 14 */     SessionHelper.getSession().setAttribute("pg", new PriceGroupBean());
/* 15 */     SessionHelper.getSession().setAttribute("commentsBean", 
/* 16 */       new CommentsBean());
/*    */   }
/*    */ 
/*    */   public String organize() {
/* 20 */     cleanUp();
/* 21 */     return "organize";
/*    */   }
/*    */ 
/*    */   public String create() {
/* 25 */     cleanUp();
/* 26 */     return "create";
/*    */   }
/*    */ 
/*    */   public String update() {
/* 30 */     cleanUp();
/* 31 */     return "update";
/*    */   }
/*    */ 
/*    */   public String viewrateplan() {
/* 35 */     cleanUp();
/* 36 */     return "viewrate";
/*    */   }
/*    */ 
/*    */   public String viewgroup() {
/* 40 */     cleanUp();
/* 41 */     return "viewgroup";
/*    */   }
/*    */ 
/*    */   public String createPgGroup() {
/* 45 */     cleanUp();
/* 46 */     return "create";
/*    */   }
/*    */ 
/*    */   public String createComments() {
/* 50 */     cleanUp();
/* 51 */     return "createComments";
/*    */   }
/*    */ 
/*    */   public String updatePgGroup() {
/* 55 */     cleanUp();
/* 56 */     return "update";
/*    */   }
/*    */ 
/*    */   public String viewPg() {
/* 60 */     cleanUp();
/* 61 */     return "viewrate";
/*    */   }
/*    */ 
/*    */   public String viewComments() {
/* 65 */     cleanUp();
/* 66 */     return "viewComments";
/*    */   }
/*    */ 
/*    */   public String viewPgGroup() {
/* 70 */     cleanUp();
/* 71 */     return "viewgroup";
/*    */   }
/*    */ }