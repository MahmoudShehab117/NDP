/*    */ package com.vodafone.dailyreport.frontend.util;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.RatePlanDao;
/*    */ import com.vodafone.dailyreport.backend.model.ServiceClass;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class Test
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 12 */     RatePlanDao dao = new RatePlanDao();
/* 13 */     ArrayList list = dao.getServiceClass();
/* 14 */     Iterator it = list.iterator();
/* 15 */     while (it.hasNext()) {
/* 16 */       ServiceClass serviceClass = (ServiceClass)it.next();
/* 17 */       System.out.println(serviceClass.getScCode() + ";" + serviceClass.getScName() + ";" + serviceClass.isActivationSource() + ";" + 
/* 18 */         serviceClass.isScConsumer() + ";" + serviceClass.isScEnt() + ";" + serviceClass.isScPost() + 
/* 19 */         ";" + serviceClass.isScPre() + ";" + serviceClass.isUpdate() + ";");
/*    */     }
/*    */   }
/*    */ }