package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.dao.PriceGroupDao;
import com.vodafone.dailyreport.backend.model.PriceGroupGroup;
import com.vodafone.dailyreport.backend.model.PriceGroupModel;
import com.vodafone.dailyreport.backend.service.PriceGroupService;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.faces.event.ActionEvent;
import org.ajax4jsf.ajax.UIAjaxCommandLink;
import org.richfaces.component.UIDatascroller;

public class PriceGroupBean
{
/*  19 */   PriceGroupGroup group = new PriceGroupGroup();
/*  20 */   ArrayList pgList = new ArrayList();
/*  21 */   String msgStr = "";
/*  22 */   GroupSearchBean groupSearchBean = new GroupSearchBean();
/*  23 */   ArrayList groups = new ArrayList();
/*  24 */   HashMap map = new HashMap();
/*  25 */   ArrayList groupPlans = new ArrayList();
/*  26 */   SearchBean bean = new SearchBean();
/*  27 */   ArrayList plan = new ArrayList();
/*  28 */   PriceGroupGroup updateGroup = new PriceGroupGroup();
  private UIDatascroller datascroller2;
  private UIDatascroller datascroller3;

  public UIDatascroller getDatascroller2()
  {
/*  35 */     return this.datascroller2;
  }

  public void setDatascroller2(UIDatascroller datascroller2) {
/*  39 */     this.datascroller2 = datascroller2;
  }

  public UIDatascroller getDatascroller3() {
/*  43 */     return this.datascroller3;
  }

  public void setDatascroller3(UIDatascroller datascroller3) {
/*  47 */     this.datascroller3 = datascroller3;
  }

  public void initalizeScroll() {
/*  51 */     this.datascroller2.setPage("1");
  }

  public String search()
  {
/*  56 */     initalizeScroll();
/*  57 */     this.msgStr = "";
/*  58 */     if ((this.group.getGroupName() == null) || (this.group.getGroupName().equals("")) || 
/*  59 */       (this.group.getDesc() == null) || 
/*  60 */       (this.group.getDesc().equals(""))) {
/*  61 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/*  62 */       return "rateplans";
    }
/*  64 */     this.pgList = PriceGroupService.getDao().getPg();
/*  65 */     this.group.setPriceGroups(this.pgList);

/*  67 */     return "rateplans";
  }

  public String searchGroup()
  {
/*  74 */     initalizeScroll();
/*  75 */     this.msgStr = "";
/*  76 */     String name = this.groupSearchBean.getName();
/*  77 */     boolean show = this.groupSearchBean.isShow();
/*  78 */     this.groups = PriceGroupService.getDao().getGroupByname(name, show);
/*  79 */     Iterator it = this.groups.iterator();
/*  80 */     while (it.hasNext()) {
/*  81 */       PriceGroupGroup group = (PriceGroupGroup)it.next();
/*  82 */       this.map.put(group.getGroupName(), new Integer(group.getGroupKey()));
    }
/*  84 */     this.pgList = new ArrayList();
/*  85 */     return "groupssearch";
  }

  public String add()
  {
/*  94 */     if ((this.group.getGroupName() == null) || (this.group.getGroupName().equals("")) || 
/*  95 */       (this.group.getDesc() == null) || 
/*  96 */       (this.group.getDesc().equals(""))) {
/*  97 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/*  98 */       return null;
    }
/* 100 */     int check = PriceGroupService.getDao().createGroup(this.group);
/* 101 */     if (check == -1) {
/* 102 */       this.msgStr = "Group is already Exist";
/* 103 */       return null;
    }
/* 105 */     this.msgStr = 
/* 106 */       ("Group '" + this.group.getGroupName() + 
/* 106 */       "' Created Succesfully");
/* 107 */     this.group = new PriceGroupGroup();
/* 108 */     this.pgList = new ArrayList();

/* 110 */     return "rateplans";
  }

  public void getPg(ActionEvent ae)
  {
/* 117 */     UIAjaxCommandLink commandLink = (UIAjaxCommandLink)ae.getComponent();
/* 118 */     String groupName = (String)commandLink.getValue();
/* 119 */     System.out.println(groupName);
/* 120 */     int key = ((Integer)this.map.get(groupName)).intValue();
/* 121 */     this.groupPlans = PriceGroupService.getDao().getPgbyGroup(key);

/* 123 */     System.out.println(this.groupPlans.size());
  }

  public String searchPg()
  {
/* 128 */     initalizeScroll();
/* 129 */     this.plan = PriceGroupService.getDao().getPg(this.bean.getName());
/* 130 */     return "searchrateplan";
  }

  public void updateGroup(ActionEvent ae)
  {
/* 137 */     UIAjaxCommandLink commandLink = (UIAjaxCommandLink)ae.getComponent();
/* 138 */     String groupName = (String)commandLink.getValue();
/* 139 */     System.out.println(groupName);
/* 140 */     this.updateGroup = ((PriceGroupGroup)PriceGroupService.getDao().getGroupByname(groupName, false).get(0));
/* 141 */     System.out.println(this.updateGroup.getGroupKey());
/* 142 */     this.pgList = PriceGroupService.getDao().getPgbyGroup(this.updateGroup.getGroupKey());
/* 143 */     Iterator it = this.pgList.iterator();
/* 144 */     while (it.hasNext()) {
/* 145 */       PriceGroupModel groupModel = (PriceGroupModel)it.next();
/* 146 */       if (groupModel.getPriceGroupGroupKey().getGroupKey() == this.updateGroup.getGroupKey()) {
/* 147 */         groupModel.setOriginal(true);
      }
    }
/* 150 */     this.updateGroup.setPriceGroups(this.pgList);
  }

  public String update()
  {
/* 158 */     if ((this.updateGroup.getGroupName() == null) || (this.updateGroup.getGroupName().equals("")) || 
/* 159 */       (this.updateGroup.getDesc() == null) || 
/* 160 */       (this.updateGroup.getDesc().equals(""))) {
/* 161 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/* 162 */       return null;
    }
/* 164 */     int check = PriceGroupService.getDao().updateGroup(this.updateGroup);
/* 165 */     if (check == -1) {
/* 166 */       this.msgStr = "Group is already Exist";
/* 167 */       return null;
    }
/* 169 */     this.msgStr = 
/* 170 */       ("Group '" + this.updateGroup.getGroupName() + 
/* 170 */       "' Updated Succesfully");

/* 172 */     this.groupSearchBean = new GroupSearchBean();
/* 173 */     this.groups = new ArrayList();
/* 174 */     this.pgList = new ArrayList();
/* 175 */     return "updat";
  }

  public String searchUpdate()
  {
/* 180 */     initalizeScroll();
/* 181 */     this.msgStr = "";
/* 182 */     if ((this.updateGroup.getGroupName() == null) || (this.updateGroup.getGroupName().equals("")) || 
/* 183 */       (this.updateGroup.getDesc() == null) || 
/* 184 */       (this.updateGroup.getDesc().equals(""))) {
/* 185 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/* 186 */       return "searchupdate";
    }
/* 188 */     this.pgList = PriceGroupService.getDao().getPg();
/* 189 */     Iterator it = this.pgList.iterator();
/* 190 */     while (it.hasNext()) {
/* 191 */       PriceGroupModel groupModel = (PriceGroupModel)it.next();
/* 192 */       if (groupModel.getPriceGroupGroupKey().getGroupKey() == this.updateGroup.getGroupKey()) {
/* 193 */         groupModel.setOriginal(true);
      }
    }
/* 196 */     this.updateGroup.setPriceGroups(this.pgList);

/* 199 */     return "searchupdate";
  }

  public PriceGroupGroup getUpdateGroup()
  {
/* 205 */     return this.updateGroup;
  }

  public void setUpdateGroup(PriceGroupGroup updateGroup) {
/* 209 */     this.updateGroup = updateGroup;
  }

  public ArrayList getPlan() {
/* 213 */     return this.plan;
  }

  public void setPlan(ArrayList plan) {
/* 217 */     this.plan = plan;
  }

  public SearchBean getBean() {
/* 221 */     return this.bean;
  }

  public void setBean(SearchBean bean) {
/* 225 */     this.bean = bean;
  }

  public ArrayList getGroups() {
/* 229 */     return this.groups;
  }

  public void setGroups(ArrayList groups) {
/* 233 */     this.groups = groups;
  }

  public GroupSearchBean getGroupSearchBean() {
/* 237 */     return this.groupSearchBean;
  }

  public void setGroupSearchBean(GroupSearchBean groupSearchBean) {
/* 241 */     this.groupSearchBean = groupSearchBean;
  }

  public String getMsgStr() {
/* 245 */     return this.msgStr;
  }

  public void setMsgStr(String msgStr) {
/* 249 */     this.msgStr = msgStr;
  }

  public ArrayList getGroupPlans()
  {
/* 255 */     return this.groupPlans;
  }

  public void setGroupPlans(ArrayList groupPlans) {
/* 259 */     this.groupPlans = groupPlans;
  }

  public HashMap getMap() {
/* 263 */     return this.map;
  }

  public void setMap(HashMap map) {
/* 267 */     this.map = map;
  }

  public ArrayList getPgList() {
/* 271 */     return this.pgList;
  }

  public void setPgList(ArrayList pgList) {
/* 275 */     this.pgList = pgList;
  }

  public void setGroup(PriceGroupGroup group) {
/* 279 */     this.group = group;
  }

  public PriceGroupGroup getGroup() {
/* 283 */     return this.group;
  }
}