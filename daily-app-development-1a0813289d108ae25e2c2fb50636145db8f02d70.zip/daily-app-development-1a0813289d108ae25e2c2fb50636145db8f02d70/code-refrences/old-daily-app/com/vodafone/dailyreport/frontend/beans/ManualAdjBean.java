package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.model.ManualRecordModel;
import com.vodafone.dailyreport.backend.model.TrxModel;
import com.vodafone.dailyreport.backend.service.ManualAdjService;
import com.vodafone.dailyreport.frontend.util.SessionHelper;
import org.richfaces.component.UIDatascroller;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ManualAdjBean {
    /*  25 */ ArrayList adjs = new ArrayList();
    private UIDatascroller datascroller2;
    private String msgStr;
    private String day;
    /*  29 */   private String errorMsg = "";

    public String getMsgStr() {
        /*  35 */
        return this.msgStr;
    }

    public void setMsgStr(String msgStr) {
        /*  42 */
        this.msgStr = msgStr;
    }

    public String getAdjData() {
        /*  46 */
        ArrayList trx = SessionHelper.getVeBean().getTrx();
        /*  47 */
        HashMap trxMap = SessionHelper.getVeBean().getTrxMap();
        /*  48 */
        this.adjs = ManualAdjService.getDao().getAdjustmentData(this.day);
        /*  49 */
        return "adj";
    }

    public String adjust() {
        /*  55 */
        HashMap trxMap = SessionHelper.getVeBean().getTrxMap();
        /*  56 */
        Iterator it = this.adjs.iterator();

        /*  60 */
        while (it.hasNext()) {
            /*  61 */
            ManualRecordModel model = (ManualRecordModel) it.next();
            /*  62 */
            TrxModel model2 = (TrxModel) trxMap.get(model.getAdjustType());
            /*  63 */
            model.setTrxModel(model2);
        }

        /*  67 */
        return "adj";
    }

    public String submit() {
        /*  72 */
        int i = 0;
        /*  73 */
        String invalidRows = "";
        /*  74 */
        String isAdmin = "";
        /*  75 */
        this.errorMsg = "";

        /*  77 */
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        /*  78 */
        HttpSession session = request.getSession();
        /*  79 */
        if ((session.getAttribute("loginbean") != null) && (((LoginBean) session.getAttribute("loginbean")).getUserModel() != null)) {
            /*  80 */
            isAdmin = ((LoginBean) session.getAttribute("loginbean")).getUserModel().getAdmin();
        }

        /*  83 */
        HashMap trxMap = SessionHelper.getVeBean().getTrxMap();
        /*  84 */
        Iterator it = this.adjs.iterator();
        /*  85 */
        while (it.hasNext()) {
            /*  86 */
            i++;
            /*  87 */
            ManualRecordModel model = (ManualRecordModel) it.next();
            /*  88 */
            TrxModel model2 = (TrxModel) trxMap.get(model.getAdjustType());
            /*  89 */
            model.setTrxModel(model2);

            /*  91 */
            if (model.getAdjSubs() > 3000L) {
                /*  92 */
                invalidRows = invalidRows + i + ",";
                /*  93 */
                this.errorMsg = ("Error: row " + invalidRows + " has subs values greater than 3000");
            }

        }

        /*  98 */
        if (("".equals(this.errorMsg)) || ((!"".equals(this.errorMsg)) && ("Y".equals(isAdmin)))) {
            /*  99 */
            ManualAdjService.getDao().insertAdjustmentData(this.adjs);
            /* 100 */
            ManualAdjService.getDao().insertClosingData(this.adjs);
            /* 101 */
            ManualAdjService.getDao().insertNetAdds(this.adjs);

            /* 103 */
            this.adjs = ManualAdjService.getDao().getAdjustmentData(this.day);
            /* 104 */
            this.errorMsg = "";
        }

        /* 107 */
        return "adj";
    }

    public ArrayList getAdjs() {
        /* 115 */
        return this.adjs;
    }

    public void setAdjs(ArrayList adjs) {
        /* 123 */
        this.adjs = adjs;
    }

    public UIDatascroller getDatascroller2() {
        /* 131 */
        return this.datascroller2;
    }

    public void setDatascroller2(UIDatascroller datascroller2) {
        /* 139 */
        this.datascroller2 = datascroller2;
    }

    public String getDay() {
        /* 146 */
        return this.day;
    }

    public void setDay(String day) {
        /* 153 */
        this.day = day;
    }

    public String getErrorMsg() {
        /* 157 */
        return this.errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        /* 161 */
        this.errorMsg = errorMsg;
    }
}