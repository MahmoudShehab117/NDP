package com.vodafone.dailyreport.frontend.resources;

public class Constants
{
}