/*    */ package com.vodafone.dailyreport.frontend.handler;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.model.AppUser;
/*    */ 
/*    */ public class UserManagmentHandler
/*    */ {
/*    */   public String encryptPassword(String password)
/*    */   {
/*  9 */     return "";
/*    */   }
/*    */ 
/*    */   public boolean checkuserExpiration(String username) {
/* 13 */     return false;
/*    */   }
/*    */ 
/*    */   public AppUser login(String username, String pass) {
/* 17 */     return null;
/*    */   }
/*    */ }