/*    */ package com.vodafone.dailyreport.frontend.log;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class FrontLogHandler extends Logger
/*    */ {
/* 15 */   public static FrontLogHandler handler = new FrontLogHandler("Daily Report Front Bean", null);
/*    */ 
/*    */   protected FrontLogHandler(String name, String resourceBundleName) {
/* 18 */     super(name, resourceBundleName);
/*    */   }
/*    */ 
/*    */   public static FrontLogHandler getLogger()
/*    */   {
/* 27 */     return handler;
/*    */   }
/*    */ }