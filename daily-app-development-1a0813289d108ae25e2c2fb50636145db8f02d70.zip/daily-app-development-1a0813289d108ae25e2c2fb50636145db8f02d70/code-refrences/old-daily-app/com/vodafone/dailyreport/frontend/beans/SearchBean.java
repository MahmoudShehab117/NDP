/*    */ package com.vodafone.dailyreport.frontend.beans;
/*    */ 
/*    */ public class SearchBean
/*    */ {
/*    */   private String name;
/* 15 */   private String type = "0";
/* 16 */   private String cType = "0";
/* 17 */   private String activationSource = "0";
/* 18 */   private String bundleType = "0";
/*    */ 
/*    */   public String getActivationSource()
/*    */   {
/* 22 */     return this.activationSource;
/*    */   }
/*    */   public void setActivationSource(String activationSource) {
/* 25 */     this.activationSource = activationSource;
/*    */   }
/*    */   public String getCType() {
/* 28 */     return this.cType;
/*    */   }
/*    */   public void setCType(String type) {
/* 31 */     this.cType = type;
/*    */   }
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 37 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 40 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 43 */     this.type = type;
/*    */   }
/*    */   public void setBundleType(String bundleType) {
/* 46 */     this.bundleType = bundleType;
/*    */   }
/*    */   public String getBundleType() {
/* 49 */     return this.bundleType;
/*    */   }
/*    */ }