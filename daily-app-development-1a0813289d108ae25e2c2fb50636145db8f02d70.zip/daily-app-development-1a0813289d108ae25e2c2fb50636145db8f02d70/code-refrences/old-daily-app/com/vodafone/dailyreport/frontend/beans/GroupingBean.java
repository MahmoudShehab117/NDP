package com.vodafone.dailyreport.frontend.beans;

import com.vodafone.dailyreport.backend.dao.RatePlanDao;
import com.vodafone.dailyreport.backend.model.RatePlan;
import com.vodafone.dailyreport.backend.model.RatePlanGroup;
import com.vodafone.dailyreport.backend.service.RatePlanService;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.faces.event.ActionEvent;
import org.ajax4jsf.ajax.UIAjaxCommandLink;
import org.richfaces.component.UIDatascroller;

public class GroupingBean
{
/*  29 */   RatePlanGroup group = new RatePlanGroup();
/*  30 */   ArrayList rateplan = new ArrayList();
/*  31 */   String msgStr = "";
/*  32 */   GroupSearchBean groupSearchBean = new GroupSearchBean();
/*  33 */   ArrayList groups = new ArrayList();
/*  34 */   HashMap map = new HashMap();
/*  35 */   ArrayList groupPlans = new ArrayList();
/*  36 */   SearchBean bean = new SearchBean();
/*  37 */   ArrayList plan = new ArrayList();
/*  38 */   RatePlanGroup updateGroup = new RatePlanGroup();
  private UIDatascroller datascroller2;
  private UIDatascroller datascroller3;

  public UIDatascroller getDatascroller2()
  {
/*  46 */     return this.datascroller2;
  }

  public void setDatascroller2(UIDatascroller datascroller2) {
/*  50 */     this.datascroller2 = datascroller2;
  }

  public UIDatascroller getDatascroller3() {
/*  54 */     return this.datascroller3;
  }

  public void setDatascroller3(UIDatascroller datascroller3) {
/*  58 */     this.datascroller3 = datascroller3;
  }

  public void initalizeScroll() {
/*  62 */     this.datascroller2.setPage("1");
  }

  public String search()
  {
/*  67 */     initalizeScroll();
/*  68 */     this.msgStr = "";
/*  69 */     if ((this.group.getRpGroupName() == null) || (this.group.getRpGroupName().equals("")) || 
/*  70 */       (this.group.getRpGroupDesc() == null) || 
/*  71 */       (this.group.getRpGroupDesc().equals(""))) {
/*  72 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/*  73 */       return "rateplans";
    }
/*  75 */     this.rateplan = RatePlanService.getDao().getRatePlan();
/*  76 */     this.group.setRatePlans(this.rateplan);

/*  78 */     return "rateplans";
  }

  public String searchGroup()
  {
/*  85 */     initalizeScroll();
/*  86 */     this.msgStr = "";
/*  87 */     String name = this.groupSearchBean.getName();
/*  88 */     boolean show = this.groupSearchBean.isShow();
/*  89 */     this.groups = RatePlanService.getDao().getGroupByname(name, show);
/*  90 */     Iterator it = this.groups.iterator();
/*  91 */     while (it.hasNext()) {
/*  92 */       RatePlanGroup group = (RatePlanGroup)it.next();
/*  93 */       this.map.put(group.getRpGroupName(), new Integer(group.getRpGroupKey()));
    }

/*  96 */     return "groupssearch";
  }

  public String add()
  {
/* 105 */     if ((this.group.getRpGroupName() == null) || (this.group.getRpGroupName().equals("")) || 
/* 106 */       (this.group.getRpGroupDesc() == null) || 
/* 107 */       (this.group.getRpGroupDesc().equals(""))) {
/* 108 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/* 109 */       return null;
    }
/* 111 */     int check = RatePlanService.getDao().createGroup(this.group);
/* 112 */     if (check == -1) {
/* 113 */       this.msgStr = "Group is already Exist";
/* 114 */       return null;
    }
/* 116 */     this.msgStr = 
/* 117 */       ("Group '" + this.group.getRpGroupName() + 
/* 117 */       "' Created Succesfully");
/* 118 */     this.group = new RatePlanGroup();
/* 119 */     this.rateplan = new ArrayList();

/* 121 */     return "rateplans";
  }

  public void getRatePlan(ActionEvent ae)
  {
/* 128 */     UIAjaxCommandLink commandLink = (UIAjaxCommandLink)ae.getComponent();
/* 129 */     String groupName = (String)commandLink.getValue();
/* 130 */     System.out.println(groupName);
/* 131 */     int key = ((Integer)this.map.get(groupName)).intValue();
/* 132 */     this.groupPlans = RatePlanService.getDao().getRatePlanbyGroup(key);
/* 133 */     System.out.println(this.groupPlans.size());
  }

  public String searchRatePlan() {
/* 137 */     initalizeScroll();
/* 138 */     System.out.println(this.bean.getName());
/* 139 */     this.plan = RatePlanService.getDao().getRatePlan(this.bean.getName());
/* 140 */     return "searchrateplan";
  }

  public void updateGroup(ActionEvent ae) {
/* 144 */     UIAjaxCommandLink commandLink = (UIAjaxCommandLink)ae.getComponent();
/* 145 */     String groupName = (String)commandLink.getValue();
/* 146 */     System.out.println(groupName);
/* 147 */     this.updateGroup = ((RatePlanGroup)RatePlanService.getDao().getGroupByname(groupName, false).get(0));
/* 148 */     this.rateplan = RatePlanService.getDao().getRatePlanbyGroup(this.updateGroup.getRpGroupKey());
/* 149 */     Iterator it = this.rateplan.iterator();
/* 150 */     while (it.hasNext()) {
/* 151 */       RatePlan plan = (RatePlan)it.next();
/* 152 */       if (plan.getRatePlanGroup().getRpGroupKey() == this.updateGroup.getRpGroupKey()) {
/* 153 */         plan.setOriginal(true);
      }
    }
/* 156 */     this.updateGroup.setRatePlans(this.rateplan);
  }

  public String update()
  {
/* 162 */     if ((this.updateGroup.getRpGroupName() == null) || (this.updateGroup.getRpGroupName().equals("")) || 
/* 163 */       (this.updateGroup.getRpGroupDesc() == null) || 
/* 164 */       (this.updateGroup.getRpGroupDesc().equals(""))) {
/* 165 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/* 166 */       return null;
    }
/* 168 */     System.out.println(this.updateGroup.getRpGroupKey());
/* 169 */     int check = RatePlanService.getDao().updateGroup(this.updateGroup);
/* 170 */     if (check == -1) {
/* 171 */       this.msgStr = "Group is already Exist";
/* 172 */       return null;
    }
/* 174 */     this.msgStr = 
/* 175 */       ("Group '" + this.updateGroup.getRpGroupName() + 
/* 175 */       "' Updated Succesfully");

/* 177 */     this.groupSearchBean = new GroupSearchBean();
/* 178 */     this.groups = new ArrayList();
/* 179 */     this.rateplan = new ArrayList();
/* 180 */     return "updat";
  }

  public String searchUpdate()
  {
/* 185 */     initalizeScroll();
/* 186 */     this.msgStr = "";
/* 187 */     if ((this.updateGroup.getRpGroupName() == null) || (this.updateGroup.getRpGroupName().equals("")) || 
/* 188 */       (this.updateGroup.getRpGroupDesc() == null) || 
/* 189 */       (this.updateGroup.getRpGroupDesc().equals(""))) {
/* 190 */       this.msgStr = "Kindly Complete All Mantadory Fields ";
/* 191 */       return "searchupdate";
    }
/* 193 */     this.rateplan = RatePlanService.getDao().getRatePlan();
/* 194 */     Iterator it = this.rateplan.iterator();
/* 195 */     while (it.hasNext()) {
/* 196 */       RatePlan plan = (RatePlan)it.next();
/* 197 */       if (plan.getRatePlanGroup().getRpGroupKey() == this.updateGroup.getRpGroupKey()) {
/* 198 */         plan.setOriginal(true);
      }
    }
/* 201 */     this.updateGroup.setRatePlans(this.rateplan);

/* 203 */     return "searchupdate";
  }

  public RatePlanGroup getUpdateGroup()
  {
/* 209 */     return this.updateGroup;
  }

  public void setUpdateGroup(RatePlanGroup updateGroup) {
/* 213 */     this.updateGroup = updateGroup;
  }

  public ArrayList getPlan() {
/* 217 */     return this.plan;
  }

  public void setPlan(ArrayList plan) {
/* 221 */     this.plan = plan;
  }

  public SearchBean getBean() {
/* 225 */     return this.bean;
  }

  public void setBean(SearchBean bean) {
/* 229 */     this.bean = bean;
  }

  public ArrayList getGroups() {
/* 233 */     return this.groups;
  }

  public void setGroups(ArrayList groups) {
/* 237 */     this.groups = groups;
  }

  public GroupSearchBean getGroupSearchBean() {
/* 241 */     return this.groupSearchBean;
  }

  public void setGroupSearchBean(GroupSearchBean groupSearchBean) {
/* 245 */     this.groupSearchBean = groupSearchBean;
  }

  public String getMsgStr() {
/* 249 */     return this.msgStr;
  }

  public void setMsgStr(String msgStr) {
/* 253 */     this.msgStr = msgStr;
  }

  public RatePlanGroup getGroup() {
/* 257 */     return this.group;
  }

  public void setGroup(RatePlanGroup group) {
/* 261 */     this.group = group;
  }

  public ArrayList getRateplan() {
/* 265 */     return this.rateplan;
  }

  public void setRateplan(ArrayList rateplan) {
/* 269 */     this.rateplan = rateplan;
  }

  public ArrayList getGroupPlans() {
/* 273 */     return this.groupPlans;
  }

  public void setGroupPlans(ArrayList groupPlans) {
/* 277 */     this.groupPlans = groupPlans;
  }

  public HashMap getMap() {
/* 281 */     return this.map;
  }

  public void setMap(HashMap map) {
/* 285 */     this.map = map;
  }
}