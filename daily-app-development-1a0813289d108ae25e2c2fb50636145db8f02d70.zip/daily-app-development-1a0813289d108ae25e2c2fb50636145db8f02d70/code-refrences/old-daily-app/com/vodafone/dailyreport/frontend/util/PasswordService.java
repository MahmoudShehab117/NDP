/*    */ package com.vodafone.dailyreport.frontend.util;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import sun.misc.BASE64Encoder;
/*    */ 
/*    */ public final class PasswordService
/*    */ {
/*    */   private static PasswordService instance;
/*    */ 
/*    */   public synchronized String encrypt(String plaintext)
/*    */   {
/* 27 */     MessageDigest md = null;
/*    */     try
/*    */     {
/* 30 */       md = MessageDigest.getInstance("SHA");
/*    */     }
/*    */     catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
/*    */     {
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 38 */       md.update(plaintext.getBytes("UTF-8"));
/*    */     }
/*    */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*    */     {
/*    */     }
/*    */ 
/* 45 */     byte[] raw = md.digest();
/* 46 */     String hash = new BASE64Encoder().encode(raw);
/* 47 */     return hash;
/*    */   }
/*    */ 
/*    */   public static synchronized PasswordService getInstance()
/*    */   {
/* 55 */     if (instance == null)
/*    */     {
/* 57 */       instance = new PasswordService();
/*    */     }
/* 59 */     return instance;
/*    */   }
/*    */ }