/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class TotalModel
/*    */ {
/*    */   long closing;
/*    */   long opening;
/*    */ 
/*    */   public long getClosing()
/*    */   {
/* 10 */     return this.closing;
/*    */   }
/*    */ 
/*    */   public void setClosing(long closing)
/*    */   {
/* 16 */     this.closing = closing;
/*    */   }
/*    */ 
/*    */   public long getOpening()
/*    */   {
/* 22 */     return this.opening;
/*    */   }
/*    */ 
/*    */   public void setOpening(long opening)
/*    */   {
/* 28 */     this.opening = opening;
/*    */   }
/*    */ 
/*    */   public TotalModel(long closing, long opening) {
/* 32 */     this.closing = closing;
/* 33 */     this.opening = opening;
/*    */   }
/*    */ 
/*    */   public TotalModel()
/*    */   {
/*    */   }
/*    */ }