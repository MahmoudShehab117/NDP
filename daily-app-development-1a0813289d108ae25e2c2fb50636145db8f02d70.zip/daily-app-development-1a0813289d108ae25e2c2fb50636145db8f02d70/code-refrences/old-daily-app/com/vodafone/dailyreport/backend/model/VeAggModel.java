package com.vodafone.dailyreport.backend.model;

import java.util.ArrayList;
import java.util.Date;

public class VeAggModel
{
  private long subs;
  private String seq;
  private int dateKey;
  private int priceGroupKey;
  private int ratePlanKey;
  private int trxKey;
  private int ratePlanGroupKey;
  private int dwhStatusKey;
  private int userKey;
  private String segment;
  private String status;
  private String activationReason;
  private String priceGroup;
  private String ratePlan;
  private String trxName;
  private String ratePlanGroup;
  private String dwhStatus;
  private boolean applyFlag;
  private Date applyDate;
  private String date;
  private String cCode;
  private ArrayList details;
  private int diffCode;
  private String diff;
  private long inSubs;
  private long outSubs;
  private long open;
  private long close;
  private boolean inApply;
  private boolean outApply;
  private String inAdjustType;
  private String outAdjustType;
  private long variance;
  private TrxModel inTrxModel;
  private TrxModel outTrxModel;
  public long closeFinal;

  public long getVariance()
  {
/*  52 */     long variance = getClose() - this.open;

/*  54 */     return variance;
  }

  public void setVariance(long variance)
  {
/*  60 */     this.variance = variance;
  }

  public long getInSubs()
  {
/*  66 */     return this.inSubs;
  }

  public void setInSubs(long inSubs)
  {
/*  72 */     this.inSubs = inSubs;
  }

  public long getOutSubs()
  {
/*  78 */     return this.outSubs;
  }

  public void setOutSubs(long outSubs)
  {
/*  84 */     this.outSubs = outSubs;
  }

  public String getDiff()
  {
/*  90 */     return this.diff;
  }

  public void setDiff(String diff)
  {
/*  96 */     this.diff = diff;
  }

  public int getDiffCode()
  {
/* 102 */     return this.diffCode;
  }

  public void setDiffCode(int diffCode)
  {
/* 108 */     this.diffCode = diffCode;
  }
  public ArrayList getDetails() {
/* 111 */     return this.details;
  }
  public void setDetails(ArrayList details) {
/* 114 */     this.details = details;
  }
  public String getCCode() {
/* 117 */     return this.cCode;
  }
  public void setCCode(String code) {
/* 120 */     this.cCode = code;
  }
  public String getDate() {
/* 123 */     return this.date;
  }
  public void setDate(String date) {
/* 126 */     this.date = date;
  }
  public String getActivationReason() {
/* 129 */     return this.activationReason;
  }
  public void setActivationReason(String activationReason) {
/* 132 */     this.activationReason = activationReason;
  }
  public Date getApplyDate() {
/* 135 */     return this.applyDate;
  }
  public void setApplyDate(Date applyDate) {
/* 138 */     this.applyDate = applyDate;
  }
  public boolean isApplyFlag() {
/* 141 */     return this.applyFlag;
  }
  public void setApplyFlag(boolean applyFlag) {
/* 144 */     this.applyFlag = applyFlag;
  }
  public int getDateKey() {
/* 147 */     return this.dateKey;
  }
  public void setDateKey(int dateKey) {
/* 150 */     this.dateKey = dateKey;
  }
  public String getDwhStatus() {
/* 153 */     return this.dwhStatus;
  }
  public void setDwhStatus(String dwhStatus) {
/* 156 */     this.dwhStatus = dwhStatus;
  }
  public int getDwhStatusKey() {
/* 159 */     return this.dwhStatusKey;
  }
  public void setDwhStatusKey(int dwhStatusKey) {
/* 162 */     this.dwhStatusKey = dwhStatusKey;
  }
  public String getPriceGroup() {
/* 165 */     return this.priceGroup;
  }
  public void setPriceGroup(String priceGroup) {
/* 168 */     this.priceGroup = priceGroup;
  }
  public int getPriceGroupKey() {
/* 171 */     return this.priceGroupKey;
  }
  public void setPriceGroupKey(int priceGroupKey) {
/* 174 */     this.priceGroupKey = priceGroupKey;
  }
  public String getRatePlan() {
/* 177 */     return this.ratePlan;
  }
  public void setRatePlan(String ratePlan) {
/* 180 */     this.ratePlan = ratePlan;
  }
  public String getRatePlanGroup() {
/* 183 */     return this.ratePlanGroup;
  }
  public void setRatePlanGroup(String ratePlanGroup) {
/* 186 */     this.ratePlanGroup = ratePlanGroup;
  }
  public int getRatePlanGroupKey() {
/* 189 */     return this.ratePlanGroupKey;
  }
  public void setRatePlanGroupKey(int ratePlanGroupKey) {
/* 192 */     this.ratePlanGroupKey = ratePlanGroupKey;
  }
  public int getRatePlanKey() {
/* 195 */     return this.ratePlanKey;
  }
  public void setRatePlanKey(int ratePlanKey) {
/* 198 */     this.ratePlanKey = ratePlanKey;
  }
  public String getSegment() {
/* 201 */     return this.segment;
  }
  public void setSegment(String segment) {
/* 204 */     this.segment = segment;
  }
  public long getSubs() {
/* 207 */     return this.subs;
  }
  public void setSubs(long subs) {
/* 210 */     this.subs = subs;
  }
  public int getTrxKey() {
/* 213 */     return this.trxKey;
  }
  public void setTrxKey(int trxKey) {
/* 216 */     this.trxKey = trxKey;
  }
  public String getTrxName() {
/* 219 */     return this.trxName;
  }
  public void setTrxName(String trxName) {
/* 222 */     this.trxName = trxName;
  }
  public int getUserKey() {
/* 225 */     return this.userKey;
  }
  public void setUserKey(int userKey) {
/* 228 */     this.userKey = userKey;
  }
  public String getSeq() {
/* 231 */     return this.seq;
  }
  public void setSeq(String seq) {
/* 234 */     this.seq = seq;
  }

  public boolean isInApply()
  {
/* 240 */     return this.inApply;
  }

  public void setInApply(boolean inApply)
  {
/* 246 */     this.inApply = inApply;
  }

  public boolean isOutApply()
  {
/* 252 */     return this.outApply;
  }

  public void setOutApply(boolean outApply)
  {
/* 258 */     this.outApply = outApply;
  }

  public long getClosrOri()
  {
/* 266 */     return this.close;
  }

  public long getClose()
  {
/* 278 */     if (this.closeFinal == 0L) {
/* 279 */       this.closeFinal = this.close;
    }

/* 282 */     return this.closeFinal;
  }

  public void setClose(long close)
  {
/* 288 */     this.close = close;
  }

  public long getOpen()
  {
/* 294 */     return this.open;
  }

  public void setOpen(long open)
  {
/* 301 */     this.open = open;
  }

  public String getInAdjustType()
  {
/* 307 */     return this.inAdjustType;
  }

  public void setInAdjustType(String inAdjustType)
  {
/* 313 */     this.inAdjustType = inAdjustType;
  }

  public String getOutAdjustType()
  {
/* 319 */     return this.outAdjustType;
  }

  public void setOutAdjustType(String outAdjustType)
  {
/* 325 */     this.outAdjustType = outAdjustType;
  }

  public TrxModel getInTrxModel()
  {
/* 331 */     return this.inTrxModel;
  }

  public void setInTrxModel(TrxModel inTrxModel)
  {
/* 337 */     this.inTrxModel = inTrxModel;
  }

  public TrxModel getOutTrxModel()
  {
/* 343 */     return this.outTrxModel;
  }

  public void setOutTrxModel(TrxModel outTrxModel)
  {
/* 349 */     this.outTrxModel = outTrxModel;
  }

  public String getStatus()
  {
/* 355 */     return this.status;
  }

  public void setStatus(String status)
  {
/* 361 */     this.status = status;
  }

  public long getCloseFinal()
  {
/* 367 */     return this.closeFinal;
  }

  public void setCloseFinal(long closeFinal)
  {
/* 373 */     this.closeFinal = closeFinal;
  }
}