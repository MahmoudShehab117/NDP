/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class PriceGroupModel
/*    */ {
/*    */   private String priceGroupName;
/*    */   private String priceGroupCode;
/*    */   private PriceGroupGroup priceGroupGroupKey;
/*    */   private int oldPriceGroupGroupKey;
/*    */   private boolean update;
/*    */   private boolean original;
/*    */ 
/*    */   public boolean isUpdate()
/*    */   {
/* 19 */     return this.update;
/*    */   }
/*    */ 
/*    */   public void setUpdate(boolean update) {
/* 23 */     this.update = update;
/*    */   }
/*    */ 
/*    */   public String getPriceGroupCode() {
/* 27 */     return this.priceGroupCode;
/*    */   }
/*    */ 
/*    */   public void setPriceGroupCode(String priceGroupCode) {
/* 31 */     this.priceGroupCode = priceGroupCode;
/*    */   }
/*    */ 
/*    */   public String getPriceGroupName() {
/* 35 */     return this.priceGroupName;
/*    */   }
/*    */ 
/*    */   public void setPriceGroupName(String priceGroupName) {
/* 39 */     this.priceGroupName = priceGroupName;
/*    */   }
/*    */ 
/*    */   public PriceGroupGroup getPriceGroupGroupKey() {
/* 43 */     return this.priceGroupGroupKey;
/*    */   }
/*    */ 
/*    */   public void setPriceGroupGroupKey(PriceGroupGroup priceGroupGroupKey) {
/* 47 */     this.priceGroupGroupKey = priceGroupGroupKey;
/*    */   }
/*    */ 
/*    */   public int getOldPriceGroupGroupKey() {
/* 51 */     return this.oldPriceGroupGroupKey;
/*    */   }
/*    */ 
/*    */   public void setOldPriceGroupGroupKey(int oldPriceGroupGroupKey) {
/* 55 */     this.oldPriceGroupGroupKey = oldPriceGroupGroupKey;
/*    */   }
/*    */ 
/*    */   public boolean isOriginal()
/*    */   {
/* 62 */     return this.original;
/*    */   }
/*    */ 
/*    */   public void setOriginal(boolean original)
/*    */   {
/* 70 */     this.original = original;
/*    */   }
/*    */ }