/*    */ package com.vodafone.dailyreport.backend.util;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class DateParser
/*    */ {
/*    */   public static String getStringFromDate(Date date)
/*    */   {
/*  8 */     String DATE_FORMAT = "dd/MM/yyyy";
/*  9 */     SimpleDateFormat sdf = 
/* 10 */       new SimpleDateFormat(DATE_FORMAT);
/*    */ 
/* 12 */     return sdf.format(date);
/*    */   }
/*    */ 
/*    */   public static String getDetailsFromDate(Date date) {
/* 16 */     String DATE_FORMAT = "dd-MM-yyyy HH:mm";
/* 17 */     SimpleDateFormat sdf = 
/* 18 */       new SimpleDateFormat(DATE_FORMAT);
/*    */ 
/* 20 */     return sdf.format(date);
/*    */   }
/*    */ }