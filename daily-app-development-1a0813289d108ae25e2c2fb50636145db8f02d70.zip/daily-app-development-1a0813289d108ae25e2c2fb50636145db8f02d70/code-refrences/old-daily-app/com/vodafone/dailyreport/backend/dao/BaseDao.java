package com.vodafone.dailyreport.backend.dao;

import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.log.LogHandler;
import com.vodafone.dailyreport.backend.model.QueryModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.logging.Level;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BaseDao
{
/*  29 */   private static DataSource dataSource = null;

/*  34 */   public static LogHandler LOGGERDAO = LogHandler.getLogger();
  static final String driverClass = "oracle.jdbc.driver.OracleDriver";
  static final String connectionURLOCI = "jdbc:oracle:oci8:@CUSTDB_JEFFREYH3";
  static final String connectionURLThin = "jdbc:oracle:thin:@10.230.85.142:1521/cbatestsrv";
  static final String userID = "sanwar1";
  static final String userPassword = "SANWAR1";

  public static DataSource getDataSource()
  {
/*  41 */     if (dataSource == null) {
      try
      {
/*  44 */         Hashtable env = new Hashtable();

/*  46 */         env.put("java.naming.factory.initial", 
/*  47 */           "weblogic.jndi.WLInitialContextFactory");
/*  48 */         Context ctx = new InitialContext(env);
/*  49 */         dataSource = (DataSource)ctx.lookup(BackEndConstants.DATA_SOURCE_NAME);
/*  50 */         ctx.close();
      } catch (NamingException exception) {
/*  52 */         LOGGERDAO.log(Level.SEVERE, exception.getMessage());
/*  53 */         exception.printStackTrace();
      }

    }

/*  64 */     return dataSource;
  }

  public static Connection getConnection()
  {
/*  71 */     Connection connection = null;
    try
    {
/*  74 */       connection = getDataSource().getConnection();
    }
    catch (Exception e)
    {
      try
      {
/* 101 */         Class.forName("oracle.jdbc.OracleDriver");
      }
      catch (ClassNotFoundException e1) {
/* 104 */         e1.printStackTrace();
      }
      try {
/* 107 */         Class.forName("oracle.jdbc.OracleDriver");
/* 108 */         connection = DriverManager.getConnection("jdbc:oracle:thin:@10.230.85.142:1521/cbatestsrv", 
/* 109 */           "sanwar1", "SANWAR1");
      }
      catch (Exception e1) {
/* 112 */         e1.printStackTrace();
      }
    }

/* 116 */     return connection;
  }

  public void closeConnection(Connection connection, PreparedStatement statement)
  {
    try
    {
/* 127 */       statement.close();
/* 128 */       connection.close();
    } catch (SQLException e) {
/* 130 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 131 */       e.printStackTrace();
    }
  }

  public QueryModel getQuery(int key)
  {
/* 142 */     Connection connection = getConnection();
/* 143 */     PreparedStatement statement = null;
/* 144 */     QueryModel queryModel = null;
    try
    {
/* 147 */       statement = connection
/* 148 */         .prepareStatement("select  query_Name  , query_Desc , sql , seq ,id   from Daily_Queries where id= ? order by   seq ");
/* 149 */       statement.setLong(1, key);
/* 150 */       ResultSet resultSet = statement.executeQuery();
/* 151 */       while (resultSet.next()) {
/* 152 */         String qName = resultSet.getString("query_Name");
/* 153 */         String qDesc = resultSet.getString("query_Desc");
/* 154 */         String qSql = resultSet.getString("sql");
/* 155 */         int seq = resultSet.getInt("seq");
/* 156 */         int id = resultSet.getInt("id");

/* 158 */         queryModel = new QueryModel(qName, qDesc, qSql, seq, id);
      }
/* 160 */       connection.close();
    } catch (Exception e) {
      try {
/* 163 */         connection.close();
/* 164 */         LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 165 */         e.printStackTrace();
      } catch (SQLException e1) {
/* 167 */         e1.printStackTrace();
      }
    }

/* 171 */     return queryModel;
  }
}