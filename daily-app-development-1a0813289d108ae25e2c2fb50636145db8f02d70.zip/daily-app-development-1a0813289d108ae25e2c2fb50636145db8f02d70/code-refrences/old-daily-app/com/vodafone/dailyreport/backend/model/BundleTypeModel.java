/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class BundleTypeModel
/*    */ {
/*    */   private int id;
/*    */   private String key;
/*    */   private String value;
/*    */ 
/*    */   public int getId()
/*    */   {
/*  9 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(int id) {
/* 13 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getKey() {
/* 17 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(String key) {
/* 21 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 25 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 29 */     this.value = value;
/*    */   }
/*    */ }