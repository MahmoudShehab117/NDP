/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class Comment
/*    */ {
/*    */   private String date;
/*    */   private String comment;
/*    */   private String cat;
/*    */   private int dateKey;
/*    */   private int key;
/*    */ 
/*    */   public Comment(String date, String comment, String cat, int dateKey, int key)
/*    */   {
/* 12 */     this.date = date;
/* 13 */     this.comment = comment;
/* 14 */     this.cat = cat;
/* 15 */     this.dateKey = dateKey;
/* 16 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public int getKey()
/*    */   {
/* 22 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(int key)
/*    */   {
/* 28 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String getComment()
/*    */   {
/* 34 */     return this.comment;
/*    */   }
/*    */ 
/*    */   public void setComment(String comment)
/*    */   {
/* 40 */     this.comment = comment;
/*    */   }
/*    */ 
/*    */   public String getDate()
/*    */   {
/* 46 */     return this.date;
/*    */   }
/*    */ 
/*    */   public void setDate(String date)
/*    */   {
/* 52 */     this.date = date;
/*    */   }
/*    */ 
/*    */   public int getDateKey()
/*    */   {
/* 58 */     return this.dateKey;
/*    */   }
/*    */ 
/*    */   public void setDateKey(int dateKey)
/*    */   {
/* 64 */     this.dateKey = dateKey;
/*    */   }
/*    */ 
/*    */   public String getCat()
/*    */   {
/* 70 */     return this.cat;
/*    */   }
/*    */ 
/*    */   public void setCat(String cat)
/*    */   {
/* 76 */     this.cat = cat;
/*    */   }
/*    */ 
/*    */   public Comment(String date, String comment, String cat) {
/* 80 */     this.date = date;
/* 81 */     this.comment = comment;
/* 82 */     this.cat = cat;
/*    */   }
/*    */ }