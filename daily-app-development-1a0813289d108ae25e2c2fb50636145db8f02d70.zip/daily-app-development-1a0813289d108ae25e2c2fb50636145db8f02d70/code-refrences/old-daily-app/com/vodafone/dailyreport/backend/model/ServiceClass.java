package com.vodafone.dailyreport.backend.model;

public class ServiceClass
{
  private String scName;
  private int scCode;
  private boolean scEnt;
  private boolean scConsumer;
  private boolean scPre;
  private boolean scPost;
  private boolean scHybird;
  private String bundleType;
  private boolean activationSource;
  private boolean deacSource;
  private boolean oldDeacSource;
  boolean update;
  private String typeFlag;
  private String contractFlag;
  private boolean OldscEnt;
  private boolean OldscConsumer;
  private boolean OldscPre;
  private boolean OldscPost;
  private boolean OldactivationSource;
  private boolean oldPre;
  private boolean oldPost;

  public String getContractFlag(boolean ifNull)
  {
/*  39 */     return this.contractFlag; } 
/*  40 */   public String getTypeFlag(boolean ifNull) { return this.typeFlag; }

  public String getContractFlag()
  {
/*  44 */     return this.contractFlag;
  }

  public void setContractFlag(String contractFlag)
  {
/*  49 */     this.contractFlag = contractFlag;
  }

  public void setTypeFlag(String typeFlag)
  {
/*  55 */     this.typeFlag = typeFlag;
  }

  public String getTypeFlag() {
/*  59 */     return this.typeFlag;
  }

  public boolean isScConsumer()
  {
/*  67 */     return this.contractFlag.equals("1");
  }

  public boolean isScEnt()
  {
/*  75 */     return this.contractFlag.equals("2");
  }

  public boolean isScPost()
  {
/*  83 */     return this.typeFlag.equals("2");
  }

  public boolean isScPre()
  {
/*  92 */     return this.typeFlag.equals("1");
  }

  public boolean isUpdate()
  {
/* 101 */     return this.update;
  }

  public void setUpdate(boolean update) {
/* 105 */     this.update = update;
  }

  public boolean isActivationSource()
  {
/* 112 */     return this.activationSource;
  }

  public void setActivationSource(boolean activationSource)
  {
/* 120 */     this.activationSource = activationSource;
  }

  public int getScCode()
  {
/* 127 */     return this.scCode;
  }

  public void setScCode(int scCode)
  {
/* 135 */     this.scCode = scCode;
  }

  public void setScConsumer(boolean scConsumer)
  {
/* 145 */     this.scConsumer = scConsumer;
  }

  public void setScEnt(boolean scEnt)
  {
/* 158 */     this.scEnt = scEnt;
  }

  public String getScName()
  {
/* 165 */     return this.scName;
  }

  public void setScName(String scName)
  {
/* 173 */     this.scName = scName;
  }

  public void setScPost(boolean scPost)
  {
/* 186 */     this.scPost = scPost;
  }

  public void setScPre(boolean scPre)
  {
/* 199 */     this.scPre = scPre;
  }
  public boolean isOldactivationSource() {
/* 202 */     return this.OldactivationSource;
  }
  public void setOldactivationSource(boolean oldactivationSource) {
/* 205 */     this.OldactivationSource = oldactivationSource;
  }
  public boolean isOldscConsumer() {
/* 208 */     return this.OldscConsumer;
  }
  public void setOldscConsumer(boolean oldscConsumer) {
/* 211 */     this.OldscConsumer = oldscConsumer;
  }
  public boolean isOldscEnt() {
/* 214 */     return this.OldscEnt;
  }
  public void setOldscEnt(boolean oldscEnt) {
/* 217 */     this.OldscEnt = oldscEnt;
  }
  public boolean isOldscPost() {
/* 220 */     return this.OldscPost;
  }
  public void setOldscPost(boolean oldscPost) {
/* 223 */     this.OldscPost = oldscPost;
  }
  public boolean isOldscPre() {
/* 226 */     return this.OldscPre;
  }
  public void setOldscPre(boolean oldscPre) {
/* 229 */     this.OldscPre = oldscPre;
  }

  public boolean isDeacSource()
  {
/* 235 */     return this.deacSource;
  }

  public void setDeacSource(boolean deacSource)
  {
/* 241 */     this.deacSource = deacSource;
  }

  public boolean isOldDeacSource()
  {
/* 247 */     return this.oldDeacSource;
  }

  public void setOldDeacSource(boolean oldDeacSource)
  {
/* 253 */     this.oldDeacSource = oldDeacSource;
  }
  public void setScHybird(boolean scHybird) {
/* 256 */     this.scHybird = scHybird;
  }
  public boolean isScHybird() {
/* 259 */     return this.scHybird;
  }
  public void setBundleType(String bundleType) {
/* 262 */     this.bundleType = bundleType;
  }
  public String getBundleType() {
/* 265 */     return this.bundleType.toLowerCase();
  }
  public boolean isOldPre() {
/* 268 */     return this.oldPre;
  }
  public void setOldPre(boolean oldPre) {
/* 271 */     this.oldPre = oldPre;
  }
  public boolean isOldPost() {
/* 274 */     return this.oldPost;
  }
  public void setOldPost(boolean oldPost) {
/* 277 */     this.oldPost = oldPost;
  }
}