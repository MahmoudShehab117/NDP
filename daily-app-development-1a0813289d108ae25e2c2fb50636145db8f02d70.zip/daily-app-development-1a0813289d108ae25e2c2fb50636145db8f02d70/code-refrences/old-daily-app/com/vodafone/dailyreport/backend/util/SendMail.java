/*    */ package com.vodafone.dailyreport.backend.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Arrays;
/*    */ import java.util.Date;
/*    */ import java.util.Properties;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.mail.Authenticator;
/*    */ import javax.mail.Message.RecipientType;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.PasswordAuthentication;
/*    */ import javax.mail.Session;
/*    */ import javax.mail.Transport;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class SendMail
/*    */ {
/*    */   public static void sendMail(File attachFile, String subject, String msgText)
/*    */     throws Exception
/*    */   {
/* 16 */     Logger logger = Logger.getLogger(SendMail.class);
/* 17 */     logger.debug("sendMail Method");
/*    */ 
/* 19 */     ResourceBundle bundle = ResourceBundle.getBundle("com.vodafone.dailyreport.backend.util.ApplicationResources");
/*    */ 
/* 22 */     Properties props = System.getProperties();
/* 23 */     props.put("mail.transport.protocol", bundle.getString("mail.transport"));
/* 24 */     logger.debug(bundle.getString("mail.transport") + "  " + bundle.getString("mail.smtp.host") + "  " + bundle.getString("mail.smtp.auth"));
/* 25 */     props.put("mail.smtp.host", bundle.getString("mail.smtp.host"));
/* 26 */     props.put("mail.smtp.auth", bundle.getString("mail.smtp.auth"));
/* 27 */     props.put("mail.smtp.port", bundle.getString("mail.smtp.port"));
/*    */      tmp149_146 = new SendMail(); tmp149_146.getClass(); Authenticator auth = new SMTPAuthenticator(null);
/* 30 */     Session session = Session.getInstance(props, auth);
/*    */     try
/*    */     {
/* 35 */       logger.debug("create a message ");
/* 36 */       MimeMessage msg = new MimeMessage(session);
/* 37 */       logger.debug("mail.smtp.user" + bundle.getString("mail.smtp.user") + " -> " + bundle.getString("mail.smtp.username"));
/* 38 */       msg.setFrom(new InternetAddress(bundle.getString("mail.smtp.user"), bundle.getString("mail.smtp.username")));
/* 39 */       InternetAddress[] toAddress = new InternetAddress[2];
/* 40 */       toAddress[0] = new InternetAddress(bundle.getString("mail.to1"));
/* 41 */       toAddress[1] = new InternetAddress(bundle.getString("mail.to2"));
/* 42 */       InternetAddress[] ccAddress = { new InternetAddress(bundle.getString("mail.cc")) };
/*    */ 
/* 44 */       msg.setRecipients(Message.RecipientType.TO, toAddress);
/* 45 */       msg.setRecipients(Message.RecipientType.CC, ccAddress);
/*    */ 
/* 47 */       logger.debug("To : " + Arrays.toString(toAddress));
/* 48 */       logger.debug("CC : " + Arrays.toString(ccAddress));
/*    */ 
/* 50 */       logger.debug("subject " + subject);
/* 51 */       msg.setSubject(subject);
/* 52 */       logger.debug("msgText " + msgText);
/* 53 */       msg.setText(msgText);
/*    */ 
/* 56 */       msg.setSentDate(new Date());
/*    */ 
/* 59 */       logger.debug("send the message");
/* 60 */       Transport.send(msg);
/* 61 */       logger.debug("sent mail");
/*    */     }
/*    */     catch (MessagingException mex) {
/* 64 */       logger.debug("MessagingException " + mex.getMessage());
/* 65 */       mex.printStackTrace();
/* 66 */       Exception ex = null;
/* 67 */       if ((ex = mex.getNextException()) != null)
/* 68 */         ex.printStackTrace(); 
/*    */     }
/*    */   }
/*    */ 
/*    */   private class SMTPAuthenticator extends Authenticator {
/*    */     private SMTPAuthenticator() {
/*    */     }
/*    */ 
/*    */     public PasswordAuthentication getPasswordAuthentication() {
/*    */       try {
/* 76 */         ResourceBundle bundle = null;
/* 77 */         bundle = ResourceBundle.getBundle("com.vodafone.dailyreport.backend.util.ApplicationResources");
/* 78 */         String username = bundle.getString("mail.username");
/* 79 */         String password = bundle.getString("mail.password");
/* 80 */         return new PasswordAuthentication(username, password);
/*    */       }
/*    */       catch (Exception localException)
/*    */       {
/*    */       }
/* 85 */       return null;
/*    */     }
/*    */   }
/*    */ }