/*    */ package com.vodafone.dailyreport.backend.dao;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.constant.BackEndConstants;
/*    */ import com.vodafone.dailyreport.backend.log.LogHandler;
/*    */ import com.vodafone.dailyreport.backend.model.Comment;
/*    */ import com.vodafone.dailyreport.backend.model.QueryModel;
/*    */ import com.vodafone.dailyreport.backend.util.DateParser;
/*    */ import java.io.PrintStream;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.util.ArrayList;
/*    */ import java.util.logging.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class CommentsDao extends BaseDao
/*    */ {
/* 20 */   public static Logger logger = Logger.getLogger(CommentsDao.class.getName());
/*    */ 
/*    */   public void addComments(Comment comment)
/*    */   {
/* 24 */     Connection connection = null;
/* 25 */     PreparedStatement statement = null;
/* 26 */     QueryModel query = getQuery(BackEndConstants.ADD_COMMENTS);
/* 27 */     String querySql = query.getSql();
/*    */ 
/* 29 */     String values = "Query Values: ";
/*    */     try {
/* 31 */       System.out.println(querySql);
/* 32 */       connection = getConnection();
/* 33 */       statement = connection.prepareStatement(querySql);
/* 34 */       statement.setString(1, comment.getComment());
/* 35 */       values = values + " Param1=" + comment.getComment() + " - ";
/* 36 */       statement.setString(2, comment.getDate());
/* 37 */       values = values + " Param2=" + comment.getDate() + " - ";
/* 38 */       statement.setString(3, comment.getDate());
/* 39 */       values = values + " Param3=" + comment.getDate() + " - ";
/* 40 */       statement.setString(4, comment.getCat());
/* 41 */       values = values + " Param4=" + comment.getCat() + " - ";
/* 42 */       statement.executeUpdate();
/* 43 */       logger.info("Query : " + querySql);
/* 44 */       logger.info("Query values : " + values);
/* 45 */       connection.commit();
/*    */ 
/* 47 */       closeConnection(connection, statement);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 51 */       e.printStackTrace();
/* 52 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 53 */       closeConnection(connection, statement);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ArrayList getComments(String day)
/*    */   {
/* 62 */     Connection connection = null;
/* 63 */     PreparedStatement statement = null;
/* 64 */     QueryModel query = getQuery(BackEndConstants.GET_COMMENTS);
/* 65 */     String querySql = query.getSql();
/* 66 */     ResultSet resultSet = null;
/* 67 */     ArrayList result = new ArrayList();
/*    */     try {
/* 69 */       connection = getConnection();
/* 70 */       System.out.println(querySql);
/* 71 */       statement = connection.prepareStatement(querySql);
/* 72 */       statement.setString(1, day);
/* 73 */       logger.info("Query : " + querySql);
/* 74 */       logger.info("Query values Param1=: " + day);
/* 75 */       resultSet = statement.executeQuery();
/* 76 */       while (resultSet.next()) {
/* 77 */         Comment comment = new Comment(DateParser.getStringFromDate(resultSet.getDate("FULL_DATE")), 
/* 78 */           resultSet.getString("DAILY_COMMENT"), resultSet.getString("CATEGEORY"), resultSet.getInt("DATE_KEY"), 
/* 79 */           resultSet.getInt("COMMNET_KEY"));
/* 80 */         result.add(comment);
/*    */       }
/* 82 */       closeConnection(connection, statement);
/* 83 */       return result;
/*    */     }
/*    */     catch (Exception e) {
/* 86 */       e.printStackTrace();
/* 87 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 88 */       closeConnection(connection, statement);
/* 89 */     }return result;
/*    */   }
/*    */ }