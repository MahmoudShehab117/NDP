package com.vodafone.dailyreport.backend.dao;

import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.log.LogHandler;
import com.vodafone.dailyreport.backend.model.QueryModel;
import com.vodafone.dailyreport.backend.model.TotalModel;
import com.vodafone.dailyreport.backend.model.TrxModel;
import com.vodafone.dailyreport.backend.model.VeAggModel;
import com.vodafone.dailyreport.backend.util.DateParser;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import org.apache.log4j.Logger;

public class VeDao extends BaseDao
{
/*  25 */   public static Logger logger = Logger.getLogger(VeDao.class);

  public ArrayList getOriginalVeData(String dateSearch)
  {
/*  29 */     Connection connection = null;
/*  30 */     PreparedStatement statement = null;
/*  31 */     ResultSet resultSet = null;
/*  32 */     QueryModel query = getQuery(BackEndConstants.VE_ORIGINAL);
/*  33 */     System.out.println(query);
/*  34 */     String querySql = query.getSql();
/*  35 */     System.out.println(querySql);
/*  36 */     String values = "Query Values: ";

/*  38 */     ArrayList aggList = new ArrayList();
    try {
/*  40 */       connection = getConnection();
/*  41 */       statement = connection.prepareStatement(querySql);
/*  42 */       statement.setString(1, dateSearch);
/*  43 */       values = values + " Param1=" + dateSearch + " - ";
/*  44 */       statement.setString(2, dateSearch);
/*  45 */       values = values + " Param2=" + dateSearch + " - ";
/*  46 */       statement.setString(3, dateSearch);
/*  47 */       values = values + " Param3=" + dateSearch + " - ";
/*  48 */       logger.info("Query : " + querySql);
/*  49 */       logger.info("Query values : " + values);
/*  50 */       resultSet = statement.executeQuery();
/*  51 */       while (resultSet.next()) {
/*  52 */         VeAggModel aggModel = new VeAggModel();
/*  53 */         long insubs = resultSet.getLong("IN_SUBS");
/*  54 */         long open = resultSet.getLong("OPENING");
/*  55 */         long close = resultSet.getLong("CLOSING");
/*  56 */         long outsubs = resultSet.getLong("OUT_SUBS");
/*  57 */         int dateKey = resultSet.getInt("DATE_KEY");
/*  58 */         int ratePlanKey = resultSet.getInt("RATE_PLAN_KEY");
/*  59 */         String ratePlan = resultSet.getString("rate_plan");
/*  60 */         String date = resultSet.getString("full_date");
/*  61 */         String status = resultSet.getString("DWH_STATUS");
/*  62 */         int statusKey = resultSet.getInt("DWH_STATUS_KEY");

/*  67 */         aggModel.setDate(date);
/*  68 */         aggModel.setInSubs(insubs);
/*  69 */         aggModel.setOutSubs(outsubs);
/*  70 */         aggModel.setDateKey(dateKey);
/*  71 */         aggModel.setDateKey(dateKey);
/*  72 */         aggModel.setOpen(open);
/*  73 */         aggModel.setClose(close);
/*  74 */         aggModel.setStatus(status);
/*  75 */         aggModel.setDwhStatusKey(statusKey);

/*  77 */         aggModel.setRatePlan(ratePlan);

/*  79 */         aggModel.setRatePlanKey(ratePlanKey);

/*  85 */         aggList.add(aggModel);
      }

/*  89 */       closeConnection(connection, statement);
/*  90 */       return aggList;
    } catch (Exception e) {
/*  92 */       System.out.println(e.getMessage());
/*  93 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  94 */       closeConnection(connection, statement);
/*  95 */     }return aggList;
  }

  public ArrayList getTrx()
  {
/* 103 */     Connection connection = null;
/* 104 */     PreparedStatement statement = null;
/* 105 */     ResultSet resultSet = null;
/* 106 */     QueryModel query = getQuery(BackEndConstants.GET_TRX);
/* 107 */     System.out.println(query);
/* 108 */     String querySql = query.getSql();
/* 109 */     logger.info("Query : " + querySql);
/* 110 */     System.out.println(querySql);

/* 112 */     ArrayList aggList = new ArrayList();
    try {
/* 114 */       connection = getConnection();
/* 115 */       statement = connection.prepareStatement(querySql);
/* 116 */       resultSet = statement.executeQuery();
/* 117 */       while (resultSet.next()) {
/* 118 */         TrxModel trxModel = new TrxModel(
/* 119 */           resultSet.getString("TRX_TYPE_NAME"), 
/* 120 */           resultSet.getInt("TRX_TYPE_KEY"), 
/* 121 */           resultSet.getInt("VALUE"));

/* 124 */         aggList.add(trxModel);
      }

/* 128 */       closeConnection(connection, statement);
/* 129 */       return aggList;
    } catch (Exception e) {
/* 131 */       System.out.println(e.getMessage());
/* 132 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 133 */       closeConnection(connection, statement);
/* 134 */     }return aggList;
  }

  public TotalModel getTotalTrx(String dateSearch)
  {
/* 144 */     Connection connection = null;
/* 145 */     PreparedStatement statement = null;
/* 146 */     ResultSet resultSet = null;
/* 147 */     QueryModel query = getQuery(BackEndConstants.GET_ALL);
/* 148 */     System.out.println(query);
/* 149 */     String querySql = query.getSql();
/* 150 */     System.out.println(querySql);
/* 151 */     logger.info("Query : " + querySql);
/* 152 */     TotalModel totalModel = new TotalModel();
    try
    {
/* 155 */       connection = getConnection();
/* 156 */       statement = connection.prepareStatement(querySql);
/* 157 */       statement.setString(1, dateSearch);
/* 158 */       statement.setString(2, dateSearch);
/* 159 */       resultSet = statement.executeQuery();
/* 160 */       while (resultSet.next()) {
/* 161 */         totalModel = new TotalModel(
/* 162 */           resultSet.getLong("CLOSING"), 
/* 163 */           resultSet.getLong("OPENING"));
                }

/* 171 */       closeConnection(connection, statement);
/* 172 */       return totalModel;
    } catch (Exception e) {
/* 174 */       System.out.println(e.getMessage());
/* 175 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 176 */       closeConnection(connection, statement);
/* 177 */     }return totalModel;
  }

  public int insertDeVeData(ArrayList aggModel)
  {
/* 184 */     Connection connection = null;
/* 185 */     PreparedStatement statement = null;
/* 186 */     ResultSet resultSet = null;
/* 187 */     QueryModel query = getQuery(BackEndConstants.UPDATE);
/* 188 */     String querySql = query.getSql();
    try
    {
/* 192 */       connection = getConnection();
/* 193 */       statement = connection.prepareStatement(querySql);
/* 194 */       System.out.println(querySql);
/* 195 */       Iterator it = aggModel.iterator();
/* 196 */       while (it.hasNext()) {
/* 197 */         String values = "Query Values: ";
/* 198 */         VeAggModel model = (VeAggModel)it.next();
/* 199 */         if (model.isInApply()) {
/* 200 */           statement.setInt(1, model.getInTrxModel().getKey());
/* 201 */           values = values + " Param1=" + model.getInTrxModel().getKey() + " - ";
/* 202 */           statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 203 */           values = values + " Param2=" + DateParser.getStringFromDate(new Date()) + " - ";
/* 204 */           statement.setInt(3, model.getRatePlanKey());
/* 205 */           values = values + " Param3=" + model.getRatePlanKey() + " - ";
/* 206 */           statement.setInt(4, model.getDateKey());
/* 207 */           values = values + " Param4=" + model.getDateKey() + " - ";
/* 208 */           statement.setInt(5, 1);
/* 209 */           values = values + " Param5=1 - ";
/* 210 */           statement.setInt(6, model.getDwhStatusKey());
/* 211 */           values = values + " Param6=" + model.getDwhStatusKey();
/* 212 */           logger.info("Query : " + querySql);
/* 213 */           logger.info("Query values : " + values);
/* 214 */           statement.addBatch();
                  }

/* 217 */         if (model.isOutApply()) {
/* 218 */           statement.setInt(1, model.getOutTrxModel().getKey());
/* 219 */           values = values + " Param1=" + model.getOutTrxModel().getKey() + " - ";
/* 220 */           statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 221 */           values = values + " Param2=" + DateParser.getStringFromDate(new Date()) + " - ";
/* 222 */           statement.setInt(3, model.getRatePlanKey());
/* 223 */           values = values + " Param3=" + model.getRatePlanKey() + " - ";
/* 224 */           statement.setInt(4, model.getDateKey());
/* 225 */           values = values + " Param4=" + model.getDateKey() + " - ";
/* 226 */           statement.setInt(5, 2);
/* 227 */           values = values + " Param5=2 - ";
/* 228 */           statement.setInt(6, model.getDwhStatusKey());
/* 229 */           values = values + " Param6=" + model.getDwhStatusKey();
/* 230 */           logger.info("Query : " + querySql);
/* 231 */           logger.info("Query values : " + values);
/* 232 */           statement.addBatch();
        }

      }

/* 240 */       int result = 0;
/* 241 */       statement.executeBatch();
/* 242 */       connection.commit();
/* 243 */       closeConnection(connection, statement);
/* 244 */       return result;
    } catch (Exception e) {
/* 246 */       e.printStackTrace();
/* 247 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 248 */       closeConnection(connection, statement);
/* 249 */     }return -1;
  }

  public int commitAdjustment(ArrayList aggModel)
  {
/* 257 */     Connection connection = null;
/* 258 */     PreparedStatement statement = null;
/* 259 */     QueryModel query = getQuery(BackEndConstants.COMMIT_ADJUST);
/* 260 */     String querySql = query.getSql();
    try
    {
/* 265 */       connection = getConnection();
/* 266 */       statement = connection.prepareStatement(querySql);

/* 269 */       System.out.println(querySql);
/* 270 */       Iterator it = aggModel.iterator();
/* 271 */       while (it.hasNext()) {
/* 272 */         String values = "Query Values: ";
/* 273 */         VeAggModel model = (VeAggModel)it.next();
/* 274 */         if (model.isInApply()) {
/* 275 */           statement.setInt(1, model.getRatePlanKey());
/* 276 */           values = values + " Param1=" + model.getRatePlanKey() + " - ";
/* 277 */           statement.setInt(2, model.getDateKey());
/* 278 */           values = values + " Param2=" + model.getDateKey() + " - ";
/* 279 */           statement.setInt(3, 1);
/* 280 */           values = values + " Param3=1 - ";
/* 281 */           statement.setInt(4, model.getDwhStatusKey());
/* 282 */           values = values + " Param4=" + model.getDwhStatusKey();
/* 283 */           logger.info("Query : " + querySql);
/* 284 */           logger.info("Query values : " + values);
/* 285 */           statement.addBatch();
        }

/* 288 */         if (!model.isOutApply())
          continue;
/* 290 */         statement.setInt(1, model.getRatePlanKey());
/* 291 */         values = values + " Param1=" + model.getRatePlanKey() + " - ";
/* 292 */         statement.setInt(2, model.getDateKey());
/* 293 */         values = values + " Param2=" + model.getDateKey() + " - ";
/* 294 */         statement.setInt(3, 2);
/* 295 */         values = values + " Param3=2 - ";
/* 296 */         statement.setInt(4, model.getDwhStatusKey());
/* 297 */         values = values + " Param4=" + model.getDwhStatusKey();
/* 298 */         logger.info("Query : " + querySql);
/* 299 */         logger.info("Query values : " + values);
/* 300 */         statement.addBatch();
      }

/* 308 */       int result = 0;
/* 309 */       statement.executeBatch();
/* 310 */       connection.commit();
/* 311 */       closeConnection(connection, statement);
/* 312 */       return result;
    } catch (Exception e) {
/* 314 */       e.printStackTrace();
/* 315 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 316 */       closeConnection(connection, statement);
/* 317 */     }return -1;
  }

  public int insertDaily(int userid, int dateKey)
  {
/* 325 */     Connection connection = null;
/* 326 */     PreparedStatement statement = null;
/* 327 */     QueryModel query = getQuery(BackEndConstants.UPDATE2);
/* 328 */     String querySql = query.getSql();
    try
    {
/* 333 */       connection = getConnection();
/* 334 */       statement = connection.prepareStatement(querySql);
/* 335 */       System.out.println(querySql);

/* 337 */       String values = "Query Values: ";
/* 338 */       statement.setInt(1, userid);
/* 339 */       values = values + " Param1=" + userid + " - ";
/* 340 */       statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 341 */       values = values + " Param2=" + DateParser.getStringFromDate(new Date()) + " - ";
/* 342 */       statement.setInt(3, dateKey);
/* 343 */       values = values + " Param3=" + dateKey + " - ";
/* 344 */       statement.setString(4, DateParser.getStringFromDate(new Date()));
/* 345 */       values = values + " Param4=" + DateParser.getStringFromDate(new Date());
/* 346 */       System.out.println(querySql + " " + userid + dateKey);
/* 347 */       statement.executeUpdate();
/* 348 */       logger.info("Query : " + querySql);
/* 349 */       logger.info("Query values : " + values);

/* 354 */       int result = 0;

/* 356 */       connection.commit();
/* 357 */       closeConnection(connection, statement);
/* 358 */       return result;
    } catch (Exception e) {
/* 360 */       e.printStackTrace();
/* 361 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 362 */       closeConnection(connection, statement);
/* 363 */     }return -1;
  }

  public int insertClosing(int userid, int dateKey)
  {
/* 371 */     Connection connection = null;
/* 372 */     PreparedStatement statement = null;
/* 373 */     QueryModel query = getQuery(BackEndConstants.UPDATE3);
/* 374 */     String querySql = query.getSql();
    try
    {
/* 379 */       connection = getConnection();
/* 380 */       statement = connection.prepareStatement(querySql);
/* 381 */       System.out.println(querySql);

/* 383 */       String values = "Query Values: ";
/* 384 */       statement.setInt(1, userid);
/* 385 */       values = values + " Param1=" + userid + " - ";
/* 386 */       statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 387 */       values = values + " Param2=" + DateParser.getStringFromDate(new Date());
/* 388 */       statement.setInt(3, dateKey);
/* 389 */       values = values + " Param3=" + dateKey + " - ";
/* 390 */       statement.setString(4, DateParser.getStringFromDate(new Date()));
/* 391 */       values = values + " Param4=" + DateParser.getStringFromDate(new Date());
/* 392 */       System.out.println(querySql + " " + userid + dateKey);
/* 393 */       statement.executeUpdate();
/* 394 */       logger.info("Query : " + querySql);
/* 395 */       logger.info("Query values : " + values);

/* 401 */       int result = 0;

/* 403 */       connection.commit();
/* 404 */       closeConnection(connection, statement);
/* 405 */       return result;
    } catch (Exception e) {
/* 407 */       e.printStackTrace();
/* 408 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 409 */       closeConnection(connection, statement);
/* 410 */     }return -1;
  }

  public int insertNetAdds(int userid, int dateKey)
  {
/* 418 */     Connection connection = null;
/* 419 */     PreparedStatement statement = null;
/* 420 */     QueryModel query = getQuery(BackEndConstants.NETADDS);
/* 421 */     String querySql = query.getSql();
    try
    {
/* 426 */       connection = getConnection();
/* 427 */       statement = connection.prepareStatement(querySql);
/* 428 */       System.out.println(querySql);

/* 430 */       String values = "Query Values: ";
/* 431 */       statement.setInt(1, userid);
/* 432 */       values = values + " Param1=" + userid + " - ";
/* 433 */       statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 434 */       values = values + " Param2=" + DateParser.getStringFromDate(new Date());
/* 435 */       statement.setInt(3, dateKey);
/* 436 */       values = values + " Param3=" + dateKey + " - ";
/* 437 */       statement.setString(4, DateParser.getStringFromDate(new Date()));
/* 438 */       values = values + " Param4=" + DateParser.getStringFromDate(new Date());
/* 439 */       System.out.println(querySql + " " + userid + dateKey);
/* 440 */       statement.executeUpdate();
/* 441 */       logger.info("Query : " + querySql);
/* 442 */       logger.info("Query values : " + values);

/* 447 */       int result = 0;

/* 449 */       connection.commit();
/* 450 */       closeConnection(connection, statement);
/* 451 */       return result;
    } catch (Exception e) {
/* 453 */       e.printStackTrace();
/* 454 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 455 */       closeConnection(connection, statement);
/* 456 */     }return -1;
  }

  public int insertPerContracData(ArrayList aggModel)
  {
/* 465 */     Connection connection = null;
/* 466 */     PreparedStatement statement = null;
/* 467 */     ResultSet resultSet = null;
/* 468 */     QueryModel query = getQuery(BackEndConstants.UPDATE1);
/* 469 */     String querySql = query.getSql();
    try
    {
/* 474 */       connection = getConnection();
/* 475 */       statement = connection.prepareStatement(querySql);

/* 478 */       Iterator it = aggModel.iterator();
/* 479 */       while (it.hasNext()) {
/* 480 */         String values = "Query Values: ";
/* 481 */         VeAggModel model = (VeAggModel)it.next();
/* 482 */         if (model.isInApply()) {
/* 483 */           statement.setInt(1, model.getInTrxModel().getKey());
/* 484 */           values = values + " Param1=" + model.getInTrxModel().getKey() + " - ";
/* 485 */           statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 486 */           values = values + " Param2=" + DateParser.getStringFromDate(new Date()) + " - ";
/* 487 */           statement.setInt(3, model.getRatePlanKey());
/* 488 */           values = values + " Param3=" + model.getRatePlanKey() + " - ";
/* 489 */           statement.setInt(4, model.getDateKey());
/* 490 */           values = values + " Param4=" + model.getDateKey() + " - ";
/* 491 */           statement.setInt(5, 1);
/* 492 */           values = values + " Param5=1 - ";
/* 493 */           System.out.println(querySql + model.getInTrxModel().getKey() + DateParser.getStringFromDate(new Date()) + 
/* 494 */             model.getRatePlanKey() + model.getDateKey());
/* 495 */           statement.setInt(6, model.getDwhStatusKey());
/* 496 */           values = values + " Param6=" + model.getDwhStatusKey();
/* 497 */           logger.info("Query : " + querySql);
/* 498 */           logger.info("Query values : " + values);
/* 499 */           statement.addBatch();
        }

/* 502 */         if (model.isOutApply()) {
/* 503 */           statement.setInt(1, model.getOutTrxModel().getKey());
/* 504 */           values = values + " Param1=" + model.getOutTrxModel().getKey() + " - ";
/* 505 */           statement.setString(2, DateParser.getStringFromDate(new Date()));
/* 506 */           values = values + " Param2=" + DateParser.getStringFromDate(new Date()) + " - ";
/* 507 */           statement.setInt(3, model.getRatePlanKey());
/* 508 */           values = values + " Param3=" + model.getRatePlanKey() + " - ";
/* 509 */           statement.setInt(4, model.getDateKey());
/* 510 */           values = values + " Param4=" + model.getDateKey() + " - ";
/* 511 */           statement.setInt(5, 2);
/* 512 */           values = values + " Param5=2 - ";
/* 513 */           statement.setInt(6, model.getDwhStatusKey());
/* 514 */           values = values + " Param6=" + model.getDwhStatusKey();
/* 515 */           logger.info("Query : " + querySql);
/* 516 */           logger.info("Query values : " + values);
/* 517 */           statement.addBatch();
        }

      }

/* 525 */       int result = 0;
/* 526 */       statement.executeBatch();
/* 527 */       connection.commit();
/* 528 */       closeConnection(connection, statement);
/* 529 */       return result;
    } catch (Exception e) {
/* 531 */       e.printStackTrace();
/* 532 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 533 */       closeConnection(connection, statement);
/* 534 */     }return -1;
  }
}