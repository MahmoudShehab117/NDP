/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.VeDao;
/*    */ 
/*    */ public class VeService
/*    */ {
/* 10 */   private static VeDao veDao = new VeDao();
/*    */ 
/*    */   public static VeDao getDao()
/*    */   {
/* 16 */     return veDao;
/*    */   }
/*    */ }