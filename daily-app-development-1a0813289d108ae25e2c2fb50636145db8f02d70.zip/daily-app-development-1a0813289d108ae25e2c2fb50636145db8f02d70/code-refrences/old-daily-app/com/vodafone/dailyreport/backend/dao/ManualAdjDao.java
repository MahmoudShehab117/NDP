package com.vodafone.dailyreport.backend.dao;
/*     */
import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.log.LogHandler;
import com.vodafone.dailyreport.backend.model.AdjManualModel;
import com.vodafone.dailyreport.backend.model.ManualRecordModel;
import com.vodafone.dailyreport.backend.model.QueryModel;
import com.vodafone.dailyreport.backend.model.RATEPLANALL;
import com.vodafone.dailyreport.backend.model.TrxModel;
import com.vodafone.dailyreport.backend.util.DateParser;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import org.apache.log4j.Logger;

public class ManualAdjDao extends BaseDao
{
  public static Logger logger = Logger.getLogger(ManualAdjDao.class.getName());

  public ArrayList getAdjustmentData(String dateSearch) {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    QueryModel query = getQuery(BackEndConstants.GETADJDATA);
    System.out.println(query);
    String querySql = query.getSql();
    System.out.println(querySql);

    ArrayList aggList = new ArrayList();
    try {
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      statement.setString(1, dateSearch);
      statement.setString(2, dateSearch);
      logger.info("Query : " + querySql);
      logger.info("Query Values: Param1=" + dateSearch + " - " + "Param2=" + dateSearch);
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        ManualRecordModel aggModel = new ManualRecordModel();
        long open = resultSet.getLong("OPENING");
        long close = resultSet.getLong("CLOSING");
        int dateKey = resultSet.getInt("DATE_KEY");
        int ratePlanKey = resultSet.getInt("RATE_PLAN_KEY");
        String ratePlan = resultSet.getString("rate_plan");
        int groupKey = resultSet.getInt("RATE_PLAN_GROUP_KEY");
        String type = resultSet.getString("RATE_PLAN_TYPE");

        aggModel.setDateKey(dateKey);
        aggModel.setDateKey(dateKey);
        aggModel.setDateKey(dateKey);
        aggModel.setOpen(open);
        aggModel.setClose(close);
        aggModel.setRatePlanGroupKey(groupKey);
        aggModel.setRatePlan(ratePlan);
        aggModel.setRatePlanKey(ratePlanKey);
        aggModel.setType(type);

        aggList.add(aggModel);
      }

      closeConnection(connection, statement);
      return aggList;
    } catch (Exception e) {
      System.out.println(e.getMessage());
      LOGGERDAO.log(Level.SEVERE, e.getMessage());
      closeConnection(connection, statement);
    }return aggList;
  }

  public int getGroup(int key)
  {
    Connection connection = null;
    PreparedStatement statement = null;
    QueryModel query = getQuery(BackEndConstants.CREATE_GROUP);
    String querySql = "select PG_GROUP_KEY from price_group where PRICE_GROUP_KEY =" + key;
    int result = -1;
    logger.info("Query : " + querySql);
    logger.info("Query Values: Param1=" + key);
    try
    {
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      ResultSet resultSet = statement.executeQuery();
      while (resultSet.next()) {
        result = resultSet.getInt(1);
      }

      closeConnection(connection, statement);
      return result;
    }
    catch (Exception e) {
      e.printStackTrace();
      LOGGERDAO.log(Level.SEVERE, e.getMessage());
      closeConnection(connection, statement);
    }return result;
  }

  public void insertAdjustmentData(ArrayList adj)
  {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    QueryModel query = getQuery(BackEndConstants.INSERTADJDATA);
    System.out.println(query);
    String querySql = query.getSql();
    System.out.println(querySql);

    String values = "Query Values: ";
    try
    {
      Iterator it = adj.iterator();
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      while (it.hasNext()) {
        ManualRecordModel model = (ManualRecordModel)it.next();
        if (model.getAdjSubs() != 0L) {
          long subs = model.getAdjSubs();
          int trxKey = model.getTrxModel().getKey();
          int ratePlanGroup = model.getRatePlanGroupKey();
          int ratePlanKey = model.getRatePlanKey();
          int dateKey = model.getDateKey();
          String type = model.getType();
          statement.setLong(1, subs);
          values = values + " Param1=" + subs + " - ";
          statement.setInt(2, dateKey);
          values = values + " Param2=" + dateKey + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          }
          statement.setInt(4, ratePlanKey);
          values = values + " Param4=" + ratePlanKey + " - ";
          statement.setInt(5, trxKey);
          values = values + " Param5=" + trxKey + " - ";
          statement.setInt(6, ratePlanGroup);
          values = values + " Param6=" + ratePlanGroup + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(7, 1);
            values = values + " Param7=1 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(7, 15);
            values = values + " Param7=15 - ";
          }
          statement.setInt(8, 3);
          values = values + " Param8=3 - ";

          if ((type != null) && (type.equals("Postpaid"))) {
            int group = getGroup(1);
            statement.setInt(9, group);
            values = values + " Param9=1 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            int group = getGroup(15);
            statement.setInt(9, group);
            values = values + " Param9=" + group + " - ";
          }

          statement.setString(10, DateParser.getStringFromDate(new Date()));
          values = values + " Param10=" + DateParser.getStringFromDate(new Date());
          logger.info("Query : " + querySql);
          logger.info("Query values : " + values);
          statement.addBatch();
        }
      }

      statement.executeBatch();

      connection.commit();

      closeConnection(connection, statement);
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
      LOGGERDAO.log(Level.SEVERE, e.getMessage());
      closeConnection(connection, statement);
    }
  }

  public void insertClosingData(ArrayList adj)
  {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    QueryModel query = getQuery(BackEndConstants.INSERTADJDATA);
    System.out.println(query);
    String querySql = query.getSql();
    System.out.println(querySql);

    String values = "Query Values: ";
    try
    {
      Iterator it = adj.iterator();
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      while (it.hasNext())
      {
        ManualRecordModel model = (ManualRecordModel)it.next();
        if (model.getAdjSubs() != 0L) {
          long subs = model.getAdjSubs();
          int trxKey = model.getTrxModel().getKey();
          int ratePlanGroup = model.getRatePlanGroupKey();
          int ratePlanKey = model.getRatePlanKey();
          int dateKey = model.getDateKey();
          String type = model.getType();
          statement.setLong(1, subs);
          values = values + " Param1=" + subs + " - ";
          statement.setInt(2, dateKey);
          values = values + " Param2=" + dateKey + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          }
          statement.setInt(4, ratePlanKey);
          values = values + " Param4=" + ratePlanKey + " - ";
          statement.setInt(5, 17);
          values = values + " Param5=17 - ";
          statement.setInt(6, ratePlanGroup);
          values = values + " Param6=" + ratePlanGroup + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(7, 1);
            values = values + " Param7=1 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(7, 15);
            values = values + " Param7=15 - ";
          }
          statement.setInt(8, 3);
          values = values + " Param8=3 - ";

          if ((type != null) && (type.equals("Postpaid"))) {
            int group = getGroup(1);
            statement.setInt(9, group);
            values = values + " Param9=" + group + " - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            int group = getGroup(15);
            statement.setInt(9, group);
            values = values + " Param9=" + group + " - ";
          }
          statement.setString(10, DateParser.getStringFromDate(new Date()));
          values = values + " Param10=" + DateParser.getStringFromDate(new Date());
          logger.info("Query : " + querySql);
          logger.info("Query values : " + values);
          statement.addBatch();
        }
      }

      statement.executeBatch();

      connection.commit();

      closeConnection(connection, statement);
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
      LOGGERDAO.log(Level.SEVERE, e.getMessage());
      closeConnection(connection, statement);
    }
  }

  public void insertNetAdds(ArrayList adj)
  {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    QueryModel query = getQuery(BackEndConstants.INSERTADJDATA);
    System.out.println(query);

    String querySql = query.getSql();
    System.out.println(querySql);

    String values = "Query Values: ";
    try
    {
      Iterator it = adj.iterator();
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      while (it.hasNext())
      {
        ManualRecordModel model = (ManualRecordModel)it.next();
        if (model.getAdjSubs() != 0L) {
          long subs = model.getAdjSubs();
          int trxKey = model.getTrxModel().getKey();
          int ratePlanGroup = model.getRatePlanGroupKey();
          int ratePlanKey = model.getRatePlanKey();
          int dateKey = model.getDateKey();
          String type = model.getType();
          statement.setLong(1, subs);
          values = values + " Param1=" + subs + " - ";
          statement.setInt(2, dateKey);
          values = values + " Param2=" + dateKey + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(3, 22);
            values = values + " Param3=22 - ";
          }
          statement.setInt(4, ratePlanKey);
          values = values + " Param4=" + ratePlanKey + " - ";
          statement.setInt(5, 16);
          values = values + " Param5=16 - ";
          statement.setInt(6, ratePlanGroup);
          values = values + " Param6=" + ratePlanGroup + " - ";
          if ((type != null) && (type.equals("Postpaid"))) {
            statement.setInt(7, 1);
            values = values + " Param7=1 - ";
          } else if ((type != null) && (type.equals("Prepaid"))) {
            statement.setInt(7, 15);
            values = values + " Param7=15 - ";
          }
          statement.setInt(8, 3);
          values = values + " Param8=3 - ";

          if ((type != null) && (type.equals("Postpaid"))) {
            int group = getGroup(1);
            statement.setInt(9, group);
          } else if ((type != null) && (type.equals("Prepaid"))) {
            int group = getGroup(15);
            statement.setInt(9, group);
          }
          statement.setString(10, DateParser.getStringFromDate(new Date()));
          values = values + " Param10=" + DateParser.getStringFromDate(new Date());
          logger.info("Query : " + querySql);
          logger.info("Query values : " + values);
          statement.addBatch();
        }
      }

      statement.executeBatch();

      connection.commit();

      closeConnection(connection, statement);
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
      LOGGERDAO.log(Level.SEVERE, e.getMessage());
      closeConnection(connection, statement);
    }
  }

  public ArrayList TransferAdj(String day)
  {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    QueryModel query = getQuery(BackEndConstants.TRANSFER);
    System.out.println(query);
    String querySql = query.getSql();
    System.out.println(querySql);

    String values = "Query Values: ";

    ArrayList aggList = new ArrayList();
    try {
      connection = getConnection();
      statement = connection.prepareStatement(querySql);
      statement.setString(1, day);
      values = values + " Param1=" + day + " - ";
      logger.info("Query : " + querySql);
      logger.info("Query values : " + values);

      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        AdjManualModel aggModel = new AdjManualModel();

        String adjName = resultSet.getString("TRX_TYPE_NAME");
        int adjKey = resultSet.getInt("TRX_TYPE_KEY");
        long subs = resultSet.getLong("SUBS");
        int value = resultSet.getInt("VALUE");
        int dateKey = resultSet.getInt("date_key");

        aggModel.setDateKey(dateKey);
        aggModel.setAdjName(adjName);
        aggModel.setAdjKey(adjKey);
        aggModel.setValue(value);
        aggModel.setSubs(subs);

        aggList.add(aggModel);
      }

      closeConnection(connection, statement);
      return aggList;
      ch (Exception e) {
        System.out.println(e.getMessage());
        LOGGERDAO.log(Level.SEVERE, e.getMessage());
        closeConnection(connection, statement);
      }return aggList;
    }

    public ArrayList getAllRatePlan()
    {
      Connection connection = null;
      PreparedStatement statement = null;
      ResultSet resultSet = null;
      QueryModel query = getQuery(BackEndConstants.RATE_PLAN_ALL);
      System.out.println(query);
      String querySql = query.getSql();
      System.out.println(querySql);
      logger.info("Query : " + querySql);

      ArrayList aggList = new ArrayList();
      try {
        connection = getConnection();
        statement = connection.prepareStatement(querySql);
        resultSet = statement.executeQuery();
        while (resultSet.next()) {
          RATEPLANALL aggModel = new RATEPLANALL();

          String ratePlan = resultSet.getString("rate_plan");
          int ratePlanKey = resultSet.getInt("rate_plan_key");
          int groupKey = resultSet.getInt("RATE_PLAN_GROUP_KEY");
          String type = resultSet.getString("RATE_PLAN_TYPE");

          aggModel.setRatePlanGroup(groupKey);
          aggModel.setRatePlanKey(ratePlanKey);
          aggModel.setRatePlanName(ratePlan);
          aggModel.setType(type);

          aggList.add(aggModel);
        }

        closeConnection(connection, statement);
        return aggList;
      } catch (Exception e) {
        System.out.println(e.getMessage());
        LOGGERDAO.log(Level.SEVERE, e.getMessage());
        closeConnection(connection, statement);
      }return aggList;
    }

    public void insertTransferData(ArrayList adj)
    {
      Connection connection = null;
      PreparedStatement statement = null;
      ResultSet resultSet = null;
      QueryModel query = getQuery(BackEndConstants.INSERTADJDATA);
      System.out.println(query);
      String querySql = query.getSql();
      System.out.println(querySql);

      String values = "Query Values: ";
      try
      {
        Iterator it = adj.iterator();
        connection = getConnection();
        statement = connection.prepareStatement(querySql);
        while (it.hasNext()) {
          AdjManualModel model = (AdjManualModel)it.next();
          if (model.getAdjust() != 0L) {
            long subs = model.getAdjust();
            System.out.println(subs);
            int trxKey = model.getAdjKey();
            System.out.println(trxKey);
            int ratePlanGroup = model.getRateplanall().getRatePlanGroup();
            System.out.println(ratePlanGroup);
            int ratePlanKey = model.getRateplanall().getRatePlanKey();
            System.out.println(ratePlanKey);
            int dateKey = model.getDateKey();
            System.out.println(dateKey);
            String type = model.getRateplanall().getType();
            statement.setLong(1, subs);
            values = values + " Param1=" + subs + " - ";
            statement.setInt(2, dateKey);
            values = values + " Param2=" + dateKey + " - ";
            if ((type != null) && (type.equals("Postpaid"))) {
              statement.setInt(3, 22);
              values = values + " Param3=22 - ";
            } else if ((type != null) && (type.equals("Prepaid"))) {
              statement.setInt(3, 22);
              values = values + " Param3=22 - ";
            }
            statement.setInt(4, ratePlanKey);
            values = values + " Param4=" + ratePlanKey + " - ";
            statement.setInt(5, trxKey);
            values = values + " Param5=" + trxKey + " - ";
            statement.setInt(6, ratePlanGroup);
            values = values + " Param6=" + ratePlanGroup + " - ";
            if ((type != null) && (type.equals("Postpaid"))) {
              statement.setInt(7, 1);
              values = values + " Param7=1 - ";
            } else if ((type != null) && (type.equals("Prepaid"))) {
              statement.setInt(7, 15);
              values = values + " Param7=15 - ";
            }
            statement.setInt(8, 3);
            values = values + " Param8=3 - ";

            if ((type != null) && (type.equals("Postpaid"))) {
              int group = getGroup(1);
              values = values + " Param9=" + group + " - ";
              statement.setInt(9, group);
            } else if ((type != null) && (type.equals("Prepaid"))) {
              int group = getGroup(15);
              values = values + " Param9=" + group + " - ";
              statement.setInt(9, group);
            }

            statement.setString(10, DateParser.getStringFromDate(new Date()));
            values = values + " Param10=" + DateParser.getStringFromDate(new Date());
            logger.info("Query : " + querySql);
            logger.info("Query values : " + values);
            statement.addBatch();
          }
        }

        statement.executeBatch();

        connection.commit();

        closeConnection(connection, statement);
      }
      catch (Exception e) {
        System.out.println(e.getMessage());
        LOGGERDAO.log(Level.SEVERE, e.getMessage());
        closeConnection(connection, statement);
      }
    }
  }