package com.vodafone.dailyreport.backend.model;

public class AppUser
{
  private int userKey;
  private String name;
  private String email;
  private String phone;
  private String password;
  private boolean lockFlag;
  private String passwordExpiration;
  private String admin;

  public String getEmail()
  {
/*  22 */     return this.email;
  }

  public void setEmail(String email)
  {
/*  28 */     this.email = email;
  }

  public boolean isLockFlag()
  {
/*  34 */     return this.lockFlag;
  }

  public void setLockFlag(boolean lockFlag)
  {
/*  40 */     this.lockFlag = lockFlag;
  }

  public String getName()
  {
/*  46 */     return this.name;
  }

  public void setName(String name)
  {
/*  52 */     this.name = name;
  }

  public String getPassword()
  {
/*  58 */     return this.password;
  }

  public void setPassword(String password)
  {
/*  64 */     this.password = password;
  }

  public String getPasswordExpiration()
  {
/*  70 */     return this.passwordExpiration;
  }

  public void setPasswordExpiration(String passwordExpiration)
  {
/*  76 */     this.passwordExpiration = passwordExpiration;
  }

  public String getPhone()
  {
/*  82 */     return this.phone;
  }

  public void setPhone(String phone)
  {
/*  88 */     this.phone = phone;
  }

  public int getUserKey()
  {
/*  94 */     return this.userKey;
  }

  public void setUserKey(int userKey)
  {
/* 100 */     this.userKey = userKey;
  }
  public String getAdmin() {
/* 103 */     return this.admin;
  }
  public void setAdmin(String admin) {
/* 106 */     this.admin = admin;
  }
}