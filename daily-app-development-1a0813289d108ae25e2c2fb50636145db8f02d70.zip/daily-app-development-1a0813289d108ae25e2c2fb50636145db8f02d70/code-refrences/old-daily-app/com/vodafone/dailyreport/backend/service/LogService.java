/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.LogDao;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class LogService
/*    */ {
/*  9 */   private static LogDao ratePlanDao = new LogDao();
/*    */ 
/*    */   public static LogDao getDao()
/*    */   {
/* 15 */     System.out.println("service ok");
/* 16 */     return ratePlanDao;
/*    */   }
/*    */ }