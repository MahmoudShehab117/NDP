/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.PriceGroupDao;
/*    */ 
/*    */ public class PriceGroupService
/*    */ {
/*  8 */   private static PriceGroupDao pgDao = new PriceGroupDao();
/*    */ 
/*    */   public static PriceGroupDao getDao()
/*    */   {
/* 12 */     return pgDao;
/*    */   }
/*    */ }