package com.vodafone.dailyreport.backend.model;

public class ManualRecordModel
{
  private String ratePlan;
  private int ratePlanKey;
  private int ratePlanGroupKey;
  private long open;
  private long close;
  private long variance;
  private long adjSubs;
  private TrxModel trxModel;
  private int dateKey;
  private String adjustType;
  private String type;

  public int getDateKey()
  {
/*  24 */     return this.dateKey;
  }

  public void setDateKey(int dateKey)
  {
/*  30 */     this.dateKey = dateKey;
  }

  public long getAdjSubs()
  {
/*  36 */     return this.adjSubs;
  }

  public void setAdjSubs(long adjSubs)
  {
/*  42 */     this.adjSubs = adjSubs;
  }

  public long getClose()
  {
/*  48 */     return this.close + this.adjSubs;
  }

  public void setClose(long close)
  {
/*  54 */     this.close = close;
  }

  public long getOpen()
  {
/*  60 */     return this.open;
  }

  public void setOpen(long open)
  {
/*  66 */     this.open = open;
  }

  public String getRatePlan()
  {
/*  72 */     return this.ratePlan;
  }

  public void setRatePlan(String ratePlan)
  {
/*  78 */     this.ratePlan = ratePlan;
  }

  public int getRatePlanGroupKey()
  {
/*  84 */     return this.ratePlanGroupKey;
  }

  public void setRatePlanGroupKey(int ratePlanGroupKey)
  {
/*  90 */     this.ratePlanGroupKey = ratePlanGroupKey;
  }

  public int getRatePlanKey()
  {
/*  96 */     return this.ratePlanKey;
  }

  public void setRatePlanKey(int ratePlanKey)
  {
/* 102 */     this.ratePlanKey = ratePlanKey;
  }

  public TrxModel getTrxModel()
  {
/* 108 */     return this.trxModel;
  }

  public void setTrxModel(TrxModel trxModel)
  {
/* 114 */     this.trxModel = trxModel;
  }

  public long getVariance()
  {
/* 120 */     return this.close + this.adjSubs - this.open;
  }

  public void setVariance(long variance)
  {
/* 126 */     this.variance = variance;
  }

  public String getAdjustType()
  {
/* 132 */     return this.adjustType;
  }

  public void setAdjustType(String adjustType)
  {
/* 138 */     this.adjustType = adjustType;
  }

  public void setType(String type)
  {
/* 144 */     this.type = type;
  }

  public String getType()
  {
/* 150 */     return this.type;
  }
}