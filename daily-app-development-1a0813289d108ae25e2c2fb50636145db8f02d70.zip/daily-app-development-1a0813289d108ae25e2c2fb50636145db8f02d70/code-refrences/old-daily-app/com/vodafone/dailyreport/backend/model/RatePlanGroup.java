package com.vodafone.dailyreport.backend.model;

import java.util.ArrayList;

public class RatePlanGroup
{
  private int rpGroupKey;
  private String rpGroupName;
  private String rpGroupDesc;
/*  24 */   private boolean rpGroupShow = true;
  private String oldrpGroupName;
  private String oldrpGroupDesc;
/*  30 */   private boolean oldrpGroupShow = true;
  ArrayList ratePlans;

  public String getRpGroupDesc()
  {
/*  37 */     return this.rpGroupDesc;
  }

  public void setRpGroupDesc(String rpGroupDesc)
  {
/*  43 */     this.rpGroupDesc = rpGroupDesc;
  }

  public int getRpGroupKey()
  {
/*  49 */     return this.rpGroupKey;
  }

  public void setRpGroupKey(int rpGroupKey)
  {
/*  55 */     this.rpGroupKey = rpGroupKey;
  }

  public String getRpGroupName()
  {
/*  61 */     return this.rpGroupName;
  }

  public void setRpGroupName(String rpGroupName)
  {
/*  67 */     this.rpGroupName = rpGroupName;
  }

  public boolean isRpGroupShow()
  {
/*  73 */     return this.rpGroupShow;
  }

  public void setRpGroupShow(boolean rpGroupShow)
  {
/*  79 */     this.rpGroupShow = rpGroupShow;
  }
  public ArrayList getRatePlans() {
/*  82 */     return this.ratePlans;
  }
  public void setRatePlans(ArrayList ratePlans) {
/*  85 */     this.ratePlans = ratePlans;
  }
  public String getOldrpGroupDesc() {
/*  88 */     return this.oldrpGroupDesc;
  }
  public void setOldrpGroupDesc(String oldrpGroupDesc) {
/*  91 */     this.oldrpGroupDesc = oldrpGroupDesc;
  }
  public String getOldrpGroupName() {
/*  94 */     return this.oldrpGroupName;
  }
  public void setOldrpGroupName(String oldrpGroupName) {
/*  97 */     this.oldrpGroupName = oldrpGroupName;
  }
  public boolean isOldrpGroupShow() {
/* 100 */     return this.oldrpGroupShow;
  }
  public void setOldrpGroupShow(boolean oldrpGroupShow) {
/* 103 */     this.oldrpGroupShow = oldrpGroupShow;
  }
}