/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.RatePlanDao;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class RatePlanService
/*    */ {
/*  7 */   private static RatePlanDao ratePlanDao = new RatePlanDao();
/*    */ 
/*    */   public static RatePlanDao getDao() {
/* 10 */     System.out.println("service ok");
/* 11 */     return ratePlanDao;
/*    */   }
/*    */ }