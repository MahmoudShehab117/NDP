/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.ManualAdjDao;
/*    */ 
/*    */ public class ManualAdjService
/*    */ {
/*  8 */   private static ManualAdjDao manualDao = new ManualAdjDao();
/*    */ 
/*    */   public static ManualAdjDao getDao()
/*    */   {
/* 14 */     return manualDao;
/*    */   }
/*    */ }