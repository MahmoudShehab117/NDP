/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class PriceGroupGroup
/*    */ {
/*    */   private int groupKey;
/*    */   private String groupName;
/*  9 */   private boolean show = true;
/*    */   private String desc;
/*    */   private ArrayList priceGroups;
/*    */   private String oldGroupName;
/*    */   private boolean oldShow;
/*    */   private String oldDesc;
/*    */ 
/*    */   public String getDesc()
/*    */   {
/* 19 */     return this.desc;
/*    */   }
/*    */   public void setDesc(String desc) {
/* 22 */     this.desc = desc;
/*    */   }
/*    */   public String getOldDesc() {
/* 25 */     return this.oldDesc;
/*    */   }
/*    */   public void setOldDesc(String oldDesc) {
/* 28 */     this.oldDesc = oldDesc;
/*    */   }
/*    */   public String getOldGroupName() {
/* 31 */     return this.oldGroupName;
/*    */   }
/*    */   public void setOldGroupName(String oldGroupName) {
/* 34 */     this.oldGroupName = oldGroupName;
/*    */   }
/*    */   public boolean isOldShow() {
/* 37 */     return this.oldShow;
/*    */   }
/*    */   public void setOldShow(boolean oldShow) {
/* 40 */     this.oldShow = oldShow;
/*    */   }
/*    */   public int getGroupKey() {
/* 43 */     return this.groupKey;
/*    */   }
/*    */   public void setGroupKey(int groupKey) {
/* 46 */     this.groupKey = groupKey;
/*    */   }
/*    */   public String getGroupName() {
/* 49 */     return this.groupName;
/*    */   }
/*    */   public void setGroupName(String groupName) {
/* 52 */     this.groupName = groupName;
/*    */   }
/*    */   public ArrayList getPriceGroups() {
/* 55 */     return this.priceGroups;
/*    */   }
/*    */   public void setPriceGroups(ArrayList priceGroups) {
/* 58 */     this.priceGroups = priceGroups;
/*    */   }
/*    */   public boolean isShow() {
/* 61 */     return this.show;
/*    */   }
/*    */   public void setShow(boolean show) {
/* 64 */     this.show = show;
/*    */   }
/*    */ }