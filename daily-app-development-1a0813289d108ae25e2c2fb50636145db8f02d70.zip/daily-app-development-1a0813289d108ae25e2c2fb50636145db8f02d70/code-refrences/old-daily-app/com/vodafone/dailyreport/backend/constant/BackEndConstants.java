/*    */ package com.vodafone.dailyreport.backend.constant;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class BackEndConstants
/*    */ {
/*    */   public static final String INITAL_CONTEXT_FACTORY = "weblogic.jndi.WLInitialContextFactory";
/*  9 */   public static String DATA_SOURCE_NAME = "jdbc/RA";
/*    */ 
/* 13 */   public static int SERVICE_CLASS = 1;
/* 14 */   public static int TARIFF_MODEL = 2;
/* 15 */   public static int RATE_PLAN = 3;
/* 16 */   public static int RATE_PLAN_GROUP = 4;
/* 17 */   public static int UPDATE_SC = 5;
/* 18 */   public static int UPDATE_TM = 6;
/* 19 */   public static int UPDATE_GROUP = 7;
/* 20 */   public static int CREATE_GROUP = 8;
/* 21 */   public static int CHECK_GROUP = 9;
/* 22 */   public static int UPDATE_GROUPS = 10;
/* 23 */   public static int LOG = 11;
/*    */ 
/* 25 */   public static int PRICEGROUP = 12;
/* 26 */   public static int PRICEGROUP_GROUP = 13;
/* 27 */   public static int UPDATE_PRICEGROUP_GROUP = 14;
/* 28 */   public static int CREATE_PRICEGROUP_GROUP = 15;
/* 29 */   public static int CHECK_PRICEGROUP_GROUP = 16;
/* 30 */   public static int UPDATE_PRICEGROUP = 17;
/*    */ 
/* 32 */   public static int VE_ORIGINAL = 18;
/* 33 */   public static int VE_DETAIL = 19;
/* 34 */   public static int VE_AGG_UPDATE = 20;
/* 35 */   public static int VE_DE_UPDATE = 21;
/* 36 */   public static int VE_DE_CONTRACT_UPDATE = 22;
/*    */ 
/* 39 */   public static String POST = "POST_FLAG";
/* 40 */   public static String PRE = "PRE_FLAG";
/* 41 */   public static String HYBIRD = "HYBRID";
/* 42 */   public static String ENT = "ENTERPRISE_FLAG";
/* 43 */   public static String CONSUMER = "CONSUMER_FLAG";
/* 44 */   public static String SOURCE = "ACTIVATION_SOURCE_FLAG";
/* 45 */   public static String BUNDLE = "BUNDLE_TYPE";
/*    */ 
/* 50 */   public static int LOG_GROUP_SHOW = 14;
/* 51 */   public static int LOG_GROUP_NAME = 12;
/* 52 */   public static int LOG_GROUP_DESC = 13;
/* 53 */   public static int LOG_RATE_PLAN_GROUP = 11;
/* 54 */   public static int LOG_TARIFF_ACTIVATION = 10;
/* 55 */   public static int LOG_TARIFF_DEAC = 101;
/* 56 */   public static int LOG_TARIFF_POST = 9;
/* 57 */   public static int LOG_TARIFF_PRE = 8;
/* 58 */   public static int LOG_TARIFF_ENT = 7;
/* 59 */   public static int LOG_TARIFF_CONSUMER = 6;
/* 60 */   public static int LOG_SC_ACTIVATION = 5;
/* 61 */   public static int LOG_SC_DEAC = 51;
/* 62 */   public static int LOG_SC_POST = 4;
/* 63 */   public static int LOG_SC_PRE = 3;
/* 64 */   public static int LOG_SC_ENT = 2;
/* 65 */   public static int LOG_SC_CONSUMER = 1;
/*    */ 
/* 70 */   public static int LOG_PRICEGROUPING_SHOW = 18;
/* 71 */   public static int LOG_PRICEGROUPING_NAME = 15;
/* 72 */   public static int LOG_RICEGROUPING_DESC = 16;
/* 73 */   public static int LOG_PRICEGROUP_GROUP = 17;
/*    */ 
/* 75 */   public static int GET_COMMENTS = 21;
/* 76 */   public static int ADD_COMMENTS = 22;
/* 77 */   public static int GET_TRX = 23;
/* 78 */   public static int GET_ALL = 24;
/* 79 */   public static int UPDATE = 25;
/* 80 */   public static int UPDATE1 = 26;
/* 81 */   public static int UPDATE2 = 27;
/* 82 */   public static int UPDATE3 = 28;
/*    */ 
/* 84 */   public static int GETADJDATA = 30;
/* 85 */   public static int INSERTADJDATA = 31;
/* 86 */   public static int COMMIT_ADJUST = 32;
/*    */ 
/* 89 */   public static int TRANSFER = 33;
/*    */ 
/* 91 */   public static int RATE_PLAN_ALL = 34;
/*    */ 
/* 93 */   public static int NETADDS = 35;
/*    */ 
/* 95 */   public static int NETADDS_DATA = 36;
/*    */   public static Logger ERROR_LOGGER;
/*    */   public static Logger DEBUG_LOGGER;
/*    */ }