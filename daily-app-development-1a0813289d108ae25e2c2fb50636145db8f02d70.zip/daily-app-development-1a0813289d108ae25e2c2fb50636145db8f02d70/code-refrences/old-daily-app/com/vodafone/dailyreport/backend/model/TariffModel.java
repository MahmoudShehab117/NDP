package com.vodafone.dailyreport.backend.model;

public class TariffModel
{
  private String tmName;
  private int tmCode;
  private boolean tmEnt;
  private boolean tmConsumer;
  private boolean tmPre;
  private boolean tmPost;
  private boolean tmHybird;
  private boolean activationSource;
  private String bundleType;
  private boolean deacSource;
  private boolean oldDeacSource;
  private boolean oldtmEnt;
  private boolean oldtmConsumer;
  private boolean oldtmPre;
  private boolean oldtmPost;
  private boolean oldactivationSource;
  boolean update;
  private String typeFlag;
  private String contractFlag;

  public String getContractFlag(boolean ifNull)
  {
/*  68 */     return this.contractFlag;
  }

  public String getTypeFlag(boolean ifNull)
  {
/*  73 */     return this.typeFlag;
  }

  public String getContractFlag() {
/*  77 */     return this.contractFlag;
  }

  public void setContractFlag(String contractFlag)
  {
/*  82 */     this.contractFlag = contractFlag;
  }

  public void setTypeFlag(String typeFlag) {
/*  86 */     this.typeFlag = typeFlag;
  }

  public String getTypeFlag()
  {
/*  91 */     return this.typeFlag;
  }

  public boolean isUpdate()
  {
/*  97 */     return this.update;
  }

  public void setUpdate(boolean update) {
/* 101 */     this.update = update;
  }

  public boolean isActivationSource()
  {
/* 108 */     return this.activationSource;
  }

  public void setActivationSource(boolean activationSource)
  {
/* 116 */     this.activationSource = activationSource;
  }

  public boolean isTmEnt()
  {
/* 124 */     return this.contractFlag.equals("2");
  }

  public void setTmEnt(boolean tmEnt)
  {
/* 135 */     this.tmEnt = tmEnt;
  }

  public int getTmCode()
  {
/* 142 */     return this.tmCode;
  }

  public void setTmCode(int tmCode)
  {
/* 150 */     this.tmCode = tmCode;
  }

  public boolean isTmConsumer()
  {
/* 158 */     return this.contractFlag.equals("1");
  }

  public void setTmConsumer(boolean tmConsumer)
  {
/* 170 */     this.tmConsumer = tmConsumer;
  }

  public String getTmName()
  {
/* 177 */     return this.tmName;
  }

  public void setTmName(String tmName)
  {
/* 185 */     this.tmName = tmName;
  }

  public boolean isTmPost()
  {
/* 193 */     return this.typeFlag.equals("2");
  }

  public void setTmPost(boolean tmPost)
  {
/* 205 */     this.tmPost = tmPost;
  }

  public boolean isTmPre()
  {
/* 213 */     return this.typeFlag.equals("1");
  }

  public void setTmPre(boolean tmPre)
  {
/* 225 */     this.tmPre = tmPre;
  }

  public boolean isOldactivationSource()
  {
/* 230 */     return this.oldactivationSource;
  }

  public void setOldactivationSource(boolean oldactivationSource)
  {
/* 235 */     this.oldactivationSource = oldactivationSource;
  }

  public boolean isOldtmConsumer()
  {
/* 240 */     return this.oldtmConsumer;
  }

  public void setOldtmConsumer(boolean oldtmConsumer)
  {
/* 245 */     this.oldtmConsumer = oldtmConsumer;
  }

  public boolean isOldtmEnt()
  {
/* 250 */     return this.oldtmEnt;
  }

  public void setOldtmEnt(boolean oldtmEnt)
  {
/* 255 */     this.oldtmEnt = oldtmEnt;
  }

  public boolean isOldtmPost()
  {
/* 260 */     return this.oldtmPost;
  }

  public void setOldtmPost(boolean oldtmPost)
  {
/* 265 */     this.oldtmPost = oldtmPost;
  }

  public boolean isOldtmPre()
  {
/* 270 */     return this.oldtmPre;
  }

  public void setOldtmPre(boolean oldtmPre)
  {
/* 275 */     this.oldtmPre = oldtmPre;
  }

  public boolean isDeacSource()
  {
/* 283 */     return this.deacSource;
  }

  public void setDeacSource(boolean deacSource)
  {
/* 291 */     this.deacSource = deacSource;
  }

  public boolean isOldDeacSource()
  {
/* 299 */     return this.oldDeacSource;
  }

  public void setOldDeacSource(boolean oldDeacSource)
  {
/* 307 */     this.oldDeacSource = oldDeacSource;
  }

  public void setTmHybird(boolean tmHybird)
  {
/* 312 */     this.tmHybird = tmHybird;
  }

  public boolean isTmHybird()
  {
/* 317 */     return this.tmHybird;
  }

  public void setBundleType(String bundleType)
  {
/* 322 */     this.bundleType = bundleType;
  }

  public String getBundleType()
  {
/* 327 */     return this.bundleType.toLowerCase();
  }
}