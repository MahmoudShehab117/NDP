package com.vodafone.dailyreport.backend.model;

public class RatePlan
{
  private int rpKey;
  private String rpCode;
  private String rpName;
  private String rpType;
  private String rpContractType;
  private RatePlanGroup ratePlanGroup;
  private boolean hybird;
  private String data_voice_adsl_flag;
  private String bundle_flag;
  private String for_ivr_cost;
  private String for_ivr_rev;
  private String combined;
  private String post_pre_flag;
  private boolean activationSource;
  private boolean deacSource;
  private boolean showFlag;
  private boolean update;
  private boolean original;

  public boolean isUpdate()
  {
/*  45 */     return this.update;
  }

  public void setUpdate(boolean update)
  {
/*  50 */     this.update = update;
  }

  public boolean isActivationSource()
  {
/*  57 */     return this.activationSource;
  }

  public void setActivationSource(boolean activationSource)
  {
/*  65 */     this.activationSource = activationSource;
  }

  public RatePlanGroup getRatePlanGroup()
  {
/*  72 */     return this.ratePlanGroup;
  }

  public void setRatePlanGroup(RatePlanGroup ratePlanGroup)
  {
/*  80 */     this.ratePlanGroup = ratePlanGroup;
  }

  public String getRpCode()
  {
/*  87 */     return this.rpCode;
  }

  public void setRpCode(String rpCode)
  {
/*  95 */     this.rpCode = rpCode;
  }

  public String getRpContractType()
  {
/* 102 */     return this.rpContractType;
  }

  public void setRpContractType(String rpContractType)
  {
/* 110 */     this.rpContractType = rpContractType;
  }

  public int getRpKey()
  {
/* 117 */     return this.rpKey;
  }

  public void setRpKey(int rpKey)
  {
/* 125 */     this.rpKey = rpKey;
  }

  public String getRpName()
  {
/* 132 */     return this.rpName;
  }

  public void setRpName(String rpName)
  {
/* 140 */     this.rpName = rpName;
  }

  public String getRpType()
  {
/* 147 */     return this.rpType;
  }

  public void setRpType(String rpType)
  {
/* 155 */     this.rpType = rpType;
  }

  public boolean isShowFlag() {
/* 159 */     return this.showFlag;
  }

  public void setShowFlag(boolean showFlag) {
/* 163 */     this.showFlag = showFlag;
  }

  public boolean isDeacSource()
  {
/* 171 */     return this.deacSource;
  }

  public void setDeacSource(boolean deacSource)
  {
/* 179 */     this.deacSource = deacSource;
  }

  public boolean isOriginal()
  {
/* 187 */     return this.original;
  }

  public void setOriginal(boolean original)
  {
/* 195 */     this.original = original;
  }

  public void setHybird(boolean hybird)
  {
/* 200 */     this.hybird = hybird;
  }

  public boolean isHybird()
  {
/* 205 */     return this.hybird;
  }

  public void setData_voice_adsl_flag(String data_voice_adsl_flag)
  {
/* 210 */     this.data_voice_adsl_flag = data_voice_adsl_flag;
  }

  public String getData_voice_adsl_flag()
  {
/* 215 */     return this.data_voice_adsl_flag;
  }

  public void setBundle_flag(String bundle_flag)
  {
/* 220 */     this.bundle_flag = bundle_flag;
  }

  public String getBundle_flag()
  {
/* 225 */     return this.bundle_flag;
  }

  public void setFor_ivr_cost(String for_ivr_cost)
  {
/* 230 */     this.for_ivr_cost = for_ivr_cost;
  }

  public String getFor_ivr_cost()
  {
/* 235 */     return this.for_ivr_cost;
  }

  public void setFor_ivr_rev(String for_ivr_rev)
  {
/* 240 */     this.for_ivr_rev = for_ivr_rev;
  }

  public String getFor_ivr_rev()
  {
/* 245 */     return this.for_ivr_rev;
  }

  public void setCombined(String combined)
  {
/* 250 */     this.combined = combined;
  }

  public String getCombined()
  {
/* 255 */     return this.combined;
  }

  public void setPost_pre_flag(String post_pre_flag)
  {
/* 260 */     this.post_pre_flag = post_pre_flag;
  }

  public String getPost_pre_flag()
  {
/* 265 */     return this.post_pre_flag;
  }
}