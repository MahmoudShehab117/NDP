package com.vodafone.dailyreport.backend.model;

import java.util.ArrayList;

public class DailyAggModel
{
  private long subs;
  private int dateKey;
  private int priceGroupKey;
  private int ratePlanKey;
  private int trxKey;
  private int ratePlanGroupKey;
  private int dwhStatusKey;
  private int userKey;
  private String segment;
  private String activationReason;
  private String priceGroup;
  private String ratePlan;
  private String trxName;
  private String ratePlanGroup;
  private String dwhStatus;
  private ArrayList veList;
  private String date;
  private String cCode;

  public String getCCode()
  {
/*  29 */     return this.cCode;
  }
  public void setCCode(String code) {
/*  32 */     this.cCode = code;
  }
  public ArrayList getVeList() {
/*  35 */     return this.veList;
  }
  public void setVeList(ArrayList veList) {
/*  38 */     this.veList = veList;
  }
  public String getActivationReason() {
/*  41 */     return this.activationReason;
  }
  public void setActivationReason(String activationReason) {
/*  44 */     this.activationReason = activationReason;
  }

  public int getDateKey() {
/*  48 */     return this.dateKey;
  }
  public void setDateKey(int dateKey) {
/*  51 */     this.dateKey = dateKey;
  }
  public String getDwhStatus() {
/*  54 */     return this.dwhStatus;
  }
  public void setDwhStatus(String dwhStatus) {
/*  57 */     this.dwhStatus = dwhStatus;
  }
  public int getDwhStatusKey() {
/*  60 */     return this.dwhStatusKey;
  }
  public void setDwhStatusKey(int dwhStatusKey) {
/*  63 */     this.dwhStatusKey = dwhStatusKey;
  }
  public String getPriceGroup() {
/*  66 */     return this.priceGroup;
  }
  public void setPriceGroup(String priceGroup) {
/*  69 */     this.priceGroup = priceGroup;
  }
  public int getPriceGroupKey() {
/*  72 */     return this.priceGroupKey;
  }
  public void setPriceGroupKey(int priceGroupKey) {
/*  75 */     this.priceGroupKey = priceGroupKey;
  }
  public String getRatePlan() {
/*  78 */     return this.ratePlan;
  }
  public void setRatePlan(String ratePlan) {
/*  81 */     this.ratePlan = ratePlan;
  }
  public String getRatePlanGroup() {
/*  84 */     return this.ratePlanGroup;
  }
  public void setRatePlanGroup(String ratePlanGroup) {
/*  87 */     this.ratePlanGroup = ratePlanGroup;
  }
  public int getRatePlanGroupKey() {
/*  90 */     return this.ratePlanGroupKey;
  }
  public void setRatePlanGroupKey(int ratePlanGroupKey) {
/*  93 */     this.ratePlanGroupKey = ratePlanGroupKey;
  }
  public int getRatePlanKey() {
/*  96 */     return this.ratePlanKey;
  }
  public void setRatePlanKey(int ratePlanKey) {
/*  99 */     this.ratePlanKey = ratePlanKey;
  }
  public String getSegment() {
/* 102 */     return this.segment;
  }
  public void setSegment(String segment) {
/* 105 */     this.segment = segment;
  }
  public long getSubs() {
/* 108 */     return this.subs;
  }
  public void setSubs(long subs) {
/* 111 */     this.subs = subs;
  }
  public int getTrxKey() {
/* 114 */     return this.trxKey;
  }
  public void setTrxKey(int trxKey) {
/* 117 */     this.trxKey = trxKey;
  }
  public String getTrxName() {
/* 120 */     return this.trxName;
  }
  public void setTrxName(String trxName) {
/* 123 */     this.trxName = trxName;
  }
  public int getUserKey() {
/* 126 */     return this.userKey;
  }
  public void setUserKey(int userKey) {
/* 129 */     this.userKey = userKey;
  }
  public String getDate() {
/* 132 */     return this.date;
  }
  public void setDate(String date) {
/* 135 */     this.date = date;
  }
}