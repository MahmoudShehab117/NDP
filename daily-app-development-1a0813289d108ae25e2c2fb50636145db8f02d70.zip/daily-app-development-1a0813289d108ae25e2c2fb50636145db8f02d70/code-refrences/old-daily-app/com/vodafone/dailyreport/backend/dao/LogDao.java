package com.vodafone.dailyreport.backend.dao;

import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.log.LogHandler;
import com.vodafone.dailyreport.backend.model.LogFact;
import com.vodafone.dailyreport.backend.model.QueryModel;
import com.vodafone.dailyreport.backend.util.DateParser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import org.apache.log4j.Logger;

public class LogDao extends BaseDao
{
/*  29 */   public static Logger logger = Logger.getLogger(LogDao.class.getName());

  public int log(ArrayList logFacts) {
/*  32 */     Connection connection = null;
/*  33 */     PreparedStatement statement = null;
/*  34 */     QueryModel query = getQuery(BackEndConstants.LOG);
/*  35 */     String querySql = query.getSql();
/*  36 */     Iterator it = logFacts.iterator();
    try {
/*  38 */       connection = getConnection();
/*  39 */       statement = connection.prepareStatement(querySql);
/*  40 */       while (it.hasNext()) {
/*  41 */         LogFact logFact = (LogFact)it.next();
/*  42 */         statement.setInt(1, logFact.getLogAttribute());
/*  43 */         statement.setString(2, logFact.getOldValue());
/*  44 */         statement.setString(3, logFact.getNewValue());
/*  45 */         statement.setString(4, DateParser.getDetailsFromDate(logFact.getTimeStamp()));

/*  47 */         statement.setInt(5, 0);
/*  48 */         statement.setString(6, logFact.getSource());
/*  49 */         logger.info("Query: " + querySql);
/*  50 */         logger.info("Values: " + 
/*  51 */           logFact.getLogAttribute() + " - " + 
/*  52 */           logFact.getOldValue() + " - " + 
/*  53 */           logFact.getNewValue() + " - " + 
/*  54 */           DateParser.getDetailsFromDate(logFact.getTimeStamp()) + " - " + 
/*  55 */           "0" + " - " + 
/*  56 */           logFact.getSource());

/*  58 */         statement.addBatch();
      }
/*  60 */       int[] result = statement.executeBatch();
/*  61 */       connection.commit();
/*  62 */       closeConnection(connection, statement);
/*  63 */       return result.length;
    } catch (Exception e) {
/*  65 */       e.printStackTrace();
/*  66 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  67 */       closeConnection(connection, statement);
/*  68 */     }return -1;
  }

  public int log(LogFact logFact)
  {
/*  76 */     Connection connection = null;
/*  77 */     PreparedStatement statement = null;
/*  78 */     QueryModel query = getQuery(BackEndConstants.LOG);
/*  79 */     String querySql = query.getSql();
    try
    {
/*  82 */       connection = getConnection();
/*  83 */       statement = connection.prepareStatement(querySql);

/*  86 */       statement.setInt(1, logFact.getLogAttribute());
/*  87 */       statement.setString(2, logFact.getOldValue());
/*  88 */       statement.setString(3, logFact.getNewValue());
/*  89 */       statement.setString(4, DateParser.getDetailsFromDate(logFact.getTimeStamp()));

/*  91 */       statement.setInt(5, 0);
/*  92 */       statement.setString(6, logFact.getSource());

/*  94 */       logger.info("Query: " + querySql);
/*  95 */       logger.info("Values: " + 
/*  96 */         logFact.getLogAttribute() + " - " + 
/*  97 */         logFact.getOldValue() + " - " + 
/*  98 */         logFact.getNewValue() + " - " + 
/*  99 */         DateParser.getDetailsFromDate(logFact.getTimeStamp()) + " - " + 
/* 100 */         "0" + " - " + 
/* 101 */         logFact.getSource());

/* 104 */       int result = statement.executeUpdate();
/* 105 */       connection.commit();
/* 106 */       closeConnection(connection, statement);

/* 108 */       return result;
    } catch (Exception e) {
/* 110 */       e.printStackTrace();
/* 111 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 112 */       closeConnection(connection, statement);
/* 113 */     }return -1;
  }
}