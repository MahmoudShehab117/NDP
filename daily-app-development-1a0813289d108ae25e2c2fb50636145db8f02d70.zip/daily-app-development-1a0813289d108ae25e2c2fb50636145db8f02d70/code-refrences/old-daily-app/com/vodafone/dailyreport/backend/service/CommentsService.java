/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.CommentsDao;
/*    */ 
/*    */ public class CommentsService
/*    */ {
/*  8 */   private static CommentsDao commentsDao = new CommentsDao();
/*    */ 
/*    */   public static CommentsDao getDao()
/*    */   {
/* 15 */     return commentsDao;
/*    */   }
/*    */ }