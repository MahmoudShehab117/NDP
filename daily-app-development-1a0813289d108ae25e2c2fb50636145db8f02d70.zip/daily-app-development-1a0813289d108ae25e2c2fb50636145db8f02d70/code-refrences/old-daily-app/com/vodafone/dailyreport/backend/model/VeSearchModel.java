/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class VeSearchModel
/*    */ {
/*    */   private int dateKey;
/*    */   private int priceGroupKey;
/*    */   private int ratePlanKey;
/*    */   private int trxKey;
/*    */   private int ratePlanGroupKey;
/*    */   private int dwhStatusKey;
/*    */   private int userKey;
/*    */   private String segment;
/*    */   private String cCode;
/*    */ 
/*    */   public String getCCode()
/*    */   {
/* 18 */     return this.cCode;
/*    */   }
/*    */   public void setCCode(String code) {
/* 21 */     this.cCode = code;
/*    */   }
/*    */   public int getDateKey() {
/* 24 */     return this.dateKey;
/*    */   }
/*    */   public void setDateKey(int dateKey) {
/* 27 */     this.dateKey = dateKey;
/*    */   }
/*    */   public int getDwhStatusKey() {
/* 30 */     return this.dwhStatusKey;
/*    */   }
/*    */   public void setDwhStatusKey(int dwhStatusKey) {
/* 33 */     this.dwhStatusKey = dwhStatusKey;
/*    */   }
/*    */   public int getPriceGroupKey() {
/* 36 */     return this.priceGroupKey;
/*    */   }
/*    */   public void setPriceGroupKey(int priceGroupKey) {
/* 39 */     this.priceGroupKey = priceGroupKey;
/*    */   }
/*    */   public int getRatePlanGroupKey() {
/* 42 */     return this.ratePlanGroupKey;
/*    */   }
/*    */   public void setRatePlanGroupKey(int ratePlanGroupKey) {
/* 45 */     this.ratePlanGroupKey = ratePlanGroupKey;
/*    */   }
/*    */   public int getRatePlanKey() {
/* 48 */     return this.ratePlanKey;
/*    */   }
/*    */   public void setRatePlanKey(int ratePlanKey) {
/* 51 */     this.ratePlanKey = ratePlanKey;
/*    */   }
/*    */   public String getSegment() {
/* 54 */     return this.segment;
/*    */   }
/*    */   public void setSegment(String segment) {
/* 57 */     this.segment = segment;
/*    */   }
/*    */   public int getTrxKey() {
/* 60 */     return this.trxKey;
/*    */   }
/*    */   public void setTrxKey(int trxKey) {
/* 63 */     this.trxKey = trxKey;
/*    */   }
/*    */   public int getUserKey() {
/* 66 */     return this.userKey;
/*    */   }
/*    */   public void setUserKey(int userKey) {
/* 69 */     this.userKey = userKey;
/*    */   }
/*    */ }