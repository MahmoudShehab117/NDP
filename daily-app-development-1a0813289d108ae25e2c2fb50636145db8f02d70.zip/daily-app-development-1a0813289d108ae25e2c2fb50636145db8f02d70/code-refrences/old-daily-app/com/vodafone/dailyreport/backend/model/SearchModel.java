/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class SearchModel
/*    */ {
/*    */   private String att;
/*    */   private boolean value;
/*    */   private boolean empty;
/*    */ 
/*    */   public String getAtt()
/*    */   {
/*  9 */     return this.att;
/*    */   }
/*    */   public void setAtt(String att) {
/* 12 */     this.att = att;
/*    */   }
/*    */   public boolean isEmpty() {
/* 15 */     return this.empty;
/*    */   }
/*    */   public void setEmpty(boolean empty) {
/* 18 */     this.empty = empty;
/*    */   }
/*    */   public boolean isValue() {
/* 21 */     return this.value;
/*    */   }
/*    */   public void setValue(boolean value) {
/* 24 */     this.value = value;
/*    */   }
/*    */ }