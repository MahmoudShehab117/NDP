/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class RATEPLANALL
/*    */ {
/*    */   private int ratePlanKey;
/*    */   private int ratePlanGroup;
/*    */   private String ratePlanName;
/*    */   private String type;
/*    */ 
/*    */   public int getRatePlanGroup()
/*    */   {
/* 12 */     return this.ratePlanGroup;
/*    */   }
/*    */ 
/*    */   public void setRatePlanGroup(int ratePlanGroup)
/*    */   {
/* 18 */     this.ratePlanGroup = ratePlanGroup;
/*    */   }
/*    */ 
/*    */   public int getRatePlanKey()
/*    */   {
/* 24 */     return this.ratePlanKey;
/*    */   }
/*    */ 
/*    */   public void setRatePlanKey(int ratePlanKey)
/*    */   {
/* 30 */     this.ratePlanKey = ratePlanKey;
/*    */   }
/*    */ 
/*    */   public String getRatePlanName()
/*    */   {
/* 36 */     return this.ratePlanName;
/*    */   }
/*    */ 
/*    */   public void setRatePlanName(String ratePlanName)
/*    */   {
/* 42 */     this.ratePlanName = ratePlanName;
/*    */   }
/*    */ 
/*    */   public String getType()
/*    */   {
/* 48 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type)
/*    */   {
/* 54 */     this.type = type;
/*    */   }
/*    */ }