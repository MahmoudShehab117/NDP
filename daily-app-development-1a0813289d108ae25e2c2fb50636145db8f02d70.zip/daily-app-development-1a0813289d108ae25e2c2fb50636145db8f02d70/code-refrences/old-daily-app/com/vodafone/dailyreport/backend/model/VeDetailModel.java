package com.vodafone.dailyreport.backend.model;

import java.util.Date;

public class VeDetailModel
{
  private int contract;
  private String mobileNnumber;
  private int dateKey;
  private int priceGroupKey;
  private int ratePlanKey;
  private int trxKey;
  private int ratePlanGroupKey;
  private int dwhStatusKey;
  private int userKey;
  private String segment;
  private String activationReason;
  private String priceGroup;
  private String ratePlan;
  private String trxName;
  private String ratePlanGroup;
  private String dwhStatus;
  private boolean applyFlag;
  private Date applyDate;
  private String date;
  private String cCode;

  public String getCCode()
  {
/*  30 */     return this.cCode;
  }
  public void setCCode(String code) {
/*  33 */     this.cCode = code;
  }
  public String getDate() {
/*  36 */     return this.date;
  }
  public void setDate(String date) {
/*  39 */     this.date = date;
  }
  public String getActivationReason() {
/*  42 */     return this.activationReason;
  }
  public void setActivationReason(String activationReason) {
/*  45 */     this.activationReason = activationReason;
  }
  public Date getApplyDate() {
/*  48 */     return this.applyDate;
  }
  public void setApplyDate(Date applyDate) {
/*  51 */     this.applyDate = applyDate;
  }
  public boolean isApplyFlag() {
/*  54 */     return this.applyFlag;
  }
  public void setApplyFlag(boolean applyFlag) {
/*  57 */     this.applyFlag = applyFlag;
  }
  public int getDateKey() {
/*  60 */     return this.dateKey;
  }
  public void setDateKey(int dateKey) {
/*  63 */     this.dateKey = dateKey;
  }
  public String getDwhStatus() {
/*  66 */     return this.dwhStatus;
  }
  public void setDwhStatus(String dwhStatus) {
/*  69 */     this.dwhStatus = dwhStatus;
  }
  public int getDwhStatusKey() {
/*  72 */     return this.dwhStatusKey;
  }
  public void setDwhStatusKey(int dwhStatusKey) {
/*  75 */     this.dwhStatusKey = dwhStatusKey;
  }
  public String getPriceGroup() {
/*  78 */     return this.priceGroup;
  }
  public void setPriceGroup(String priceGroup) {
/*  81 */     this.priceGroup = priceGroup;
  }
  public int getPriceGroupKey() {
/*  84 */     return this.priceGroupKey;
  }
  public void setPriceGroupKey(int priceGroupKey) {
/*  87 */     this.priceGroupKey = priceGroupKey;
  }
  public String getRatePlan() {
/*  90 */     return this.ratePlan;
  }
  public void setRatePlan(String ratePlan) {
/*  93 */     this.ratePlan = ratePlan;
  }
  public String getRatePlanGroup() {
/*  96 */     return this.ratePlanGroup;
  }
  public void setRatePlanGroup(String ratePlanGroup) {
/*  99 */     this.ratePlanGroup = ratePlanGroup;
  }
  public int getRatePlanGroupKey() {
/* 102 */     return this.ratePlanGroupKey;
  }
  public void setRatePlanGroupKey(int ratePlanGroupKey) {
/* 105 */     this.ratePlanGroupKey = ratePlanGroupKey;
  }
  public int getRatePlanKey() {
/* 108 */     return this.ratePlanKey;
  }
  public void setRatePlanKey(int ratePlanKey) {
/* 111 */     this.ratePlanKey = ratePlanKey;
  }
  public String getSegment() {
/* 114 */     return this.segment;
  }
  public void setSegment(String segment) {
/* 117 */     this.segment = segment;
  }

  public int getContract() {
/* 121 */     return this.contract;
  }
  public void setContract(int contract) {
/* 124 */     this.contract = contract;
  }
  public int getTrxKey() {
/* 127 */     return this.trxKey;
  }
  public void setTrxKey(int trxKey) {
/* 130 */     this.trxKey = trxKey;
  }
  public String getTrxName() {
/* 133 */     return this.trxName;
  }
  public void setTrxName(String trxName) {
/* 136 */     this.trxName = trxName;
  }
  public int getUserKey() {
/* 139 */     return this.userKey;
  }
  public void setUserKey(int userKey) {
/* 142 */     this.userKey = userKey;
  }
  public String getMobileNnumber() {
/* 145 */     return this.mobileNnumber;
  }
  public void setMobileNnumber(String mobileNnumber) {
/* 148 */     this.mobileNnumber = mobileNnumber;
  }
}