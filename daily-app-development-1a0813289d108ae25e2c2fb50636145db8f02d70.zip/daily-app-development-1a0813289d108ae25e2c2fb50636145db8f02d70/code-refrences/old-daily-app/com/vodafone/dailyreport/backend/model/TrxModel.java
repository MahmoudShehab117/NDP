/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class TrxModel
/*    */ {
/*    */   String name;
/*    */   int key;
/*    */   int value;
/*    */ 
/*    */   public int getKey()
/*    */   {
/* 11 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(int key)
/*    */   {
/* 17 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 23 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 29 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 35 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(int value)
/*    */   {
/* 41 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public TrxModel(String name, int key, int value) {
/* 45 */     this.name = name;
/* 46 */     this.key = key;
/* 47 */     this.value = value;
/*    */   }
/*    */ }