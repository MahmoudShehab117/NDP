/*    */ package com.vodafone.dailyreport.backend.service;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.dao.UserManagmentDao;
/*    */ 
/*    */ public class UserManagmentService
/*    */ {
/*  7 */   private static UserManagmentDao umDao = new UserManagmentDao();
/*    */ 
/*    */   public static UserManagmentDao getDao()
/*    */   {
/* 11 */     return umDao;
/*    */   }
/*    */ }