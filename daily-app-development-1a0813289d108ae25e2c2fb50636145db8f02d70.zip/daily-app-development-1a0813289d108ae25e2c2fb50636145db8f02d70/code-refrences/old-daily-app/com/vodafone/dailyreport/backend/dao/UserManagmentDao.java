/*    */ package com.vodafone.dailyreport.backend.dao;
/*    */ 
/*    */ import com.vodafone.dailyreport.backend.model.AppUser;
/*    */ import com.vodafone.dailyreport.backend.model.QueryModel;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class UserManagmentDao extends BaseDao
/*    */ {
/* 19 */   public static Logger logger = Logger.getLogger(UserManagmentDao.class);
/*    */ 
/*    */   public AppUser checkUser(String username)
/*    */   {
/* 23 */     Connection connection = getConnection();
/* 24 */     QueryModel queries = new QueryModel();
/* 25 */     PreparedStatement statement = null;
/* 26 */     ResultSet result = null;
/* 27 */     AppUser bean = new AppUser();
/*    */     try
/*    */     {
/* 30 */       queries = getQuery(20);
/*    */ 
/* 32 */       statement = connection.prepareStatement(queries.getSql());
/* 33 */       statement.setString(1, username);
/* 34 */       logger.info("Query : " + queries.getSql());
/* 35 */       logger.info("Query values : Param1=" + username);
/*    */ 
/* 37 */       result = statement.executeQuery();
/*    */ 
/* 41 */       while (result.next()) {
/* 42 */         bean.setUserKey(result.getInt("USER_KEY"));
/* 43 */         bean.setPassword(result.getString("PASSWORD"));
/* 44 */         bean.setName(result.getString("NAME"));
/* 45 */         bean.setAdmin(result.getString("admin"));
/*    */       }
/*    */ 
/* 49 */       connection.close();
/* 50 */       return bean;
/*    */     }
/*    */     catch (Exception e) {
/*    */       try {
/* 54 */         connection.close();
/* 55 */         e.printStackTrace();
/*    */       }
/*    */       catch (SQLException e1) {
/* 58 */         e1.printStackTrace();
/*    */       }
/*    */     }
/* 60 */     return bean;
/*    */   }
/*    */ }