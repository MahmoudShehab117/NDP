/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class LogFact
/*    */ {
/*    */   private Date timeStamp;
/*    */   private String oldValue;
/*    */   private String newValue;
/*    */   private String source;
/*    */   private AppUser user;
/*    */   private int logAttribute;
/*    */ 
/*    */   public int getLogAttribute()
/*    */   {
/* 22 */     return this.logAttribute;
/*    */   }
/*    */ 
/*    */   public void setLogAttribute(int logAttribute)
/*    */   {
/* 28 */     this.logAttribute = logAttribute;
/*    */   }
/*    */ 
/*    */   public String getNewValue()
/*    */   {
/* 34 */     return this.newValue;
/*    */   }
/*    */ 
/*    */   public void setNewValue(String newValue)
/*    */   {
/* 40 */     this.newValue = newValue;
/*    */   }
/*    */ 
/*    */   public String getOldValue()
/*    */   {
/* 46 */     return this.oldValue;
/*    */   }
/*    */ 
/*    */   public void setOldValue(String oldValue)
/*    */   {
/* 52 */     this.oldValue = oldValue;
/*    */   }
/*    */ 
/*    */   public Date getTimeStamp()
/*    */   {
/* 58 */     return this.timeStamp;
/*    */   }
/*    */ 
/*    */   public void setTimeStamp(Date timeStamp)
/*    */   {
/* 64 */     this.timeStamp = timeStamp;
/*    */   }
/*    */ 
/*    */   public AppUser getUser()
/*    */   {
/* 70 */     return this.user;
/*    */   }
/*    */ 
/*    */   public void setUser(AppUser user)
/*    */   {
/* 76 */     this.user = user;
/*    */   }
/*    */   public String getSource() {
/* 79 */     return this.source;
/*    */   }
/*    */   public void setSource(String source) {
/* 82 */     this.source = source;
/*    */   }
/*    */ }