/*      */ package com.vodafone.dailyreport.backend.dao;
/*      */ 
/*      */ import com.vodafone.dailyreport.backend.constant.BackEndConstants;
/*      */ import com.vodafone.dailyreport.backend.log.LogHandler;
/*      */ import com.vodafone.dailyreport.backend.model.LogFact;
/*      */ import com.vodafone.dailyreport.backend.model.QueryModel;
/*      */ import com.vodafone.dailyreport.backend.model.RatePlan;
/*      */ import com.vodafone.dailyreport.backend.model.RatePlanGroup;
/*      */ import com.vodafone.dailyreport.backend.model.SearchModel;
/*      */ import com.vodafone.dailyreport.backend.model.ServiceClass;
/*      */ import com.vodafone.dailyreport.backend.model.TariffModel;
/*      */ import com.vodafone.dailyreport.backend.service.LogService;
/*      */ import com.vodafone.dailyreport.frontend.beans.LoginBean;
/*      */ import com.vodafone.dailyreport.frontend.util.SessionHelper;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.logging.Level;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class RatePlanDao extends BaseDao
/*      */ {
/*   39 */   public static Logger logger = Logger.getLogger(RatePlanDao.class);
/*      */ 
/*      */   public ArrayList getServiceClass() {
/*   42 */     Connection connection = null;
/*   43 */     PreparedStatement statement = null;
/*   44 */     ArrayList results = new ArrayList();
/*   45 */     ResultSet resultSet = null;
/*      */     try
/*      */     {
/*   48 */       QueryModel query = getQuery(BackEndConstants.SERVICE_CLASS);
/*   49 */       logger.info("Query : " + query.getSql());
/*   50 */       connection = getConnection();
/*   51 */       statement = connection.prepareStatement(query.getSql());
/*   52 */       resultSet = statement.executeQuery();
/*   53 */       while (resultSet.next())
/*      */       {
/*   55 */         ServiceClass serviceClass = new ServiceClass();
/*   56 */         serviceClass.setScCode(resultSet.getInt("SERVICE_CLASS_CODE"));
/*   57 */         serviceClass.setScName(resultSet.getString("SERVICE_CLASS"));
/*   58 */         if (resultSet.getInt("CONSUMER_FLAG") == 1)
/*   59 */           serviceClass.setScConsumer(true);
/*      */         else {
/*   61 */           serviceClass.setScConsumer(false);
/*      */         }
/*      */ 
/*   64 */         if (resultSet.getInt("ENTERPRISE_FLAG") == 1)
/*   65 */           serviceClass.setScEnt(true);
/*      */         else {
/*   67 */           serviceClass.setScEnt(false);
/*      */         }
/*      */ 
/*   70 */         if (resultSet.getInt("PRE_FLAG") == 1)
/*   71 */           serviceClass.setScPre(true);
/*      */         else {
/*   73 */           serviceClass.setScPre(false);
/*      */         }
/*      */ 
/*   76 */         if (resultSet.getInt("POST_FLAG") == 1)
/*   77 */           serviceClass.setScPost(true);
/*      */         else {
/*   79 */           serviceClass.setScPost(false);
/*      */         }
/*      */ 
/*   82 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*   83 */           serviceClass.setActivationSource(true);
/*      */         else {
/*   85 */           serviceClass.setActivationSource(false);
/*      */         }
/*      */ 
/*   88 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1)
/*   89 */           serviceClass.setDeacSource(true);
/*      */         else {
/*   91 */           serviceClass.setDeacSource(false);
/*      */         }
/*      */ 
/*   94 */         serviceClass.setOldactivationSource(serviceClass
/*   95 */           .isActivationSource());
/*   96 */         serviceClass.setOldscConsumer(serviceClass.isScConsumer());
/*   97 */         serviceClass.setOldscEnt(serviceClass.isScEnt());
/*      */ 
/*   99 */         serviceClass.setOldscPost(serviceClass.isScPost());
/*  100 */         serviceClass.setOldactivationSource(serviceClass.isScPre());
/*      */ 
/*  102 */         results.add(serviceClass);
/*      */       }
/*  104 */       closeConnection(connection, statement);
/*  105 */       return results;
/*      */     } catch (Exception e) {
/*  107 */       e.printStackTrace();
/*  108 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  109 */       closeConnection(connection, statement);
/*  110 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getServiceClassByFlag(String name, String bundleType, ArrayList searchModels)
/*      */   {
/*  120 */     Connection connection = null;
/*  121 */     PreparedStatement statement = null;
/*  122 */     ArrayList results = new ArrayList();
/*  123 */     ResultSet resultSet = null;
/*  124 */     QueryModel query = getQuery(BackEndConstants.SERVICE_CLASS);
/*  125 */     String querySql = query.getSql();
/*      */ 
/*  127 */     Iterator it = searchModels.iterator();
/*  128 */     int counter = 0;
/*  129 */     while (it.hasNext()) {
/*  130 */       SearchModel searchModel = (SearchModel)it.next();
/*  131 */       String attr = searchModel.getAtt();
/*  132 */       boolean valueBoolean = searchModel.isValue();
/*  133 */       int value = -1;
/*  134 */       boolean empty = searchModel.isEmpty();
/*  135 */       if (valueBoolean)
/*  136 */         value = 1;
/*      */       else {
/*  138 */         value = 0;
/*      */       }
/*      */ 
/*  141 */       if (counter == 0) {
/*  142 */         if (!empty)
/*  143 */           querySql = querySql + " where " + attr + "=" + value;
/*      */         else {
/*  145 */           querySql = querySql + " where " + attr + " is null ";
/*      */         }
/*      */       }
/*  148 */       else if (!empty)
/*  149 */         querySql = querySql + " and  " + attr + "=" + value;
/*      */       else {
/*  151 */         querySql = querySql + " and " + attr + " is null ";
/*      */       }
/*      */ 
/*  156 */       counter++;
/*      */     }
/*      */ 
/*  159 */     if ((counter == 0) && (name != null) && (name.equals("All")))
/*  160 */       querySql = querySql + " where lower(SERVICE_CLASS) like lower('%%')";
/*  161 */     else if ((counter != 0) && (name != null) && (name.equals("All"))) {
/*  162 */       querySql = querySql + " and  lower(SERVICE_CLASS) like lower('%%')";
/*      */     }
/*      */ 
/*  165 */     if ((counter == 0) && (name != null) && (!name.equals("All")))
/*  166 */       querySql = querySql + " where  lower(SERVICE_CLASS) like lower('%" + name + 
/*  167 */         "%')";
/*  168 */     else if ((counter != 0) && (name != null) && (!name.equals("All"))) {
/*  169 */       querySql = querySql + " and  lower(SERVICE_CLASS) like lower('%" + name + 
/*  170 */         "%')";
/*      */     }
/*      */ 
/*  173 */     if (!bundleType.equals("")) {
/*  174 */       querySql = querySql + "and lower(BUNDLE_TYPE) like lower('%" + bundleType + 
/*  175 */         "%')";
/*      */     }
/*      */ 
/*  178 */     querySql = querySql + " order by SERVICE_CLASS ";
/*  179 */     logger.debug("Service Class Query : " + querySql);
/*  180 */     System.out.println(querySql);
/*  181 */     logger.info("Query : " + querySql);
/*      */     try
/*      */     {
/*  184 */       connection = getConnection();
/*  185 */       statement = connection.prepareStatement(querySql);
/*  186 */       resultSet = statement.executeQuery();
/*  187 */       while (resultSet.next())
/*      */       {
/*  189 */         ServiceClass serviceClass = new ServiceClass();
/*  190 */         serviceClass.setScCode(resultSet.getInt("SERVICE_CLASS_CODE"));
/*  191 */         serviceClass.setScName(resultSet.getString("SERVICE_CLASS"));
/*  192 */         if (resultSet.getString("BUNDLE_TYPE") == null)
/*  193 */           serviceClass.setBundleType("");
/*      */         else {
/*  195 */           serviceClass.setBundleType(resultSet.getString("BUNDLE_TYPE"));
/*      */         }
/*  197 */         if (resultSet.getInt("CONSUMER_FLAG") == 1) {
/*  198 */           serviceClass.setScConsumer(true);
/*  199 */           serviceClass.setOldscConsumer(true);
/*  200 */           serviceClass.setContractFlag("1");
/*      */         } else {
/*  202 */           serviceClass.setScConsumer(false);
/*  203 */           serviceClass.setOldscConsumer(false);
/*      */         }
/*      */ 
/*  206 */         if (resultSet.getInt("ENTERPRISE_FLAG") == 1) {
/*  207 */           serviceClass.setScEnt(true);
/*  208 */           serviceClass.setOldscEnt(true);
/*  209 */           serviceClass.setContractFlag("2");
/*      */         } else {
/*  211 */           serviceClass.setScEnt(false);
/*  212 */           serviceClass.setOldscEnt(false);
/*      */         }
/*      */ 
/*  215 */         if ((resultSet.getInt("PRE_FLAG") == 1) && (resultSet.getInt("HYBIRD_FLAG") == 1)) {
/*  216 */           serviceClass.setScPre(true);
/*  217 */           serviceClass.setOldscPre(true);
/*  218 */           serviceClass.setTypeFlag("1");
/*  219 */           serviceClass.setScHybird(true);
/*  220 */         } else if ((resultSet.getInt("PRE_FLAG") == 1) && (resultSet.getInt("HYBIRD_FLAG") == 0)) {
/*  221 */           serviceClass.setScPre(true);
/*  222 */           serviceClass.setOldscPre(true);
/*  223 */           serviceClass.setTypeFlag("1");
/*  224 */           serviceClass.setScHybird(false);
/*      */         } else {
/*  226 */           serviceClass.setScPre(false);
/*  227 */           serviceClass.setOldscPre(false);
/*  228 */           serviceClass.setScHybird(false);
/*      */         }
/*      */ 
/*  231 */         if (resultSet.getInt("POST_FLAG") == 1) {
/*  232 */           serviceClass.setTypeFlag("2");
/*  233 */           serviceClass.setScPost(true);
/*  234 */           serviceClass.setOldscPost(true);
/*      */         } else {
/*  236 */           serviceClass.setScPost(false);
/*  237 */           serviceClass.setOldscPost(false);
/*      */         }
/*      */ 
/*  240 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1) {
/*  241 */           serviceClass.setActivationSource(true);
/*  242 */           serviceClass.setOldactivationSource(true);
/*      */         } else {
/*  244 */           serviceClass.setActivationSource(false);
/*  245 */           serviceClass.setOldactivationSource(false);
/*      */         }
/*      */ 
/*  248 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1) {
/*  249 */           serviceClass.setDeacSource(true);
/*  250 */           serviceClass.setOldDeacSource(true);
/*      */         }
/*      */         else {
/*  253 */           serviceClass.setDeacSource(false);
/*  254 */           serviceClass.setOldDeacSource(false);
/*      */         }
/*      */ 
/*  259 */         results.add(serviceClass);
/*      */       }
/*  261 */       closeConnection(connection, statement);
/*  262 */       return results;
/*      */     } catch (Exception e) {
/*  264 */       e.printStackTrace();
/*  265 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  266 */       closeConnection(connection, statement);
/*  267 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getTariffModel()
/*      */   {
/*  275 */     Connection connection = null;
/*  276 */     PreparedStatement statement = null;
/*  277 */     ArrayList results = new ArrayList();
/*  278 */     ResultSet resultSet = null;
/*      */     try
/*      */     {
/*  281 */       QueryModel query = getQuery(BackEndConstants.TARIFF_MODEL);
/*  282 */       connection = getConnection();
/*  283 */       statement = connection.prepareStatement(query.getSql());
/*  284 */       logger.info("Query : " + query.getSql());
/*  285 */       resultSet = statement.executeQuery();
/*  286 */       while (resultSet.next())
/*      */       {
/*  288 */         TariffModel tariffModel = new TariffModel();
/*  289 */         tariffModel.setTmCode(resultSet.getInt("TARIFF_MODEL_CODE"));
/*  290 */         tariffModel.setTmName(resultSet.getString("TARIFF_MODEL"));
/*      */ 
/*  292 */         if (resultSet.getString("BUNDLE_TYPE") == null)
/*  293 */           tariffModel.setBundleType("");
/*      */         else {
/*  295 */           tariffModel.setBundleType(resultSet.getString("BUNDLE_TYPE"));
/*      */         }
/*  297 */         if (resultSet.getInt("CONSUMER_FLAG") == 1) {
/*  298 */           tariffModel.setTmConsumer(true);
/*      */         }
/*      */         else {
/*  301 */           tariffModel.setTmConsumer(false);
/*      */         }
/*      */ 
/*  304 */         if (resultSet.getInt("ENTERPRISE_FLAG") == 1)
/*  305 */           tariffModel.setTmEnt(true);
/*      */         else {
/*  307 */           tariffModel.setTmEnt(false);
/*      */         }
/*      */ 
/*  310 */         if (resultSet.getInt("PRE_FLAG") == 1)
/*  311 */           tariffModel.setTmPre(true);
/*      */         else {
/*  313 */           tariffModel.setTmPre(false);
/*      */         }
/*      */ 
/*  316 */         if (resultSet.getInt("POST_FLAG") == 1)
/*  317 */           tariffModel.setTmPost(true);
/*      */         else {
/*  319 */           tariffModel.setTmPost(false);
/*      */         }
/*      */ 
/*  322 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*  323 */           tariffModel.setActivationSource(true);
/*      */         else {
/*  325 */           tariffModel.setActivationSource(false);
/*      */         }
/*      */ 
/*  328 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1) {
/*  329 */           tariffModel.setDeacSource(true);
/*      */         }
/*      */         else {
/*  332 */           tariffModel.setDeacSource(false);
/*      */         }
/*      */ 
/*  335 */         tariffModel.setOldactivationSource(tariffModel
/*  336 */           .isActivationSource());
/*  337 */         tariffModel.setOldtmConsumer(tariffModel.isTmConsumer());
/*  338 */         tariffModel.setOldtmEnt(tariffModel.isTmEnt());
/*      */ 
/*  340 */         tariffModel.setOldtmPost(tariffModel.isTmPost());
/*  341 */         tariffModel.setOldactivationSource(tariffModel.isTmPre());
/*      */ 
/*  343 */         results.add(tariffModel);
/*      */       }
/*  345 */       closeConnection(connection, statement);
/*  346 */       return results;
/*      */     } catch (Exception e) {
/*  348 */       e.printStackTrace();
/*  349 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  350 */       closeConnection(connection, statement);
/*  351 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getTariffModelbyFlag(String name, String bundleType, ArrayList searchModels)
/*      */   {
/*  361 */     Connection connection = null;
/*  362 */     PreparedStatement statement = null;
/*  363 */     ArrayList results = new ArrayList();
/*  364 */     ResultSet resultSet = null;
/*  365 */     QueryModel query = getQuery(BackEndConstants.TARIFF_MODEL);
/*  366 */     String querySql = query.getSql();
/*  367 */     Iterator it = searchModels.iterator();
/*  368 */     int counter = 0;
/*  369 */     while (it.hasNext()) {
/*  370 */       SearchModel searchModel = (SearchModel)it.next();
/*  371 */       String attr = searchModel.getAtt();
/*  372 */       boolean valueBoolean = searchModel.isValue();
/*  373 */       int value = -1;
/*  374 */       boolean empty = searchModel.isEmpty();
/*  375 */       if (valueBoolean)
/*  376 */         value = 1;
/*      */       else {
/*  378 */         value = 0;
/*      */       }
/*      */ 
/*  381 */       if (counter == 0) {
/*  382 */         if (!empty)
/*  383 */           querySql = querySql + " where " + attr + "=" + value;
/*      */         else {
/*  385 */           querySql = querySql + " where " + attr + " is null ";
/*      */         }
/*      */       }
/*  388 */       else if (!empty)
/*  389 */         querySql = querySql + " and  " + attr + "=" + value;
/*      */       else {
/*  391 */         querySql = querySql + " and " + attr + " is null ";
/*      */       }
/*      */ 
/*  396 */       counter++;
/*      */     }
/*      */ 
/*  399 */     if ((counter == 0) && (name != null) && (name.equals("All")))
/*  400 */       querySql = querySql + " where lower(TARIFF_MODEL) like lower('%%')";
/*  401 */     else if ((counter != 0) && (name != null) && (name.equals("All"))) {
/*  402 */       querySql = querySql + " and  lower(TARIFF_MODEL) like lower('%%')";
/*      */     }
/*      */ 
/*  405 */     if ((counter == 0) && (name != null) && (!name.equals("All")))
/*  406 */       querySql = querySql + " where  lower(TARIFF_MODEL) like lower('%" + name + 
/*  407 */         "%')";
/*  408 */     else if ((counter != 0) && (name != null) && (!name.equals("All"))) {
/*  409 */       querySql = querySql + " and  lower(TARIFF_MODEL) like lower('%" + name + 
/*  410 */         "%')";
/*      */     }
/*      */ 
/*  413 */     if (!bundleType.equals("")) {
/*  414 */       querySql = querySql + "and lower(BUNDLE_TYPE) like lower('%" + bundleType + 
/*  415 */         "%')";
/*      */     }
/*      */ 
/*  418 */     querySql = querySql + " order by TARIFF_MODEL";
/*  419 */     logger.debug("Tariff Search Query : " + querySql);
/*  420 */     System.out.println(querySql);
/*  421 */     logger.info("Query : " + querySql);
/*      */     try
/*      */     {
/*  425 */       connection = getConnection();
/*  426 */       statement = connection.prepareStatement(querySql);
/*  427 */       resultSet = statement.executeQuery();
/*  428 */       while (resultSet.next())
/*      */       {
/*  430 */         TariffModel tariffModel = new TariffModel();
/*  431 */         tariffModel.setTmCode(resultSet.getInt("TARIFF_MODEL_CODE"));
/*  432 */         tariffModel.setTmName(resultSet.getString("TARIFF_MODEL"));
/*  433 */         if (resultSet.getString("BUNDLE_TYPE") == null)
/*  434 */           tariffModel.setBundleType("");
/*      */         else {
/*  436 */           tariffModel.setBundleType(resultSet.getString("BUNDLE_TYPE"));
/*      */         }
/*  438 */         if (resultSet.getInt("CONSUMER_FLAG") == 1) {
/*  439 */           tariffModel.setTmConsumer(true);
/*  440 */           tariffModel.setOldtmConsumer(true);
/*  441 */           tariffModel.setContractFlag("1");
/*      */         } else {
/*  443 */           tariffModel.setTmConsumer(false);
/*  444 */           tariffModel.setOldtmConsumer(false);
/*      */         }
/*      */ 
/*  448 */         if (resultSet.getInt("ENTERPRISE_FLAG") == 1) {
/*  449 */           tariffModel.setTmEnt(true);
/*  450 */           tariffModel.setOldtmEnt(true);
/*  451 */           tariffModel.setContractFlag("2");
/*      */         } else {
/*  453 */           tariffModel.setTmEnt(false);
/*  454 */           tariffModel.setOldtmEnt(false);
/*      */         }
/*      */ 
/*  457 */         if ((resultSet.getInt("PRE_FLAG") == 1) && (resultSet.getInt("HYBIRD_FLAG") == 1)) {
/*  458 */           tariffModel.setTmPre(true);
/*  459 */           tariffModel.setOldtmPre(true);
/*  460 */           tariffModel.setTypeFlag("1");
/*  461 */           tariffModel.setTmHybird(true);
/*  462 */         } else if ((resultSet.getInt("PRE_FLAG") == 1) && (resultSet.getInt("HYBIRD_FLAG") == 0)) {
/*  463 */           tariffModel.setTmPre(true);
/*  464 */           tariffModel.setOldtmPre(true);
/*  465 */           tariffModel.setTypeFlag("1");
/*  466 */           tariffModel.setTmHybird(false);
/*      */         } else {
/*  468 */           tariffModel.setTmPre(false);
/*  469 */           tariffModel.setOldtmPre(false);
/*  470 */           tariffModel.setTmHybird(false);
/*      */         }
/*      */ 
/*  473 */         if (resultSet.getInt("POST_FLAG") == 1) {
/*  474 */           tariffModel.setTypeFlag("2");
/*  475 */           tariffModel.setTmPost(true);
/*  476 */           tariffModel.setOldtmPost(true);
/*      */         }
/*      */         else {
/*  479 */           tariffModel.setTmPost(false);
/*  480 */           tariffModel.setOldtmPost(false);
/*      */         }
/*      */ 
/*  483 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1) {
/*  484 */           tariffModel.setActivationSource(true);
/*  485 */           tariffModel.setOldactivationSource(true);
/*      */         } else {
/*  487 */           tariffModel.setActivationSource(false);
/*  488 */           tariffModel.setOldactivationSource(false);
/*      */         }
/*      */ 
/*  491 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1) {
/*  492 */           tariffModel.setDeacSource(true);
/*  493 */           tariffModel.setOldDeacSource(true);
/*      */         }
/*      */         else {
/*  496 */           tariffModel.setDeacSource(false);
/*  497 */           tariffModel.setOldDeacSource(false);
/*      */         }
/*      */ 
/*  506 */         results.add(tariffModel);
/*      */       }
/*  508 */       closeConnection(connection, statement);
/*  509 */       return results;
/*      */     } catch (Exception e) {
/*  511 */       e.printStackTrace();
/*  512 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  513 */       closeConnection(connection, statement);
/*  514 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getRatePlan()
/*      */   {
/*  522 */     Connection connection = null;
/*  523 */     PreparedStatement statement = null;
/*  524 */     ArrayList results = new ArrayList();
/*  525 */     ResultSet resultSet = null;
/*      */     try
/*      */     {
/*  528 */       QueryModel query = getQuery(BackEndConstants.RATE_PLAN);
/*  529 */       connection = getConnection();
/*  530 */       statement = connection.prepareStatement(query.getSql());
/*  531 */       logger.info("Query : " + query.getSql());
/*  532 */       resultSet = statement.executeQuery();
/*  533 */       while (resultSet.next())
/*      */       {
/*  535 */         RatePlan ratePlan = new RatePlan();
/*  536 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*  537 */           ratePlan.setActivationSource(true);
/*      */         else {
/*  539 */           ratePlan.setActivationSource(false);
/*      */         }
/*      */ 
/*  542 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1)
/*  543 */           ratePlan.setDeacSource(true);
/*      */         else {
/*  545 */           ratePlan.setDeacSource(false);
/*      */         }
/*      */ 
/*  548 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  549 */           ratePlan.setShowFlag(true);
/*      */         else {
/*  551 */           ratePlan.setShowFlag(false);
/*      */         }
/*      */ 
/*  554 */         if (resultSet.getInt("HYBIRD_FLAG") == 1)
/*  555 */           ratePlan.setHybird(true);
/*      */         else {
/*  557 */           ratePlan.setHybird(false);
/*      */         }
/*      */ 
/*  560 */         ratePlan.setRpCode(resultSet.getString("RATE_PLAN_CODE"));
/*  561 */         ratePlan
/*  562 */           .setRpContractType(resultSet.getString("CONTRACT_TYPE"));
/*  563 */         ratePlan.setRpName(resultSet.getString("RATE_PLAN"));
/*  564 */         ratePlan.setRpType(resultSet.getString("RATE_PLAN_TYPE"));
/*  565 */         System.out.println(resultSet.getInt("RATE_PLAN_GROUP_KEY"));
/*  566 */         if (resultSet.getInt("RATE_PLAN_GROUP_KEY") != 0)
/*      */         {
/*  568 */           RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  569 */           ratePlanGroup
/*  570 */             .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  571 */           ratePlanGroup.setRpGroupName(resultSet
/*  572 */             .getString("RATE_PLAN_GROUP"));
/*  573 */           ratePlanGroup.setRpGroupKey(resultSet
/*  574 */             .getInt("GROUP_KEY"));
/*  575 */           if (resultSet.getInt("GROUP_SHOW_FLAG") == 1)
/*  576 */             ratePlanGroup.setRpGroupShow(true);
/*      */           else {
/*  578 */             ratePlanGroup.setRpGroupShow(false);
/*      */           }
/*  580 */           ratePlan.setRatePlanGroup(ratePlanGroup);
/*      */         } else {
/*  582 */           ratePlan.setRatePlanGroup(new RatePlanGroup());
/*      */         }
/*  584 */         ratePlan.setData_voice_adsl_flag(resultSet.getString("DATA_VOICE_ADSL_FLAG"));
/*  585 */         ratePlan.setBundle_flag(resultSet.getString("BUNDLE_FLAG"));
/*  586 */         ratePlan.setFor_ivr_cost(resultSet.getString("FOR_IVR_COST"));
/*  587 */         ratePlan.setFor_ivr_rev(resultSet.getString("FOR_IVR_REV"));
/*  588 */         ratePlan.setCombined(resultSet.getString("COMBINED"));
/*  589 */         ratePlan.setPost_pre_flag(resultSet.getString("POST_PRE_FLAG"));
/*      */ 
/*  591 */         results.add(ratePlan);
/*      */       }
/*  593 */       closeConnection(connection, statement);
/*  594 */       return results;
/*      */     } catch (Exception e) {
/*  596 */       e.printStackTrace();
/*  597 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  598 */       closeConnection(connection, statement);
/*  599 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getRatePlan(String name)
/*      */   {
/*  604 */     Connection connection = null;
/*  605 */     PreparedStatement statement = null;
/*  606 */     ArrayList results = new ArrayList();
/*  607 */     ResultSet resultSet = null;
/*  608 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN);
/*  609 */     String qs = query.getSql();
/*  610 */     System.out.println(qs);
/*  611 */     if ((name != null) && (!name.equals("")))
/*  612 */       qs = qs + " and  lower(Rate_plan) like  lower('%" + name + "%')";
/*      */     else {
/*  614 */       qs = qs + " and lower(Rate_plan) like  lower('%%')";
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  619 */       connection = getConnection();
/*  620 */       statement = connection.prepareStatement(qs);
/*  621 */       System.out.println(qs);
/*  622 */       logger.info("Query : " + qs);
/*  623 */       resultSet = statement.executeQuery();
/*      */ 
/*  625 */       while (resultSet.next())
/*      */       {
/*  627 */         RatePlan ratePlan = new RatePlan();
/*  628 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*  629 */           ratePlan.setActivationSource(true);
/*      */         else {
/*  631 */           ratePlan.setActivationSource(false);
/*      */         }
/*      */ 
/*  634 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1)
/*  635 */           ratePlan.setDeacSource(true);
/*      */         else {
/*  637 */           ratePlan.setDeacSource(false);
/*      */         }
/*      */ 
/*  640 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  641 */           ratePlan.setShowFlag(true);
/*      */         else {
/*  643 */           ratePlan.setShowFlag(false);
/*      */         }
/*      */ 
/*  646 */         if (resultSet.getInt("HYBIRD_FLAG") == 1)
/*  647 */           ratePlan.setHybird(true);
/*      */         else {
/*  649 */           ratePlan.setHybird(false);
/*      */         }
/*      */ 
/*  652 */         ratePlan.setRpCode(resultSet.getString("RATE_PLAN_CODE"));
/*  653 */         ratePlan
/*  654 */           .setRpContractType(resultSet.getString("CONTRACT_TYPE"));
/*  655 */         ratePlan.setRpName(resultSet.getString("RATE_PLAN"));
/*  656 */         ratePlan.setRpType(resultSet.getString("RATE_PLAN_TYPE"));
/*  657 */         System.out.println(resultSet.getInt("RATE_PLAN_GROUP_KEY"));
/*  658 */         if (resultSet.getInt("RATE_PLAN_GROUP_KEY") != 0)
/*      */         {
/*  660 */           RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  661 */           ratePlanGroup
/*  662 */             .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  663 */           ratePlanGroup.setRpGroupName(resultSet
/*  664 */             .getString("RATE_PLAN_GROUP"));
/*  665 */           ratePlanGroup.setRpGroupKey(resultSet
/*  666 */             .getInt("GROUP_KEY"));
/*  667 */           if (resultSet.getInt("GROUP_SHOW_FLAG") == 1)
/*  668 */             ratePlanGroup.setRpGroupShow(true);
/*      */           else {
/*  670 */             ratePlanGroup.setRpGroupShow(false);
/*      */           }
/*  672 */           ratePlan.setRatePlanGroup(ratePlanGroup);
/*      */         } else {
/*  674 */           ratePlan.setRatePlanGroup(new RatePlanGroup());
/*      */         }
/*  676 */         ratePlan.setData_voice_adsl_flag(resultSet.getString("DATA_VOICE_ADSL_FLAG"));
/*  677 */         ratePlan.setBundle_flag(resultSet.getString("BUNDLE_FLAG"));
/*  678 */         ratePlan.setFor_ivr_cost(resultSet.getString("FOR_IVR_COST"));
/*  679 */         ratePlan.setFor_ivr_rev(resultSet.getString("FOR_IVR_REV"));
/*  680 */         ratePlan.setCombined(resultSet.getString("COMBINED"));
/*  681 */         ratePlan.setPost_pre_flag(resultSet.getString("POST_PRE_FLAG"));
/*  682 */         results.add(ratePlan);
/*      */       }
/*  684 */       closeConnection(connection, statement);
/*  685 */       return results;
/*      */     } catch (Exception e) {
/*  687 */       e.printStackTrace();
/*  688 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  689 */       closeConnection(connection, statement);
/*  690 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getRatePlanByFlags(String name, String code, String type, String contractType, ArrayList searchModels)
/*      */   {
/*  705 */     Connection connection = null;
/*  706 */     PreparedStatement statement = null;
/*  707 */     ArrayList results = new ArrayList();
/*  708 */     ResultSet resultSet = null;
/*  709 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN);
/*  710 */     String querySql = query.getSql();
/*  711 */     if ((name != null) && (!name.equals("")))
/*  712 */       querySql = querySql + " and lower(RATE_PLAN) like lower('%" + name + "%')";
/*      */     else {
/*  714 */       querySql = querySql + " and lower(RATE_PLAN) like lower('%%')";
/*      */     }
/*      */ 
/*  717 */     if ((code != null) && (!code.equals("")))
/*  718 */       querySql = querySql + " and lower(RATE_PLAN_CODE) like lower('" + code + "')";
/*      */     else {
/*  720 */       querySql = querySql + " and lower(RATE_PLAN_CODE) like lower('%%')";
/*      */     }
/*      */ 
/*  723 */     if ((type != null) && (!type.equals("")))
/*  724 */       querySql = querySql + " and lower(RATE_PLAN_TYPE) like lower('" + type + "')";
/*      */     else {
/*  726 */       querySql = querySql + " and lower(RATE_PLAN_TYPE) like lower('%%')";
/*      */     }
/*      */ 
/*  729 */     if ((contractType != null) && (!contractType.equals("")))
/*  730 */       querySql = querySql + " and lower(CONTRACT_TYPE) like lower('" + contractType + 
/*  731 */         "')";
/*      */     else {
/*  733 */       querySql = querySql + " and lower(CONTRACT_TYPE) like lower('%%')";
/*      */     }
/*      */ 
/*  736 */     Iterator it = searchModels.iterator();
/*      */ 
/*  738 */     while (it.hasNext()) {
/*  739 */       SearchModel searchModel = (SearchModel)it.next();
/*  740 */       String attr = searchModel.getAtt();
/*  741 */       boolean valueBoolean = searchModel.isValue();
/*  742 */       int value = -1;
/*  743 */       boolean empty = searchModel.isEmpty();
/*  744 */       if (valueBoolean)
/*  745 */         value = 1;
/*      */       else {
/*  747 */         value = 0;
/*      */       }
/*      */ 
/*  750 */       if (!empty)
/*  751 */         querySql = querySql + " and  " + attr + "=" + value;
/*      */       else {
/*  753 */         querySql = querySql + " and " + attr + " is null ";
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  760 */       connection = getConnection();
/*  761 */       statement = connection.prepareStatement(querySql);
/*  762 */       logger.info("Query : " + querySql);
/*  763 */       resultSet = statement.executeQuery();
/*  764 */       while (resultSet.next())
/*      */       {
/*  766 */         RatePlan ratePlan = new RatePlan();
/*  767 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*  768 */           ratePlan.setActivationSource(true);
/*      */         else {
/*  770 */           ratePlan.setActivationSource(false);
/*      */         }
/*      */ 
/*  773 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1)
/*  774 */           ratePlan.setDeacSource(true);
/*      */         else {
/*  776 */           ratePlan.setDeacSource(false);
/*      */         }
/*      */ 
/*  779 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  780 */           ratePlan.setShowFlag(true);
/*      */         else {
/*  782 */           ratePlan.setShowFlag(false);
/*      */         }
/*  784 */         ratePlan.setRpCode(resultSet.getString("RATE_PLAN_CODE"));
/*  785 */         ratePlan
/*  786 */           .setRpContractType(resultSet.getString("CONTRACT_TYPE"));
/*  787 */         ratePlan.setRpName(resultSet.getString("RATE_PLAN"));
/*  788 */         ratePlan.setRpType(resultSet.getString("RATE_PLAN_TYPE"));
/*      */ 
/*  791 */         RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  792 */         ratePlanGroup
/*  793 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  794 */         ratePlanGroup.setRpGroupName(resultSet
/*  795 */           .getString("RATE_PLAN_GROUP"));
/*  796 */         ratePlanGroup.setRpGroupKey(resultSet
/*  797 */           .getInt("GROUP_KEY"));
/*  798 */         if (resultSet.getInt("GROUP_SHOW_FLAG") == 1)
/*  799 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/*  801 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/*  803 */         ratePlan.setRatePlanGroup(ratePlanGroup);
/*      */ 
/*  806 */         results.add(ratePlan);
/*      */       }
/*  808 */       closeConnection(connection, statement);
/*  809 */       return results;
/*      */     } catch (Exception e) {
/*  811 */       e.printStackTrace();
/*  812 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  813 */       closeConnection(connection, statement);
/*  814 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getRatePlanbyGroup(int groupKey)
/*      */   {
/*  824 */     Connection connection = null;
/*  825 */     PreparedStatement statement = null;
/*  826 */     ArrayList results = new ArrayList();
/*  827 */     ResultSet resultSet = null;
/*  828 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN);
/*  829 */     String querySql = query.getSql();
/*  830 */     querySql = querySql + " and a.RATE_PLAN_GROUP_KEY  = " + groupKey;
/*  831 */     System.out.println(querySql);
/*  832 */     logger.info("Query : " + querySql);
/*      */     try
/*      */     {
/*  835 */       connection = getConnection();
/*  836 */       statement = connection.prepareStatement(querySql);
/*  837 */       resultSet = statement.executeQuery();
/*  838 */       while (resultSet.next())
/*      */       {
/*  840 */         RatePlan ratePlan = new RatePlan();
/*  841 */         if (resultSet.getInt("ACTIVATION_SOURCE_FLAG") == 1)
/*  842 */           ratePlan.setActivationSource(true);
/*      */         else {
/*  844 */           ratePlan.setActivationSource(false);
/*      */         }
/*  846 */         if (resultSet.getInt("DEAC_SOURCE_FLAG") == 1)
/*  847 */           ratePlan.setDeacSource(true);
/*      */         else {
/*  849 */           ratePlan.setDeacSource(false);
/*      */         }
/*      */ 
/*  852 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  853 */           ratePlan.setShowFlag(true);
/*      */         else {
/*  855 */           ratePlan.setShowFlag(false);
/*      */         }
/*      */ 
/*  858 */         ratePlan.setRpCode(resultSet.getString("RATE_PLAN_CODE"));
/*  859 */         ratePlan
/*  860 */           .setRpContractType(resultSet.getString("CONTRACT_TYPE"));
/*  861 */         ratePlan.setRpName(resultSet.getString("RATE_PLAN"));
/*  862 */         ratePlan.setRpType(resultSet.getString("RATE_PLAN_TYPE"));
/*      */ 
/*  864 */         RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  865 */         ratePlanGroup
/*  866 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  867 */         ratePlanGroup.setRpGroupName(resultSet
/*  868 */           .getString("RATE_PLAN_GROUP"));
/*  869 */         ratePlanGroup.setRpGroupKey(resultSet
/*  870 */           .getInt("GROUP_KEY"));
/*  871 */         if (resultSet.getInt("GROUP_SHOW_FLAG") == 1)
/*  872 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/*  874 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/*  876 */         ratePlan.setRatePlanGroup(ratePlanGroup);
/*      */ 
/*  878 */         results.add(ratePlan);
/*      */       }
/*  880 */       closeConnection(connection, statement);
/*  881 */       return results;
/*      */     } catch (Exception e) {
/*  883 */       e.printStackTrace();
/*  884 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  885 */       closeConnection(connection, statement);
/*  886 */     }return null;
/*      */   }
/*      */ 
/*      */   public ArrayList getRatePlanGroup()
/*      */   {
/*  894 */     Connection connection = null;
/*  895 */     PreparedStatement statement = null;
/*  896 */     ArrayList results = new ArrayList();
/*  897 */     ResultSet resultSet = null;
/*      */     try
/*      */     {
/*  900 */       QueryModel query = getQuery(BackEndConstants.RATE_PLAN_GROUP);
/*  901 */       connection = getConnection();
/*  902 */       statement = connection.prepareStatement(query.getSql());
/*  903 */       logger.info("Query : " + query.getSql());
/*  904 */       resultSet = statement.executeQuery();
/*  905 */       while (resultSet.next())
/*      */       {
/*  907 */         RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  908 */         ratePlanGroup
/*  909 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  910 */         ratePlanGroup.setRpGroupName(resultSet
/*  911 */           .getString("RATE_PLAN_GROUP"));
/*  912 */         ratePlanGroup.setRpGroupKey(resultSet
/*  913 */           .getInt("RATE_PLAN_GROUP_KEY"));
/*  914 */         ratePlanGroup.setRatePlans(getRatePlanbyGroup(ratePlanGroup
/*  915 */           .getRpGroupKey()));
/*  916 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  917 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/*  919 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/*      */ 
/*  922 */         results.add(ratePlanGroup);
/*      */       }
/*  924 */       closeConnection(connection, statement);
/*  925 */       return results;
/*      */     } catch (Exception e) {
/*  927 */       e.printStackTrace();
/*  928 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  929 */       closeConnection(connection, statement);
/*  930 */     }return null;
/*      */   }
/*      */ 
/*      */   public RatePlanGroup getRatePlanGroupbyKeyALL(int key)
/*      */   {
/*  938 */     Connection connection = null;
/*  939 */     PreparedStatement statement = null;
/*  940 */     ArrayList results = new ArrayList();
/*  941 */     ResultSet resultSet = null;
/*  942 */     RatePlanGroup ratePlanGroup = null;
/*  943 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN_GROUP);
/*  944 */     String querySql = query.getSql();
/*  945 */     querySql = querySql + "where RATE_PLAN_GROUP_KEY =" + key;
/*      */     try
/*      */     {
/*  948 */       connection = getConnection();
/*  949 */       statement = connection.prepareStatement(querySql);
/*  950 */       logger.info("Query : " + querySql);
/*  951 */       resultSet = statement.executeQuery();
/*  952 */       while (resultSet.next())
/*      */       {
/*  954 */         ratePlanGroup = new RatePlanGroup();
/*  955 */         ratePlanGroup
/*  956 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/*  957 */         ratePlanGroup.setRpGroupName(resultSet
/*  958 */           .getString("RATE_PLAN_GROUP"));
/*  959 */         ratePlanGroup.setRpGroupKey(resultSet
/*  960 */           .getInt("RATE_PLAN_GROUP_KEY"));
/*  961 */         ratePlanGroup.setRatePlans(getRatePlanbyGroup(ratePlanGroup
/*  962 */           .getRpGroupKey()));
/*  963 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/*  964 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/*  966 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/*      */       }
/*      */ 
/*  970 */       closeConnection(connection, statement);
/*  971 */       return ratePlanGroup;
/*      */     } catch (Exception e) {
/*  973 */       e.printStackTrace();
/*  974 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  975 */       closeConnection(connection, statement);
/*  976 */     }return null;
/*      */   }
/*      */ 
/*      */   public RatePlanGroup getRatePlanGroupbyKey(int key)
/*      */   {
/*  984 */     Connection connection = null;
/*  985 */     PreparedStatement statement = null;
/*  986 */     ArrayList results = new ArrayList();
/*  987 */     ResultSet resultSet = null;
/*  988 */     RatePlanGroup ratePlanGroup = new RatePlanGroup();
/*  989 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN_GROUP);
/*  990 */     String querySql = query.getSql();
/*  991 */     querySql = querySql + " where RATE_PLAN_GROUP_KEY =" + key;
/*      */     try
/*      */     {
/*  994 */       connection = getConnection();
/*  995 */       statement = connection.prepareStatement(querySql);
/*  996 */       logger.info("Query : " + querySql);
/*  997 */       resultSet = statement.executeQuery();
/*  998 */       while (resultSet.next())
/*      */       {
/* 1000 */         ratePlanGroup = new RatePlanGroup();
/* 1001 */         ratePlanGroup
/* 1002 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/* 1003 */         ratePlanGroup.setRpGroupName(resultSet
/* 1004 */           .getString("RATE_PLAN_GROUP"));
/* 1005 */         ratePlanGroup.setRpGroupKey(resultSet
/* 1006 */           .getInt("RATE_PLAN_GROUP_KEY"));
/* 1007 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/* 1008 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/* 1010 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/*      */       }
/*      */ 
/* 1014 */       closeConnection(connection, statement);
/* 1015 */       return ratePlanGroup;
/*      */     } catch (Exception e) {
/* 1017 */       e.printStackTrace();
/* 1018 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1019 */       closeConnection(connection, statement);
/* 1020 */     }return null;
/*      */   }
/*      */ 
/*      */   public void updateServicClass(ArrayList serviceClasses)
/*      */   {
/* 1029 */     Connection connection = null;
/* 1030 */     PreparedStatement statement = null;
/* 1031 */     Iterator it = serviceClasses.iterator();
/* 1032 */     ArrayList logFact = new ArrayList();
/* 1033 */     QueryModel query = getQuery(BackEndConstants.UPDATE_SC);
/* 1034 */     String querySql = query.getSql();
/* 1035 */     logger.debug("updateServicClass : " + querySql);
/*      */ 
/* 1037 */     String values = "Query Values: ";
/*      */     try
/*      */     {
/* 1041 */       connection = getConnection();
/* 1042 */       statement = connection.prepareStatement(querySql);
/* 1043 */       while (it.hasNext()) {
/* 1044 */         ServiceClass serviceClass = (ServiceClass)it.next();
/*      */ 
/* 1046 */         statement.setInt(9, serviceClass.getScCode());
/* 1047 */         statement.setString(8, serviceClass.getBundleType());
/* 1048 */         if (serviceClass.getContractFlag(true) == null) {
/* 1049 */           statement.setNull(1, 4);
/* 1050 */           values = values + " Param1=null - ";
/* 1051 */           statement.setNull(2, 4);
/* 1052 */           values = values + " Param2=null - ";
/*      */         }
/*      */         else {
/* 1055 */           if (serviceClass.isScConsumer()) {
/* 1056 */             statement.setInt(1, 1);
/* 1057 */             values = values + " Param1=1 - ";
/*      */           } else {
/* 1059 */             statement.setInt(1, 0);
/* 1060 */             values = values + " Param1=0 - ";
/*      */           }
/*      */ 
/* 1063 */           if (serviceClass.isScEnt()) {
/* 1064 */             statement.setInt(2, 1);
/* 1065 */             values = values + " Param2=1 - ";
/*      */           } else {
/* 1067 */             statement.setInt(2, 0);
/* 1068 */             values = values + " Param2=0 - ";
/*      */           }
/*      */         }
/* 1071 */         if (serviceClass.getTypeFlag(true) == null) {
/* 1072 */           statement.setNull(3, 4);
/* 1073 */           values = values + " Param3=null - ";
/* 1074 */           statement.setNull(4, 4);
/* 1075 */           values = values + " Param4=null - ";
/*      */         } else {
/* 1077 */           if (serviceClass.isScPre()) {
/* 1078 */             statement.setInt(3, 1);
/* 1079 */             values = values + " Param3=1 - ";
/*      */           } else {
/* 1081 */             statement.setInt(3, 0);
/* 1082 */             values = values + " Param3=0 - ";
/*      */           }
/* 1084 */           if (serviceClass.isScPost()) {
/* 1085 */             statement.setInt(4, 1);
/* 1086 */             values = values + " Param4=1 - ";
/*      */           } else {
/* 1088 */             statement.setInt(4, 0);
/* 1089 */             values = values + " Param4=0 - ";
/*      */           }
/*      */         }
/* 1092 */         if (serviceClass.isActivationSource()) {
/* 1093 */           statement.setInt(5, 1);
/* 1094 */           values = values + " Param5=1 - ";
/*      */         } else {
/* 1096 */           statement.setInt(5, 0);
/* 1097 */           values = values + " Param5=0 - ";
/*      */         }
/*      */ 
/* 1100 */         if (serviceClass.isDeacSource()) {
/* 1101 */           statement.setInt(6, 1);
/* 1102 */           values = values + " Param6=1 - ";
/*      */         } else {
/* 1104 */           statement.setInt(6, 0);
/* 1105 */           values = values + " Param6=0 - ";
/*      */         }
/* 1107 */         if ((serviceClass.isScHybird()) && (serviceClass.isScPre())) {
/* 1108 */           statement.setInt(7, 1);
/* 1109 */           values = values + " Param7=1 - ";
/*      */         } else {
/* 1111 */           statement.setInt(7, 0);
/* 1112 */           values = values + " Param7=0";
/*      */         }
/*      */ 
/* 1116 */         if ((serviceClass.getContractFlag(true) != null) && (serviceClass.isOldscEnt() != serviceClass.isScEnt())) {
/* 1117 */           LogFact fact = new LogFact();
/* 1118 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1119 */           fact.setLogAttribute(BackEndConstants.LOG_SC_ENT);
/* 1120 */           fact.setNewValue(String.valueOf(serviceClass.isScEnt()));
/* 1121 */           fact.setOldValue(String.valueOf(serviceClass.isOldscEnt()));
/* 1122 */           fact.setTimeStamp(new Date());
/* 1123 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1124 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1128 */         if ((serviceClass.getContractFlag(true) != null) && 
/* 1129 */           (serviceClass.isOldscConsumer() != serviceClass
/* 1129 */           .isScConsumer()))
/*      */         {
/* 1131 */           LogFact fact = new LogFact();
/* 1132 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1133 */           fact.setLogAttribute(BackEndConstants.LOG_SC_CONSUMER);
/* 1134 */           fact.setNewValue(
/* 1135 */             String.valueOf(serviceClass.isScConsumer()));
/* 1136 */           fact.setOldValue(String.valueOf(serviceClass
/* 1137 */             .isOldscConsumer()));
/* 1138 */           fact.setTimeStamp(new Date());
/* 1139 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1140 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1144 */         if ((serviceClass.getTypeFlag(true) != null) && (serviceClass.isOldscPre() != serviceClass.isScPre())) {
/* 1145 */           LogFact fact = new LogFact();
/* 1146 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1147 */           fact.setLogAttribute(BackEndConstants.LOG_SC_PRE);
/* 1148 */           fact.setNewValue(String.valueOf(serviceClass.isScPre()));
/* 1149 */           fact.setOldValue(String.valueOf(serviceClass.isOldscPre()));
/* 1150 */           fact.setTimeStamp(new Date());
/* 1151 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1152 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1156 */         if ((serviceClass.getTypeFlag(true) != null) && (serviceClass.isOldscPost() != serviceClass.isScPost()))
/*      */         {
/* 1158 */           LogFact fact = new LogFact();
/* 1159 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1160 */           fact.setLogAttribute(BackEndConstants.LOG_SC_POST);
/* 1161 */           fact.setNewValue(String.valueOf(serviceClass.isScPost()));
/* 1162 */           fact
/* 1163 */             .setOldValue(String.valueOf(serviceClass
/* 1164 */             .isOldscPost()));
/* 1165 */           fact.setTimeStamp(new Date());
/* 1166 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1167 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1172 */         if (serviceClass.isOldactivationSource() != serviceClass
/* 1172 */           .isActivationSource())
/*      */         {
/* 1174 */           LogFact fact = new LogFact();
/* 1175 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1176 */           fact.setLogAttribute(BackEndConstants.LOG_SC_ACTIVATION);
/* 1177 */           fact.setNewValue(String.valueOf(serviceClass
/* 1178 */             .isActivationSource()));
/* 1179 */           fact.setOldValue(String.valueOf(serviceClass
/* 1180 */             .isOldactivationSource()));
/* 1181 */           fact.setTimeStamp(new Date());
/* 1182 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1183 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1188 */         if (serviceClass.isOldDeacSource() != serviceClass
/* 1188 */           .isDeacSource())
/*      */         {
/* 1190 */           LogFact fact = new LogFact();
/* 1191 */           fact.setSource(String.valueOf(serviceClass.getScCode()));
/* 1192 */           fact.setLogAttribute(BackEndConstants.LOG_SC_DEAC);
/* 1193 */           fact.setNewValue(String.valueOf(serviceClass
/* 1194 */             .isDeacSource()));
/* 1195 */           fact.setOldValue(String.valueOf(serviceClass
/* 1196 */             .isOldDeacSource()));
/* 1197 */           fact.setTimeStamp(new Date());
/* 1198 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1199 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1204 */         logger.info("Query : " + querySql);
/* 1205 */         logger.info("Query values : " + values);
/* 1206 */         statement.addBatch();
/*      */       }
/*      */ 
/* 1209 */       int[] result = statement.executeBatch();
/* 1210 */       if (result.length == serviceClasses.size()) {
/* 1211 */         connection.commit();
/*      */ 
/* 1213 */         LogService.getDao().log(logFact);
/*      */       } else {
/* 1215 */         connection.rollback();
/*      */       }
/* 1217 */       closeConnection(connection, statement);
/*      */     }
/*      */     catch (Exception e) {
/* 1220 */       e.printStackTrace();
/* 1221 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1222 */       closeConnection(connection, statement);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateTariffs(ArrayList tariffs)
/*      */   {
/* 1232 */     Connection connection = null;
/* 1233 */     PreparedStatement statement = null;
/* 1234 */     Iterator it = tariffs.iterator();
/* 1235 */     ArrayList logFact = new ArrayList();
/* 1236 */     QueryModel query = getQuery(BackEndConstants.UPDATE_TM);
/* 1237 */     String querySql = query.getSql();
/* 1238 */     logger.debug("updateTariffs : " + querySql);
/*      */ 
/* 1240 */     String values = "Query Values: ";
/*      */     try
/*      */     {
/* 1244 */       connection = getConnection();
/* 1245 */       statement = connection.prepareStatement(querySql);
/* 1246 */       while (it.hasNext()) {
/* 1247 */         TariffModel tariffModel = (TariffModel)it.next();
/*      */ 
/* 1249 */         statement.setInt(9, tariffModel.getTmCode());
/* 1250 */         values = values + " Param9=" + tariffModel.getTmCode() + " - ";
/* 1251 */         statement.setString(8, tariffModel.getBundleType());
/* 1252 */         values = values + " Param8=" + tariffModel.getTmCode() + " - ";
/*      */ 
/* 1254 */         if (tariffModel.getContractFlag(true) == null) {
/* 1255 */           statement.setNull(1, 4);
/* 1256 */           values = values + " Param1=null - ";
/* 1257 */           statement.setNull(2, 4);
/* 1258 */           values = values + " Param2=null - ";
/*      */         } else {
/* 1260 */           if (tariffModel.isTmConsumer()) {
/* 1261 */             statement.setInt(1, 1);
/* 1262 */             values = values + " Param1=1 - ";
/*      */           } else {
/* 1264 */             statement.setInt(1, 0);
/* 1265 */             values = values + " Param1=0 - ";
/*      */           }
/*      */ 
/* 1268 */           if (tariffModel.isTmEnt()) {
/* 1269 */             statement.setInt(2, 1);
/* 1270 */             values = values + " Param2=1 - ";
/*      */           } else {
/* 1272 */             statement.setInt(2, 0);
/* 1273 */             values = values + " Param2=0 - ";
/*      */           }
/*      */         }
/*      */ 
/* 1277 */         if (tariffModel.getTypeFlag(true) == null) {
/* 1278 */           statement.setNull(3, 4);
/* 1279 */           values = values + " Param3=null - ";
/* 1280 */           statement.setNull(4, 4);
/* 1281 */           values = values + " Param4=null - ";
/*      */         } else {
/* 1283 */           if (tariffModel.isTmPre()) {
/* 1284 */             statement.setInt(3, 1);
/* 1285 */             values = values + " Param3=1 - ";
/*      */           } else {
/* 1287 */             statement.setInt(3, 0);
/* 1288 */             values = values + " Param3=0 - ";
/*      */           }
/* 1290 */           if (tariffModel.isTmPost()) {
/* 1291 */             statement.setInt(4, 1);
/* 1292 */             values = values + " Param4=1 - ";
/*      */           } else {
/* 1294 */             statement.setInt(4, 0);
/* 1295 */             values = values + " Param4=0 - ";
/*      */           }
/*      */         }
/* 1298 */         if (tariffModel.isActivationSource()) {
/* 1299 */           statement.setInt(5, 1);
/* 1300 */           values = values + " Param5=1 - ";
/*      */         } else {
/* 1302 */           statement.setInt(5, 0);
/* 1303 */           values = values + " Param5=0 - ";
/*      */         }
/*      */ 
/* 1306 */         if (tariffModel.isDeacSource()) {
/* 1307 */           statement.setInt(6, 1);
/* 1308 */           values = values + " Param6=1 - ";
/*      */         } else {
/* 1310 */           statement.setInt(6, 0);
/* 1311 */           values = values + " Param6=0 - ";
/*      */         }
/* 1313 */         if ((tariffModel.isTmHybird()) && (tariffModel.isTmPre())) {
/* 1314 */           statement.setInt(7, 1);
/* 1315 */           values = values + " Param7=1 - ";
/*      */         } else {
/* 1317 */           statement.setInt(7, 0);
/* 1318 */           values = values + " Param7=0 - ";
/*      */         }
/*      */ 
/* 1321 */         if ((tariffModel.getContractFlag(true) != null) && (tariffModel.isOldtmEnt() != tariffModel.isTmEnt())) {
/* 1322 */           LogFact fact = new LogFact();
/* 1323 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1324 */           fact.setLogAttribute(BackEndConstants.LOG_TARIFF_ENT);
/* 1325 */           fact.setNewValue(String.valueOf(tariffModel.isTmEnt()));
/* 1326 */           fact.setOldValue(String.valueOf(tariffModel.isOldtmEnt()));
/* 1327 */           fact.setTimeStamp(new Date());
/* 1328 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1329 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1333 */         if ((tariffModel.getContractFlag(true) != null) && (tariffModel.isOldtmConsumer() != tariffModel.isTmConsumer()))
/*      */         {
/* 1335 */           LogFact fact = new LogFact();
/* 1336 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1337 */           fact.setLogAttribute(BackEndConstants.LOG_TARIFF_CONSUMER);
/* 1338 */           fact
/* 1339 */             .setNewValue(String.valueOf(tariffModel
/* 1340 */             .isTmConsumer()));
/* 1341 */           fact.setOldValue(String.valueOf(tariffModel
/* 1342 */             .isOldtmConsumer()));
/* 1343 */           fact.setTimeStamp(new Date());
/* 1344 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1345 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1349 */         if ((tariffModel.getTypeFlag(true) != null) && (tariffModel.isOldtmPre() != tariffModel.isTmPre())) {
/* 1350 */           LogFact fact = new LogFact();
/* 1351 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1352 */           fact.setLogAttribute(BackEndConstants.LOG_TARIFF_PRE);
/* 1353 */           fact.setNewValue(String.valueOf(tariffModel.isTmPre()));
/* 1354 */           fact.setOldValue(String.valueOf(tariffModel.isOldtmPre()));
/* 1355 */           fact.setTimeStamp(new Date());
/* 1356 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1357 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1361 */         if ((tariffModel.getTypeFlag(true) != null) && (tariffModel.isOldtmPost() != tariffModel.isTmPost()))
/*      */         {
/* 1363 */           LogFact fact = new LogFact();
/* 1364 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1365 */           fact.setLogAttribute(BackEndConstants.LOG_TARIFF_POST);
/* 1366 */           fact.setNewValue(String.valueOf(tariffModel.isTmPost()));
/* 1367 */           fact.setOldValue(String.valueOf(tariffModel.isOldtmPost()));
/* 1368 */           fact.setTimeStamp(new Date());
/* 1369 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1370 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1375 */         if (tariffModel.isOldactivationSource() != tariffModel
/* 1375 */           .isActivationSource())
/*      */         {
/* 1377 */           LogFact fact = new LogFact();
/* 1378 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1379 */           fact
/* 1380 */             .setLogAttribute(BackEndConstants.LOG_TARIFF_ACTIVATION);
/* 1381 */           fact.setNewValue(String.valueOf(tariffModel
/* 1382 */             .isActivationSource()));
/* 1383 */           fact.setOldValue(String.valueOf(tariffModel
/* 1384 */             .isOldactivationSource()));
/* 1385 */           fact.setTimeStamp(new Date());
/* 1386 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1387 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1392 */         if (tariffModel.isOldDeacSource() != tariffModel
/* 1392 */           .isDeacSource())
/*      */         {
/* 1394 */           LogFact fact = new LogFact();
/* 1395 */           fact.setSource(String.valueOf(tariffModel.getTmCode()));
/* 1396 */           fact
/* 1397 */             .setLogAttribute(BackEndConstants.LOG_TARIFF_DEAC);
/* 1398 */           fact.setNewValue(String.valueOf(tariffModel
/* 1399 */             .isDeacSource()));
/* 1400 */           fact.setOldValue(String.valueOf(tariffModel
/* 1401 */             .isOldDeacSource()));
/* 1402 */           fact.setTimeStamp(new Date());
/* 1403 */           fact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1404 */           logFact.add(fact);
/*      */         }
/*      */ 
/* 1407 */         logger.info("Query : " + querySql);
/* 1408 */         logger.info("Query values : " + values);
/* 1409 */         statement.addBatch();
/*      */       }
/*      */ 
/* 1412 */       int[] result = statement.executeBatch();
/* 1413 */       if (result.length == tariffs.size()) {
/* 1414 */         connection.commit();
/* 1415 */         LogService.getDao().log(logFact);
/*      */       } else {
/* 1417 */         connection.rollback();
/*      */       }
/* 1419 */       closeConnection(connection, statement);
/*      */     }
/*      */     catch (Exception e) {
/* 1422 */       e.printStackTrace();
/* 1423 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1424 */       closeConnection(connection, statement);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateGroups(ArrayList rateplans, int groupKey, boolean show)
/*      */   {
/* 1435 */     Connection connection = null;
/* 1436 */     PreparedStatement statement = null;
/* 1437 */     Iterator it = rateplans.iterator();
/* 1438 */     ArrayList logFacts = new ArrayList();
/* 1439 */     QueryModel query = getQuery(BackEndConstants.UPDATE_GROUP);
/* 1440 */     String querySql = query.getSql();
/*      */     try
/*      */     {
/* 1444 */       connection = getConnection();
/* 1445 */       statement = connection.prepareStatement(querySql);
/* 1446 */       while (it.hasNext())
/*      */       {
/* 1449 */         String values = "Query Values: ";
/*      */ 
/* 1451 */         RatePlan rateplan = (RatePlan)it.next();
/* 1452 */         if ((rateplan.isUpdate()) || (rateplan.isOriginal())) {
/* 1453 */           statement.setInt(1, groupKey);
/* 1454 */           values = values + " Param1=" + groupKey + " - ";
/* 1455 */           statement.setString(3, rateplan.getRpCode());
/* 1456 */           values = values + " Param3=" + rateplan.getRpCode();
/* 1457 */           if (show) {
/* 1458 */             statement.setInt(2, 1);
/* 1459 */             values = values + " Param2=1 - ";
/*      */           } else {
/* 1461 */             statement.setInt(2, 0);
/* 1462 */             values = values + " Param2=0 - ";
/*      */           }
/*      */         }
/* 1465 */         logger.info("Query : " + querySql);
/* 1466 */         logger.info("Query values : " + values);
/* 1467 */         statement.addBatch();
/*      */       }
/*      */ 
/* 1470 */       statement.executeBatch();
/* 1471 */       connection.commit();
/* 1472 */       closeConnection(connection, statement);
/*      */ 
/* 1475 */       it = rateplans.iterator();
/* 1476 */       while (it.hasNext()) {
/* 1477 */         RatePlan rateplan = (RatePlan)it.next();
/* 1478 */         if (rateplan.isUpdate()) {
/* 1479 */           LogFact logFact = new LogFact();
/* 1480 */           logFact.setSource(rateplan.getRpCode());
/* 1481 */           logFact
/* 1482 */             .setLogAttribute(BackEndConstants.LOG_RATE_PLAN_GROUP);
/* 1483 */           logFact.setNewValue(String.valueOf(groupKey));
/* 1484 */           logFact.setOldValue(String.valueOf(rateplan
/* 1485 */             .getRatePlanGroup().getRpGroupKey()));
/* 1486 */           logFact.setTimeStamp(new Date());
/* 1487 */           logFact
/* 1488 */             .setUser(SessionHelper.getLoginBean()
/* 1489 */             .getUserModel());
/* 1490 */           logFacts.add(logFact);
/*      */         }
/*      */       }
/* 1493 */       LogService.getDao().log(logFacts);
/*      */     }
/*      */     catch (Exception e) {
/* 1496 */       e.printStackTrace();
/* 1497 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1498 */       closeConnection(connection, statement);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getMaxGroup()
/*      */   {
/* 1504 */     Connection connection = null;
/* 1505 */     PreparedStatement statement = null;
/* 1506 */     QueryModel query = getQuery(BackEndConstants.CREATE_GROUP);
/* 1507 */     String querySql = "select max(RATE_PLAN_GROUP_KEY) key from  RATE_PLAN_GROUP ";
/* 1508 */     int result = -1;
/*      */     try
/*      */     {
/* 1511 */       connection = getConnection();
/* 1512 */       statement = connection.prepareStatement(querySql);
/* 1513 */       logger.info("Query : " + querySql);
/* 1514 */       ResultSet resultSet = statement.executeQuery();
/* 1515 */       while (resultSet.next()) {
/* 1516 */         result = resultSet.getInt(1);
/*      */       }
/*      */ 
/* 1519 */       closeConnection(connection, statement);
/* 1520 */       return result;
/*      */     }
/*      */     catch (Exception e) {
/* 1523 */       e.printStackTrace();
/* 1524 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1525 */       closeConnection(connection, statement);
/* 1526 */     }return result;
/*      */   }
/*      */ 
/*      */   public ArrayList getGroupByname(String name, boolean show)
/*      */   {
/* 1533 */     Connection connection = null;
/* 1534 */     PreparedStatement statement = null;
/* 1535 */     ArrayList results = new ArrayList();
/* 1536 */     ResultSet resultSet = null;
/* 1537 */     RatePlanGroup ratePlanGroup = null;
/* 1538 */     QueryModel query = getQuery(BackEndConstants.RATE_PLAN_GROUP);
/* 1539 */     String querySql = query.getSql();
/* 1540 */     if ((name != null) && (!name.equals("")))
/* 1541 */       querySql = querySql + " where lower(RATE_PLAN_GROUP) like lower('%" + name + 
/* 1542 */         "%')";
/*      */     else {
/* 1544 */       querySql = querySql + " where lower(RATE_PLAN_GROUP) like ('%%')";
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1549 */       connection = getConnection();
/* 1550 */       statement = connection.prepareStatement(querySql);
/* 1551 */       logger.info("Query : " + querySql);
/* 1552 */       resultSet = statement.executeQuery();
/* 1553 */       while (resultSet.next())
/*      */       {
/* 1555 */         ratePlanGroup = new RatePlanGroup();
/* 1556 */         ratePlanGroup
/* 1557 */           .setRpGroupDesc(resultSet.getString("DESCRIPTION"));
/* 1558 */         ratePlanGroup.setRpGroupName(resultSet
/* 1559 */           .getString("RATE_PLAN_GROUP"));
/* 1560 */         ratePlanGroup.setRpGroupKey(resultSet
/* 1561 */           .getInt("RATE_PLAN_GROUP_KEY"));
/* 1562 */         System.out.println("keeeeeeee" + 
/* 1563 */           ratePlanGroup.getRpGroupKey());
/*      */ 
/* 1566 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/* 1567 */           ratePlanGroup.setRpGroupShow(true);
/*      */         else {
/* 1569 */           ratePlanGroup.setRpGroupShow(false);
/*      */         }
/* 1571 */         ratePlanGroup.setOldrpGroupName(ratePlanGroup.getRpGroupName());
/* 1572 */         ratePlanGroup.setOldrpGroupDesc(ratePlanGroup.getRpGroupDesc());
/* 1573 */         ratePlanGroup.setOldrpGroupShow(ratePlanGroup.isRpGroupShow());
/* 1574 */         results.add(ratePlanGroup);
/*      */       }
/* 1576 */       closeConnection(connection, statement);
/* 1577 */       return results;
/*      */     } catch (Exception e) {
/* 1579 */       e.printStackTrace();
/* 1580 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1581 */       closeConnection(connection, statement);
/* 1582 */     }return null;
/*      */   }
/*      */ 
/*      */   public synchronized int createGroup(RatePlanGroup ratePlanGroup)
/*      */   {
/* 1591 */     Connection connection = null;
/* 1592 */     PreparedStatement statement = null;
/* 1593 */     QueryModel query = getQuery(BackEndConstants.CREATE_GROUP);
/* 1594 */     String querySql = query.getSql();
/*      */ 
/* 1596 */     String values = "Query Values: ";
/* 1597 */     LogFact logFact = new LogFact();
/* 1598 */     ArrayList rateplanForUpdate = new ArrayList();
/*      */     try {
/* 1600 */       boolean check = checkGroup(ratePlanGroup);
/* 1601 */       if (check) {
/* 1602 */         return -1;
/*      */       }
/* 1604 */       connection = getConnection();
/* 1605 */       statement = connection.prepareStatement(querySql);
/* 1606 */       statement.setString(1, ratePlanGroup.getRpGroupName());
/* 1607 */       values = values + " Param1=" + ratePlanGroup.getRpGroupName() + " - ";
/* 1608 */       statement.setString(3, ratePlanGroup.getRpGroupDesc());
/* 1609 */       values = values + " Param3=" + ratePlanGroup.getRpGroupDesc();
/* 1610 */       if (ratePlanGroup.isRpGroupShow()) {
/* 1611 */         statement.setInt(2, 1);
/* 1612 */         values = values + " Param2=1 - ";
/*      */       } else {
/* 1614 */         statement.setInt(2, 0);
/* 1615 */         values = values + " Param2=0 - ";
/*      */       }
/* 1617 */       logger.info("Query : " + querySql);
/* 1618 */       logger.info("Query values : " + values);
/* 1619 */       statement.executeUpdate();
/* 1620 */       connection.commit();
/* 1621 */       closeConnection(connection, statement);
/* 1622 */       int key = getMaxGroup();
/* 1623 */       logFact.setLogAttribute(BackEndConstants.LOG_GROUP_NAME);
/* 1624 */       logFact.setSource(String.valueOf(key));
/* 1625 */       logFact.setNewValue(ratePlanGroup.getRpGroupName());
/* 1626 */       logFact.setOldValue("");
/* 1627 */       logFact.setTimeStamp(new Date());
/* 1628 */       logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1629 */       LogService.getDao().log(logFact);
/*      */ 
/* 1631 */       if (ratePlanGroup.getRatePlans() != null) {
/* 1632 */         Iterator it = ratePlanGroup.getRatePlans().iterator();
/* 1633 */         while (it.hasNext()) {
/* 1634 */           RatePlan ratePlan = (RatePlan)it.next();
/* 1635 */           if (!ratePlan.isUpdate())
/*      */             continue;
/* 1637 */           rateplanForUpdate.add(ratePlan);
/*      */         }
/*      */ 
/* 1640 */         updateGroups(rateplanForUpdate, key, ratePlanGroup.isRpGroupShow());
/*      */       }
/* 1642 */       return 1;
/*      */     }
/*      */     catch (Exception e) {
/* 1645 */       e.printStackTrace();
/* 1646 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1647 */       closeConnection(connection, statement);
/* 1648 */     }return -1;
/*      */   }
/*      */ 
/*      */   public synchronized int updateGroup(RatePlanGroup ratePlanGroup)
/*      */   {
/* 1656 */     Connection connection = null;
/* 1657 */     PreparedStatement statement = null;
/* 1658 */     QueryModel query = getQuery(BackEndConstants.UPDATE_GROUPS);
/* 1659 */     String querySql = query.getSql();
/*      */ 
/* 1661 */     String values = "Query Values: ";
/* 1662 */     ArrayList rateplanForUpdate = new ArrayList();
/*      */     try {
/* 1664 */       int check = checkGroupName(ratePlanGroup);
/* 1665 */       System.out.println(check);
/* 1666 */       if ((check != -1) && 
/* 1667 */         (check != ratePlanGroup.getRpGroupKey())) {
/* 1668 */         return -1;
/*      */       }
/*      */ 
/* 1671 */       connection = getConnection();
/* 1672 */       statement = connection.prepareStatement(querySql);
/* 1673 */       statement.setString(1, ratePlanGroup.getRpGroupName());
/* 1674 */       values = values + " Param1=" + ratePlanGroup.getRpGroupName() + " - ";
/* 1675 */       statement.setString(3, ratePlanGroup.getRpGroupDesc());
/* 1676 */       values = values + " Param3=" + ratePlanGroup.getRpGroupDesc() + " - ";
/* 1677 */       if (ratePlanGroup.isRpGroupShow()) {
/* 1678 */         statement.setInt(2, 1);
/* 1679 */         values = values + " Param2=1 - ";
/*      */       } else {
/* 1681 */         statement.setInt(2, 0);
/* 1682 */         values = values + " Param2=0 - ";
/*      */       }
/*      */ 
/* 1685 */       statement.setInt(4, ratePlanGroup.getRpGroupKey());
/* 1686 */       values = values + " Param4=" + ratePlanGroup.getRpGroupKey();
/* 1687 */       logger.info("Query : " + querySql);
/* 1688 */       logger.info("Query values : " + values);
/* 1689 */       statement.executeUpdate();
/* 1690 */       connection.commit();
/* 1691 */       closeConnection(connection, statement);
/*      */ 
/* 1693 */       LogFact logFact = new LogFact();
/* 1694 */       if (!ratePlanGroup.getRpGroupName().equals(ratePlanGroup.getOldrpGroupName())) {
/* 1695 */         logFact.setLogAttribute(BackEndConstants.LOG_GROUP_NAME);
/*      */ 
/* 1697 */         logFact.setNewValue(ratePlanGroup.getRpGroupName());
/* 1698 */         logFact.setOldValue(ratePlanGroup.getOldrpGroupName());
/* 1699 */         logFact.setSource(String.valueOf(ratePlanGroup.getRpGroupKey()));
/* 1700 */         logFact.setTimeStamp(new Date());
/* 1701 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1702 */         LogService.getDao().log(logFact);
/*      */       }
/*      */ 
/* 1705 */       if (ratePlanGroup.isRpGroupShow() != ratePlanGroup.isOldrpGroupShow()) {
/* 1706 */         logFact = new LogFact();
/* 1707 */         logFact.setLogAttribute(BackEndConstants.LOG_GROUP_SHOW);
/* 1708 */         logFact.setNewValue(String.valueOf(ratePlanGroup.isRpGroupShow()));
/* 1709 */         logFact.setOldValue(
/* 1710 */           String.valueOf(ratePlanGroup.isOldrpGroupShow()));
/* 1711 */         logFact.setTimeStamp(new Date());
/* 1712 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1713 */         LogService.getDao().log(logFact);
/*      */       }
/*      */ 
/* 1718 */       if (!ratePlanGroup.getRpGroupDesc().equals(ratePlanGroup.getOldrpGroupDesc())) {
/* 1719 */         logFact.setLogAttribute(BackEndConstants.LOG_GROUP_DESC);
/* 1720 */         logFact.setNewValue(ratePlanGroup.getRpGroupDesc());
/* 1721 */         logFact.setOldValue(ratePlanGroup.getOldrpGroupDesc());
/* 1722 */         logFact.setSource(String.valueOf(ratePlanGroup.getRpGroupKey()));
/* 1723 */         logFact.setTimeStamp(new Date());
/* 1724 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 1725 */         LogService.getDao().log(logFact);
/*      */       }
/*      */ 
/* 1728 */       int key = ratePlanGroup.getRpGroupKey();
/* 1729 */       Iterator it = ratePlanGroup.getRatePlans().iterator();
/* 1730 */       while (it.hasNext()) {
/* 1731 */         RatePlan ratePlan = (RatePlan)it.next();
/* 1732 */         if ((!ratePlan.isUpdate()) && (!ratePlan.isOriginal()))
/*      */           continue;
/* 1734 */         rateplanForUpdate.add(ratePlan);
/*      */       }
/*      */ 
/* 1737 */       updateGroups(rateplanForUpdate, key, ratePlanGroup.isRpGroupShow());
/* 1738 */       return 1;
/*      */     }
/*      */     catch (Exception e) {
/* 1741 */       e.printStackTrace();
/* 1742 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1743 */       closeConnection(connection, statement);
/* 1744 */     }return -1;
/*      */   }
/*      */ 
/*      */   public boolean checkGroup(RatePlanGroup planGroup)
/*      */   {
/* 1752 */     Connection connection = null;
/* 1753 */     PreparedStatement statement = null;
/* 1754 */     QueryModel query = getQuery(BackEndConstants.CHECK_GROUP);
/* 1755 */     String querySql = query.getSql();
/* 1756 */     int result = -1;
/*      */     try
/*      */     {
/* 1759 */       connection = getConnection();
/* 1760 */       statement = connection.prepareStatement(querySql);
/* 1761 */       statement.setString(1, planGroup.getRpGroupName());
/* 1762 */       logger.info("Query : " + querySql);
/* 1763 */       logger.info("Query values : Param1=" + planGroup.getRpGroupName());
/* 1764 */       ResultSet resultSet = statement.executeQuery();
/* 1765 */       while (resultSet.next()) {
/* 1766 */         result = resultSet.getInt(1);
/*      */       }
/*      */ 
/* 1769 */       closeConnection(connection, statement);
/*      */ 
/* 1771 */       return result == 1;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1777 */       e.printStackTrace();
/* 1778 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1779 */       closeConnection(connection, statement);
/* 1780 */     }return false;
/*      */   }
/*      */ 
/*      */   public int checkGroupName(RatePlanGroup planGroup)
/*      */   {
/* 1788 */     Connection connection = null;
/* 1789 */     PreparedStatement statement = null;
/* 1790 */     QueryModel query = getQuery(BackEndConstants.CHECK_GROUP);
/* 1791 */     String querySql = query.getSql();
/* 1792 */     int result = -1;
/*      */     try
/*      */     {
/* 1795 */       connection = getConnection();
/* 1796 */       statement = connection.prepareStatement(querySql);
/* 1797 */       statement.setString(1, planGroup.getRpGroupName());
/* 1798 */       logger.info("Query : " + querySql);
/* 1799 */       logger.info("Query values : Param1=" + planGroup.getRpGroupName());
/* 1800 */       ResultSet resultSet = statement.executeQuery();
/*      */ 
/* 1802 */       while (resultSet.next()) {
/* 1803 */         result = resultSet.getInt(3);
/*      */       }
/*      */ 
/* 1806 */       closeConnection(connection, statement);
/* 1807 */       return result;
/*      */     }
/*      */     catch (Exception e) {
/* 1810 */       e.printStackTrace();
/* 1811 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 1812 */       closeConnection(connection, statement);
/* 1813 */     }return result;
/*      */   }
/*      */ }