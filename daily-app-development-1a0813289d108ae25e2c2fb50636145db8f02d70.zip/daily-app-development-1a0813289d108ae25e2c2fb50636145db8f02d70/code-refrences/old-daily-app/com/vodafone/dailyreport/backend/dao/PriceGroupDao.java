package com.vodafone.dailyreport.backend.dao;

import com.vodafone.dailyreport.backend.constant.BackEndConstants;
import com.vodafone.dailyreport.backend.log.LogHandler;
import com.vodafone.dailyreport.backend.model.LogFact;
import com.vodafone.dailyreport.backend.model.PriceGroupGroup;
import com.vodafone.dailyreport.backend.model.PriceGroupModel;
import com.vodafone.dailyreport.backend.model.QueryModel;
import com.vodafone.dailyreport.backend.service.LogService;
import com.vodafone.dailyreport.frontend.beans.LoginBean;
import com.vodafone.dailyreport.frontend.util.SessionHelper;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import org.apache.log4j.Logger;

public class PriceGroupDao extends BaseDao
{
/*  25 */   public static Logger logger = Logger.getLogger(PriceGroupDao.class.getName());

  public boolean checkGroup(PriceGroupGroup planGroup)
  {
/*  29 */     Connection connection = null;
/*  30 */     PreparedStatement statement = null;
/*  31 */     QueryModel query = getQuery(BackEndConstants.CHECK_PRICEGROUP_GROUP);
/*  32 */     String querySql = query.getSql();

/*  34 */     String values = "Query Values: ";
/*  35 */     int result = -1;
    try
    {
/*  38 */       connection = getConnection();
/*  39 */       statement = connection.prepareStatement(querySql);
/*  40 */       statement.setString(1, planGroup.getGroupName());
/*  41 */       values = values + " Param1=" + planGroup.getGroupName();
/*  42 */       logger.info("Query : " + querySql);
/*  43 */       logger.info("Query values : " + values);
/*  44 */       ResultSet resultSet = statement.executeQuery();
/*  45 */       while (resultSet.next()) {
/*  46 */         result = resultSet.getInt(1);
      }

/*  49 */       closeConnection(connection, statement);

/*  51 */       return result == 1;
    }
    catch (Exception e)
    {
/*  57 */       e.printStackTrace();
/*  58 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  59 */       closeConnection(connection, statement);
/*  60 */     }return false;
  }

  public int getMaxGroup()
  {
/*  67 */     Connection connection = null;
/*  68 */     PreparedStatement statement = null;
/*  69 */     QueryModel query = getQuery(BackEndConstants.CREATE_GROUP);
/*  70 */     String querySql = "select max(PG_GROUP_KEY) key from  PG_GROUP ";
/*  71 */     logger.info("Query : " + querySql);
/*  72 */     int result = -1;
    try
    {
/*  75 */       connection = getConnection();
/*  76 */       statement = connection.prepareStatement(querySql);
/*  77 */       ResultSet resultSet = statement.executeQuery();
/*  78 */       while (resultSet.next()) {
/*  79 */         result = resultSet.getInt(1);
      }

/*  82 */       closeConnection(connection, statement);
/*  83 */       return result;
    }
    catch (Exception e) {
/*  86 */       e.printStackTrace();
/*  87 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/*  88 */       closeConnection(connection, statement);
/*  89 */     }return result;
  }

  public synchronized int createGroup(PriceGroupGroup priceGroup)
  {
/*  97 */     Connection connection = null;
/*  98 */     PreparedStatement statement = null;
/*  99 */     QueryModel query = getQuery(BackEndConstants.CREATE_PRICEGROUP_GROUP);
/* 100 */     String querySql = query.getSql();

/* 102 */     String values = "Query Values: ";

/* 104 */     LogFact logFact = new LogFact();
/* 105 */     ArrayList priceGroupForUpdate = new ArrayList();
    try {
/* 107 */       boolean check = checkGroup(priceGroup);
/* 108 */       if (check) {
/* 109 */         return -1;
      }
/* 111 */       connection = getConnection();
/* 112 */       statement = connection.prepareStatement(querySql);
/* 113 */       statement.setString(1, priceGroup.getGroupName());
/* 114 */       values = values + " Param1=" + priceGroup.getGroupName() + " - ";
/* 115 */       statement.setString(3, priceGroup.getDesc());
/* 116 */       values = values + " Param3=" + priceGroup.getDesc();
/* 117 */       if (priceGroup.isShow()) {
/* 118 */         statement.setInt(2, 1);
/* 119 */         values = values + " Param2=1 - ";
      } else {
/* 121 */         statement.setInt(2, 0);
/* 122 */         values = values + " Param2=0 - ";
      }
/* 124 */       logger.info("Query : " + querySql);
/* 125 */       logger.info("Query values : " + values);
/* 126 */       statement.executeUpdate();
/* 127 */       connection.commit();
/* 128 */       closeConnection(connection, statement);
/* 129 */       int key = getMaxGroup();
/* 130 */       logFact.setLogAttribute(BackEndConstants.LOG_PRICEGROUPING_NAME);
/* 131 */       logFact.setSource(String.valueOf(key));
/* 132 */       logFact.setNewValue(priceGroup.getGroupName());
/* 133 */       logFact.setOldValue("");
/* 134 */       logFact.setTimeStamp(new Date());
/* 135 */       logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 136 */       LogService.getDao().log(logFact);

/* 138 */       if (priceGroup.getPriceGroups() != null) {
/* 139 */         Iterator it = priceGroup.getPriceGroups().iterator();
/* 140 */         while (it.hasNext()) {
/* 141 */           PriceGroupModel pg = (PriceGroupModel)it.next();
/* 142 */           if (!pg.isUpdate())
            continue;
/* 144 */           priceGroupForUpdate.add(pg);
        }

/* 147 */         updateGroups(priceGroupForUpdate, key);
      }
/* 149 */       return 1;
    }
    catch (Exception e) {
/* 152 */       e.printStackTrace();
/* 153 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 154 */       closeConnection(connection, statement);
/* 155 */     }return -1;
  }

  public int checkGroupName(PriceGroupGroup planGroup)
  {
/* 163 */     Connection connection = null;
/* 164 */     PreparedStatement statement = null;
/* 165 */     QueryModel query = getQuery(BackEndConstants.CHECK_PRICEGROUP_GROUP);
/* 166 */     String querySql = query.getSql();

/* 168 */     String values = "Query Values: ";

/* 170 */     int result = -1;
    try
    {
/* 173 */       connection = getConnection();
/* 174 */       statement = connection.prepareStatement(querySql);
/* 175 */       statement.setString(1, planGroup.getGroupName());
/* 176 */       values = values + " Param1=" + planGroup.getGroupName();
/* 177 */       logger.info("Query : " + querySql);
/* 178 */       logger.info("Query values : " + values);

/* 180 */       ResultSet resultSet = statement.executeQuery();

/* 182 */       while (resultSet.next()) {
/* 183 */         result = resultSet.getInt(3);
      }

/* 186 */       closeConnection(connection, statement);
/* 187 */       return result;
    }
    catch (Exception e) {
/* 190 */       e.printStackTrace();
/* 191 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 192 */       closeConnection(connection, statement);
/* 193 */     }return result;
  }

  public synchronized int updateGroup(PriceGroupGroup group)
  {
/* 202 */     Connection connection = null;
/* 203 */     PreparedStatement statement = null;
/* 204 */     QueryModel query = getQuery(BackEndConstants.UPDATE_PRICEGROUP_GROUP);
/* 205 */     String querySql = query.getSql();

/* 207 */     String values = "Query Values: ";

/* 209 */     ArrayList priceGroupForUpdate = new ArrayList();
    try {
/* 211 */       int check = checkGroupName(group);
/* 212 */       System.out.println("chcek" + check + group.getGroupKey());
/* 213 */       if ((check != -1) && 
/* 214 */         (check != group.getGroupKey())) {
/* 215 */         return -1;
      }

/* 218 */       connection = getConnection();
/* 219 */       statement = connection.prepareStatement(querySql);
/* 220 */       statement.setString(1, group.getGroupName());
/* 221 */       values = values + " Param1=" + group.getGroupName() + " - ";
/* 222 */       statement.setString(3, group.getDesc());
/* 223 */       values = values + " Param3=" + group.getDesc() + " - ";
/* 224 */       if (group.isShow()) {
/* 225 */         statement.setInt(2, 1);
/* 226 */         values = values + " Param2=1 - ";
      } else {
/* 228 */         statement.setInt(2, 0);
/* 229 */         values = values + " Param2=0 - ";
      }

/* 232 */       statement.setInt(4, group.getGroupKey());
/* 233 */       values = values + " Param4=" + group.getGroupKey() + " - ";
/* 234 */       logger.info("Query : " + querySql);
/* 235 */       logger.info("Query values : " + values);
/* 236 */       statement.executeUpdate();
/* 237 */       connection.commit();
/* 238 */       closeConnection(connection, statement);

/* 240 */       LogFact logFact = new LogFact();
/* 241 */       if (!group.getGroupName().equals(group.getOldGroupName())) {
/* 242 */         logFact.setLogAttribute(BackEndConstants.LOG_PRICEGROUPING_NAME);

/* 244 */         logFact.setNewValue(group.getGroupName());
/* 245 */         logFact.setOldValue(group.getOldGroupName());
/* 246 */         logFact.setSource(String.valueOf(group.getGroupKey()));
/* 247 */         logFact.setTimeStamp(new Date());
/* 248 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 249 */         LogService.getDao().log(logFact);
      }

/* 252 */       if (group.isShow() != group.isOldShow()) {
/* 253 */         logFact = new LogFact();
/* 254 */         logFact.setLogAttribute(BackEndConstants.LOG_PRICEGROUPING_SHOW);
/* 255 */         logFact.setNewValue(String.valueOf(group.isShow()));
/* 256 */         logFact.setOldValue(
/* 257 */           String.valueOf(group.isOldShow()));
/* 258 */         logFact.setSource(String.valueOf(group.getGroupKey()));
/* 259 */         logFact.setTimeStamp(new Date());
/* 260 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 261 */         LogService.getDao().log(logFact);
      }

/* 264 */       if (!group.getDesc().equals(group.getOldDesc())) {
/* 265 */         logFact.setLogAttribute(BackEndConstants.LOG_GROUP_DESC);
/* 266 */         logFact.setNewValue(group.getDesc());
/* 267 */         logFact.setOldValue(group.getOldDesc());
/* 268 */         logFact.setSource(String.valueOf(group.getGroupKey()));
/* 269 */         logFact.setTimeStamp(new Date());
/* 270 */         logFact.setUser(SessionHelper.getLoginBean().getUserModel());
/* 271 */         LogService.getDao().log(logFact);
      }

/* 275 */       int key = group.getGroupKey();
/* 276 */       Iterator it = group.getPriceGroups().iterator();
/* 277 */       while (it.hasNext()) {
/* 278 */         PriceGroupModel pg = (PriceGroupModel)it.next();
/* 279 */         if ((!pg.isUpdate()) && (!pg.isOriginal()))
          continue;
/* 281 */         priceGroupForUpdate.add(pg);
      }

/* 284 */       updateGroups(priceGroupForUpdate, key);
/* 285 */       return 1;
    }
    catch (Exception e) {
/* 288 */       e.printStackTrace();
/* 289 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 290 */       closeConnection(connection, statement);
/* 291 */     }return -1;
  }

  public void updateGroups(ArrayList priceGroups, int groupKey)
  {
/* 298 */     Connection connection = null;
/* 299 */     PreparedStatement statement = null;
/* 300 */     Iterator it = priceGroups.iterator();
/* 301 */     ArrayList logFacts = new ArrayList();
/* 302 */     QueryModel query = getQuery(BackEndConstants.UPDATE_PRICEGROUP);
/* 303 */     String querySql = query.getSql();

/* 305 */     String values = "Query Values: ";
    try
    {
/* 309 */       connection = getConnection();
/* 310 */       statement = connection.prepareStatement(querySql);
/* 311 */       while (it.hasNext()) {
/* 312 */         PriceGroupModel pg = (PriceGroupModel)it.next();
/* 313 */         if ((pg.isUpdate()) || (pg.isOriginal())) {
/* 314 */           statement.setInt(1, groupKey);
/* 315 */           values = values + " Param1=" + groupKey + " - ";
/* 316 */           statement.setString(2, pg.getPriceGroupCode());
/* 317 */           values = values + " Param2=" + pg.getPriceGroupCode();
/* 318 */           logger.info("Query : " + querySql);
/* 319 */           logger.info("Query values : " + values);
        }
/* 321 */         statement.addBatch();
      }

/* 324 */       statement.executeBatch();
/* 325 */       connection.commit();
/* 326 */       closeConnection(connection, statement);

/* 329 */       it = priceGroups.iterator();
/* 330 */       while (it.hasNext()) {
/* 331 */         PriceGroupModel pg = (PriceGroupModel)it.next();
/* 332 */         if (pg.isUpdate()) {
/* 333 */           LogFact logFact = new LogFact();
/* 334 */           logFact.setSource(String.valueOf(pg.getPriceGroupCode()));
/* 335 */           logFact
/* 336 */             .setLogAttribute(BackEndConstants.LOG_PRICEGROUP_GROUP);
/* 337 */           logFact.setNewValue(String.valueOf(groupKey));
/* 338 */           logFact.setOldValue(String.valueOf(pg
/* 339 */             .getPriceGroupGroupKey().getGroupKey()));
/* 340 */           logFact.setTimeStamp(new Date());
/* 341 */           logFact
/* 342 */             .setUser(SessionHelper.getLoginBean()
/* 343 */             .getUserModel());
/* 344 */           logFacts.add(logFact);
        }
      }
/* 347 */       LogService.getDao().log(logFacts);
    }
    catch (Exception e) {
/* 350 */       e.printStackTrace();
/* 351 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 352 */       closeConnection(connection, statement);
    }
  }

  public ArrayList getGroupByname(String name, boolean show)
  {
/* 358 */     Connection connection = null;
/* 359 */     PreparedStatement statement = null;
/* 360 */     ArrayList results = new ArrayList();
/* 361 */     ResultSet resultSet = null;
/* 362 */     PriceGroupGroup pgGroup = null;
/* 363 */     QueryModel query = getQuery(BackEndConstants.PRICEGROUP_GROUP);
/* 364 */     String querySql = query.getSql();
/* 365 */     if ((name != null) && (!name.equals("")))
/* 366 */       querySql = querySql + " where lower(PG_GROUP) like lower('%" + name + 
/* 367 */         "%')";
    else {
/* 369 */       querySql = querySql + " where lower(PG_GROUP) like ('%%')";
    }
/* 371 */     logger.info("Query : " + querySql);
    try
    {
/* 375 */       connection = getConnection();
/* 376 */       statement = connection.prepareStatement(querySql);
/* 377 */       resultSet = statement.executeQuery();
/* 378 */       while (resultSet.next())
      {
/* 380 */         pgGroup = new PriceGroupGroup();
/* 381 */         pgGroup.setDesc(resultSet.getString("DESCRIPTION"));
/* 382 */         pgGroup.setGroupName(resultSet.getString("PG_GROUP"));
/* 383 */         pgGroup.setGroupKey(resultSet.getInt("PG_GROUP_KEY"));

/* 385 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/* 386 */           pgGroup.setShow(true);
        else {
/* 388 */           pgGroup.setShow(false);
        }
/* 390 */         pgGroup.setOldDesc(pgGroup.getDesc());
/* 391 */         pgGroup.setOldGroupName(pgGroup.getGroupName());
/* 392 */         pgGroup.setOldShow(pgGroup.isShow());
/* 393 */         results.add(pgGroup);
      }
/* 395 */       closeConnection(connection, statement);
/* 396 */       return results;
    } catch (Exception e) {
/* 398 */       e.printStackTrace();
/* 399 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 400 */       closeConnection(connection, statement);
/* 401 */     }return null;
  }

  public ArrayList getPgbyGroup(int groupKey)
  {
/* 406 */     Connection connection = null;
/* 407 */     PreparedStatement statement = null;
/* 408 */     ArrayList results = new ArrayList();
/* 409 */     ResultSet resultSet = null;
/* 410 */     QueryModel query = getQuery(BackEndConstants.PRICEGROUP);
/* 411 */     String querySql = query.getSql();
/* 412 */     querySql = querySql + " and a.PG_GROUP_KEY  = " + groupKey;
    try {
/* 414 */       System.out.println(querySql);
/* 415 */       logger.info("Query : " + querySql);
/* 416 */       connection = getConnection();
/* 417 */       statement = connection.prepareStatement(querySql);
/* 418 */       resultSet = statement.executeQuery();
/* 419 */       while (resultSet.next())
      {
/* 421 */         PriceGroupModel pg = new PriceGroupModel();

/* 423 */         pg.setPriceGroupCode(resultSet.getString("PRICE_GROUP_CODE"));
/* 424 */         pg.setPriceGroupName(resultSet.getString("PRICE_GROUP"));

/* 426 */         if (resultSet
/* 427 */           .getInt("PG_GROUP_KEY") != 0) {
/* 428 */           PriceGroupGroup group = new PriceGroupGroup();
/* 429 */           group = new PriceGroupGroup();
/* 430 */           group.setDesc(resultSet.getString("DESCRIPTION"));
/* 431 */           group.setGroupName(resultSet.getString("PG_GROUP"));
/* 432 */           group.setGroupKey(resultSet.getInt("GROUP_KEY"));
/* 433 */           if (resultSet.getInt("SHOW_FLAG") == 1)
/* 434 */             group.setShow(true);
          else {
/* 436 */             group.setShow(false);
          }
/* 438 */           pg.setPriceGroupGroupKey(group);
        } else {
/* 440 */           pg.setPriceGroupGroupKey(new PriceGroupGroup());
        }

/* 444 */         results.add(pg);
      }
/* 446 */       closeConnection(connection, statement);
/* 447 */       System.out.println("size" + results.size());
/* 448 */       return results;
    } catch (Exception e) {
/* 450 */       e.printStackTrace();
/* 451 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 452 */       closeConnection(connection, statement);
/* 453 */     }return null;
  }

  public PriceGroupGroup getGroupbyKeyALL(int key)
  {
/* 458 */     Connection connection = null;
/* 459 */     PreparedStatement statement = null;
/* 460 */     ArrayList results = new ArrayList();
/* 461 */     ResultSet resultSet = null;
/* 462 */     PriceGroupGroup group = null;
/* 463 */     QueryModel query = getQuery(BackEndConstants.PRICEGROUP_GROUP);
/* 464 */     String querySql = query.getSql();
/* 465 */     querySql = querySql + " where PG_GROUP_KEY =" + key;
/* 466 */     logger.info("Query : " + querySql);
    try
    {
/* 471 */       connection = getConnection();
/* 472 */       statement = connection.prepareStatement(querySql);
/* 473 */       resultSet = statement.executeQuery();
/* 474 */       while (resultSet.next())
      {
/* 476 */         group = new PriceGroupGroup();
/* 477 */         group.setDesc(resultSet.getString("DESCRIPTION"));
/* 478 */         group.setGroupName(resultSet.getString("PG_GROUP"));
/* 479 */         group.setGroupKey(resultSet.getInt("PG_GROUP_KEY"));
/* 480 */         if (resultSet.getInt("SHOW_FLAG") == 1)
/* 481 */           group.setShow(true);
        else {
/* 483 */           group.setShow(false);
        }
      }
/* 486 */       closeConnection(connection, statement);
/* 487 */       return group;
    } catch (Exception e) {
/* 489 */       e.printStackTrace();
/* 490 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 491 */       closeConnection(connection, statement);
/* 492 */     }return null;
  }

  public ArrayList getPg(String name)
  {
/* 498 */     Connection connection = null;
/* 499 */     PreparedStatement statement = null;
/* 500 */     ArrayList results = new ArrayList();
/* 501 */     ResultSet resultSet = null;
/* 502 */     QueryModel query = getQuery(BackEndConstants.PRICEGROUP);
/* 503 */     String qs = query.getSql();
/* 504 */     if ((name != null) && (!name.equals("")))
/* 505 */       qs = qs + " and lower(PRICE_GROUP) like  lower('%" + name + "%')";
    else {
/* 507 */       qs = qs + " and lower(PRICE_GROUP) like  lower('%%')";
    }
/* 509 */     logger.info("Query : " + qs);
    try
    {
/* 513 */       connection = getConnection();
/* 514 */       statement = connection.prepareStatement(qs);
/* 515 */       resultSet = statement.executeQuery();
/* 516 */       while (resultSet.next())
      {
/* 518 */         PriceGroupModel pg = new PriceGroupModel();

/* 521 */         pg.setPriceGroupCode(resultSet.getString("PRICE_GROUP_CODE"));
/* 522 */         pg.setPriceGroupName(resultSet.getString("PRICE_GROUP"));

/* 524 */         if (resultSet
/* 525 */           .getInt("PG_GROUP_KEY") != 0) {
/* 526 */           PriceGroupGroup group = new PriceGroupGroup();
/* 527 */           group = new PriceGroupGroup();
/* 528 */           group.setDesc(resultSet.getString("DESCRIPTION"));
/* 529 */           group.setGroupName(resultSet.getString("PG_GROUP"));
/* 530 */           group.setGroupKey(resultSet.getInt("GROUP_KEY"));
/* 531 */           if (resultSet.getInt("SHOW_FLAG") == 1)
/* 532 */             group.setShow(true);
          else {
/* 534 */             group.setShow(false);
          }
/* 536 */           pg.setPriceGroupGroupKey(group);
        } else {
/* 538 */           pg.setPriceGroupGroupKey(new PriceGroupGroup());
        }

/* 542 */         results.add(pg);
      }
/* 544 */       closeConnection(connection, statement);
/* 545 */       return results;
    } catch (Exception e) {
/* 547 */       e.printStackTrace();
/* 548 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 549 */       closeConnection(connection, statement);
/* 550 */     }return null;
  }

  public ArrayList getPg()
  {
/* 555 */     Connection connection = null;
/* 556 */     PreparedStatement statement = null;
/* 557 */     ArrayList results = new ArrayList();
/* 558 */     ResultSet resultSet = null;
/* 559 */     QueryModel query = getQuery(BackEndConstants.PRICEGROUP);
/* 560 */     String qs = query.getSql();
/* 561 */     logger.info("Query : " + qs);
    try
    {
/* 565 */       connection = getConnection();
/* 566 */       statement = connection.prepareStatement(qs);
/* 567 */       resultSet = statement.executeQuery();
/* 568 */       while (resultSet.next())
      {
/* 570 */         PriceGroupModel pg = new PriceGroupModel();

/* 573 */         pg.setPriceGroupCode(resultSet.getString("PRICE_GROUP_CODE"));
/* 574 */         pg.setPriceGroupName(resultSet.getString("PRICE_GROUP"));
/* 575 */         if (resultSet
/* 576 */           .getInt("PG_GROUP_KEY") != 0) {
/* 577 */           PriceGroupGroup group = new PriceGroupGroup();
/* 578 */           group = new PriceGroupGroup();
/* 579 */           group.setDesc(resultSet.getString("DESCRIPTION"));
/* 580 */           group.setGroupName(resultSet.getString("PG_GROUP"));
/* 581 */           group.setGroupKey(resultSet.getInt("PG_GROUP_KEY"));
/* 582 */           if (resultSet.getInt("SHOW_FLAG") == 1)
/* 583 */             group.setShow(true);
          else {
/* 585 */             group.setShow(false);
          }
/* 587 */           pg.setPriceGroupGroupKey(group);
        } else {
/* 589 */           pg.setPriceGroupGroupKey(new PriceGroupGroup());
        }

/* 592 */         results.add(pg);
      }
/* 594 */       closeConnection(connection, statement);
/* 595 */       return results;
    } catch (Exception e) {
/* 597 */       e.printStackTrace();
/* 598 */       LOGGERDAO.log(Level.SEVERE, e.getMessage());
/* 599 */       closeConnection(connection, statement);
/* 600 */     }return null;
  }
}