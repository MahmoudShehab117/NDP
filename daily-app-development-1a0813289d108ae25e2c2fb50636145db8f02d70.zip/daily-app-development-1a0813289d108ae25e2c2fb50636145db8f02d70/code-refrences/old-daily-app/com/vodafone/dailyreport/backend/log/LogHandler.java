/*    */ package com.vodafone.dailyreport.backend.log;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class LogHandler extends Logger
/*    */ {
/* 15 */   public static LogHandler handler = new LogHandler("Daily Report Back End", null);
/*    */ 
/*    */   protected LogHandler(String name, String resourceBundleName) {
/* 18 */     super(name, resourceBundleName);
/*    */   }
/*    */ 
/*    */   public static LogHandler getLogger()
/*    */   {
/* 27 */     return handler;
/*    */   }
/*    */ }