package com.vodafone.dailyreport.backend.exception;

public class ExceptionHandler
{
}