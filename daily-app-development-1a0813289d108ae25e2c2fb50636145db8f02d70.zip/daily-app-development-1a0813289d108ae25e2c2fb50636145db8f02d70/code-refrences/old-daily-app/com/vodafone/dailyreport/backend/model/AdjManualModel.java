package com.vodafone.dailyreport.backend.model;

public class AdjManualModel
{
  private String adjName;
  private int adjKey;
  private long subs;
  private int value;
  private int dateKey;
  private int ratePlanKey;
  private RATEPLANALL rateplanall;
  private long adjust;
  private String ratePlanStr;

  public String getRatePlanStr()
  {
/*  17 */     return this.ratePlanStr;
  }

  public void setRatePlanStr(String ratePlanStr)
  {
/*  23 */     this.ratePlanStr = ratePlanStr;
  }

  public long getAdjust()
  {
/*  29 */     return this.adjust;
  }

  public void setAdjust(long adjust)
  {
/*  35 */     this.adjust = adjust;
  }

  public int getAdjKey()
  {
/*  41 */     return this.adjKey;
  }

  public void setAdjKey(int adjKey)
  {
/*  47 */     this.adjKey = adjKey;
  }

  public String getAdjName()
  {
/*  53 */     return this.adjName;
  }

  public void setAdjName(String adjName)
  {
/*  59 */     this.adjName = adjName;
  }

  public int getDateKey()
  {
/*  65 */     return this.dateKey;
  }

  public void setDateKey(int dateKey)
  {
/*  71 */     this.dateKey = dateKey;
  }

  public int getRatePlanKey()
  {
/*  78 */     return this.ratePlanKey;
  }

  public void setRatePlanKey(int ratePlanKey)
  {
/*  84 */     this.ratePlanKey = ratePlanKey;
  }

  public long getSubs()
  {
/*  90 */     return this.subs;
  }

  public void setSubs(long subs)
  {
/*  96 */     this.subs = subs;
  }

  public int getValue()
  {
/* 103 */     return this.value;
  }

  public void setValue(int value)
  {
/* 109 */     this.value = value;
  }

  public RATEPLANALL getRateplanall()
  {
/* 115 */     return this.rateplanall;
  }

  public void setRateplanall(RATEPLANALL rateplanall)
  {
/* 121 */     this.rateplanall = rateplanall;
  }
}