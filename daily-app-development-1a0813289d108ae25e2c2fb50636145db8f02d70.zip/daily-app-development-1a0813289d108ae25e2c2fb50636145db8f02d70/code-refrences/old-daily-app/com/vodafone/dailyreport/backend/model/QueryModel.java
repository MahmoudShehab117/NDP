/*    */ package com.vodafone.dailyreport.backend.model;
/*    */ 
/*    */ public class QueryModel
/*    */ {
/*    */   private String queryName;
/*    */   private String queryDesc;
/*    */   private String sql;
/*    */   private int seq;
/*    */   private int id;
/*    */ 
/*    */   public int getId()
/*    */   {
/* 18 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(int id)
/*    */   {
/* 24 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getQueryDesc()
/*    */   {
/* 30 */     return this.queryDesc;
/*    */   }
/*    */ 
/*    */   public void setQueryDesc(String queryDesc)
/*    */   {
/* 36 */     this.queryDesc = queryDesc;
/*    */   }
/*    */ 
/*    */   public String getQueryName()
/*    */   {
/* 42 */     return this.queryName;
/*    */   }
/*    */ 
/*    */   public void setQueryName(String queryName)
/*    */   {
/* 48 */     this.queryName = queryName;
/*    */   }
/*    */ 
/*    */   public int getSeq()
/*    */   {
/* 54 */     return this.seq;
/*    */   }
/*    */ 
/*    */   public void setSeq(int seq)
/*    */   {
/* 60 */     this.seq = seq;
/*    */   }
/*    */ 
/*    */   public String getSql()
/*    */   {
/* 66 */     return this.sql;
/*    */   }
/*    */ 
/*    */   public void setSql(String sql)
/*    */   {
/* 72 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public QueryModel(String queryName, String queryDesc, String sql, int seq, int id) {
/* 76 */     this.queryName = queryName;
/* 77 */     this.queryDesc = queryDesc;
/* 78 */     this.sql = sql;
/* 79 */     this.seq = seq;
/* 80 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public QueryModel()
/*    */   {
/*    */   }
/*    */ }