package com.vodafone.dailyreport.backend.service;

public class BaseService
{
}