export const environment = {
  production: false,
  url: 'http://10.0.20.41:7073',
};