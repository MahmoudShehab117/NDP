export interface PriceGroup {
  priceGroupKey: number;
  priceGroup: string;
  priceGroupCode: string;
  pgGroupKey: number;
}
