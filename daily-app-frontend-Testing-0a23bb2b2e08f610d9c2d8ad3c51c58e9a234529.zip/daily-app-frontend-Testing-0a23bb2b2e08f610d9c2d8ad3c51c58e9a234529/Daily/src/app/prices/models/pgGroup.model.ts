export interface PGGroup {
  pgGroup: string;
  description: string;
  showFlag: number;
  pgGroupKey?:number;
}
