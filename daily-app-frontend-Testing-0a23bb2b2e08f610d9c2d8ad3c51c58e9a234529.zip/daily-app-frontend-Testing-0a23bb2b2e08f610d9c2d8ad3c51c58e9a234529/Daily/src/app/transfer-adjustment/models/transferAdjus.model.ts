export interface Transfer {
    numberOfSubs:number,
    dataKey:number,
    ratePlanKey:number,
    trxTypeKey:number,
    ratePlanGroupKey:number,
    dwhStatusKey:number,
    pgGroupKey:number,
    ratePlanType :number
}