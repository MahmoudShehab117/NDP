export interface ProfileModel {
    id: number,
    name: string,
    list?: any,
    privileges:any
}