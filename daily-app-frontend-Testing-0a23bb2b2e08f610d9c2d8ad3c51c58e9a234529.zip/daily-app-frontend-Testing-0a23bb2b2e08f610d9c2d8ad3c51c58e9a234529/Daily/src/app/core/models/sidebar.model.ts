export interface Sidebar {
  icon: string;
  title: string;
  name: string;
  active: boolean;
  route: string;
}
