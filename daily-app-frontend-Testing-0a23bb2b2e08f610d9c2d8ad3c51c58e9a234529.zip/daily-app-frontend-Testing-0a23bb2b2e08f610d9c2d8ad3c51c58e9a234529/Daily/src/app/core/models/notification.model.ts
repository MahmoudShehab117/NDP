export interface Notification {
  actionDone: number;
  checkSum: string;
  creationDate: string;
  dataId: number;
  dataName: string;
  id: number;
  notificationDetails: string;
  notificationHeader: string;
  notificationType: number;
}
