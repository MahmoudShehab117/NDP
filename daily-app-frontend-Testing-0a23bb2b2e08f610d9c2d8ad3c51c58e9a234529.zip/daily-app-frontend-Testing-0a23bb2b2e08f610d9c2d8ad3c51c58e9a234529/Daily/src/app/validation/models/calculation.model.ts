export interface Calc {
  trxInSubs: number;
  trxOutSubs: number;
  inSubs: number;
  outSubs: number;
}
