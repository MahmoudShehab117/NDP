export interface Tab {
  name: string;
  count: number;
  icon: string;
  classStyle: string;
}
