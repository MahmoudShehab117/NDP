export interface Inputs {
  type: string;
  controlName: string;
  label: string;
  options?: any;
  readOnly?: any;
}
