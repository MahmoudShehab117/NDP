export interface Config {
  value?: string;
  code?: string;
  description?: string;
  type?: number;
  applicationName?: string;
}
