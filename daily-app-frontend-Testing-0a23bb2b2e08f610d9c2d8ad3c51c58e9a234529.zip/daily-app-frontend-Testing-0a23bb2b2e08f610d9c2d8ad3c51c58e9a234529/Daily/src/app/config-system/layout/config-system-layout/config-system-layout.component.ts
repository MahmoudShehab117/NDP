import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-system-layout',
  templateUrl: './config-system-layout.component.html',
  styleUrls: ['./config-system-layout.component.scss']
})
export class ConfigSystemLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
