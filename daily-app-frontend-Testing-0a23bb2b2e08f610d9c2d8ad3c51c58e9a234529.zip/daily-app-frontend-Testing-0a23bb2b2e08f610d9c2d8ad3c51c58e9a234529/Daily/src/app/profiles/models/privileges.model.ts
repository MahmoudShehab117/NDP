export interface Privilege {
  id: number;
  name: string;
  pageName: string;
  backEndUrl: string;
  description: string;
}
