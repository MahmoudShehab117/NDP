export interface Service {
  name: string;
  type: string;
  activSource: string;
  ContractType: string;
  BundleType: string;
  ratePlanGroupKey: number;
  ratePlanCode: string;
}
