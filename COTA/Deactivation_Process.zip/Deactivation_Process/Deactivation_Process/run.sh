java -D -cp COTA-DeactivationEngine.jar com.asset.cota.init.Main 2
